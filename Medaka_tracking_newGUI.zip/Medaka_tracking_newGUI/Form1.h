﻿/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/*

Medaka_Fish_Tracker

Planner:
Eiji Watanabe @ NIBB

Programmers:
Soma Shiroishi @ Kyushu Univ
Eiji Watanabe @ NIBB

Contributors:
Tomohiro Nakayasu @ NIBB
Masaki Yasugi @ NIBB
Seiji Uchida @ Kyushu Univ

IDE:
Visual Studio Express 2013 for Windows Desktop
with OpenCV242

* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.

*/
//////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////





#pragma once
#include "Labeling.h"
#include "tail_correction.h"
#include <time.h>



namespace Medaka_tracking_newGUI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;





	////////////////////////////
	/*Variable Declaration #1*/
	///////////////////////////



	/*Video & File*/
	cv::VideoCapture cap;
	std::string filename_nopath;
	cv::Mat bcgdImg;

	cv::Mat bcgd1st;
	cv::Mat bcgd2nd;
	cv::Mat bcgd3rd;

	/*Mouse Operation*/
	cv::Point mousedown;
	cv::Point mousenow;

	/*Box Area & ROI*/
	cv::Rect boxarea;//計算に使うエリア＝動画サイズに固定ver3.1
	cv::Rect aquabox;//水槽のエリア

	cv::Point boxarea_realsize;
	std::vector<cv::Rect> ROIs;
	std::vector<cv::Rect> ROI_realsize;
	std::vector<cv::Scalar> ROI_color;
	std::vector<int> ROI_targetline;
	std::vector<double> ROI_targetangle;
	std::vector<std::map<int,int>> ROI_whenhot;
	std::vector<int> ROI_totalhot;

	/*Reference Point*/
	cv::Point refpoint;

	/*Trackbar*/
	cv::Mat trackbarImg;

	/*Selecting the target frames*/
	int sttime, lsttime;
	int sttime_temp, lsttime_temp;
	bool target_frame_set;
	bool sttime_mdown;
	bool on_done_frames;

	/*Determining size*/
	int size_fish;
	int max_fish;
	int min_fish;
	double ave_fish;
	int bin_threshold;
	double blur_sigma;

	/*Tracking*/
	std::set<int> head_marked, tail_marked;	//一度マークがつく（トラッキング，もしくはクリック=手動で）とこれに追加される
	std::map<int,cv::Point> heads, tails;
	//std::map<int,std::vector<cv::Point>> joints;//joints廃止に伴う変更eijwat
	std::map<int,cv::Point> calc_pts;
	std::vector<int> suspecious_frame;	//tracking中にスキップしたフレームを示す
	std::vector<int> jump_frame;		//異常値検知によって見つけたフレーム
	int jump_i;

	
	
	

	/// <summary>
	/// Summary of Form1
	/// </summary>

	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		////////////////////////////
		/*Variable Declaration #2*/
		///////////////////////////

		System::String^ strfilename;

		int num_frames;
		int iframe_now;
		
		int width0, height0;

		//
		// Flags
		//
		/*General Flags*/
		bool video_set;
		bool background_set;

		/*Background Flags*/
		bool bcgd1st_set, bcgd2nd_set, bcgd3rd_set;

		/*Display*/
		bool show_box_area;

		/*Box Area*/
		bool setting_box_area;
		bool drawing_box_area;
		bool box_area_set;

		/*ROI*/
		bool setting_roi;
		bool drawing_roi;
		bool roi_set;
		bool roi_x_set,roi_y_set,roi_width_set,roi_height_set;

		/*Determining size*/
		bool setting_size;
		bool size_set;


		/*Tracking*/
		bool tracking_done;
		bool tracking_now;
		bool tracking_cancelled;

		/*Reference Point*///3.1 eijwat
		bool setting_reference_point;
		bool drawing_reference_point;
		bool reference_point_set;


	private: System::Windows::Forms::CheckBox^  cb_showboxarea;
	public: 
	private: System::Windows::Forms::CheckBox^  cb_showroi;
	private: System::Windows::Forms::Timer^  timer;
	private: System::ComponentModel::BackgroundWorker^  bgworker_tracking;




	private: System::Windows::Forms::CheckBox^  checkBox_showmarkers;
	private: System::Windows::Forms::Button^  b_debug;

	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Label^  label_barleft;
	private: System::Windows::Forms::Label^  label_barbottom;


	private: System::Windows::Forms::Label^  label_bartop;
	private: System::Windows::Forms::ComboBox^  comboBox_roianal;


	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::RadioButton^  rb_roibottom;

	private: System::Windows::Forms::RadioButton^  rb_roileft;

	private: System::Windows::Forms::RadioButton^  rb_roiright;

	private: System::Windows::Forms::RadioButton^  rb_roitop;

	private: System::Windows::Forms::Label^  label_barright;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::TextBox^  tb_roiangle;

	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::Button^  b_execanal;
	private: System::Windows::Forms::Button^  b_save_roianal;

	private: System::Windows::Forms::TextBox^  tb_head_angle;

	private: System::Windows::Forms::TextBox^  tb_anal_head_only;

	private: System::Windows::Forms::Label^  label35;
	private: System::Windows::Forms::Label^  label34;
	private: System::Windows::Forms::TextBox^  tb_anal_numframes;

	private: System::Windows::Forms::Label^  label33;
	private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::Label^  label30;
	private: System::Windows::Forms::Label^  label31;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::Label^  label29;
	private: System::Windows::Forms::Label^  label28;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::TabPage^  tabPage2;
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::GroupBox^  gb_saveparam;

	private: System::Windows::Forms::Button^  b_saveparamfile;
	private: System::Windows::Forms::GroupBox^  gb_writingvideo;


	private: System::Windows::Forms::GroupBox^  gb_writeoption;
	private: System::Windows::Forms::CheckBox^  cb_writeroi;
	private: System::Windows::Forms::CheckBox^  cb_writeoriginal;
	private: System::Windows::Forms::CheckBox^  cb_writebox;
	private: System::Windows::Forms::CheckBox^  cb_writehead;
	private: System::Windows::Forms::CheckBox^  cb_writejoint;
	private: System::Windows::Forms::CheckBox^  cb_writetail;
	private: System::Windows::Forms::Button^  b_savemarksonoriginal;
	private: System::Windows::Forms::GroupBox^  gb_saveresult;

	private: System::Windows::Forms::GroupBox^  gb_saving_as;
	private: System::Windows::Forms::RadioButton^  radioButton_csv;
	private: System::Windows::Forms::RadioButton^  radioButton_txt;
	private: System::Windows::Forms::Button^  b_saveresultdata;
	private: System::Windows::Forms::TabPage^  tab_tracking;
	private: System::Windows::Forms::GroupBox^  gb_determinesize;
	private: System::Windows::Forms::Button^  b_check;
	private: System::Windows::Forms::TrackBar^  trackBar_sizebinary;
	private: System::Windows::Forms::Button^  b_setsize;

	private: System::Windows::Forms::Button^  b_startsize;
	private: System::Windows::Forms::GroupBox^  gb_boxarea;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label19;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::TextBox^  textBox_boxarea_height;
	private: System::Windows::Forms::TextBox^  textBox_boxarea_width;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::Button^  b_set_boxarea;
	private: System::Windows::Forms::GroupBox^  gb_bonecalc;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  b_getbone_all;
	private: System::Windows::Forms::Button^  b_getbone_frame;
	private: System::Windows::Forms::GroupBox^  gb_tracking;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::NumericUpDown^  track_num_joint_points;
	private: System::Windows::Forms::Button^  b_track_exec;
	private: System::Windows::Forms::GroupBox^  gb_smoothing;
	private: System::Windows::Forms::NumericUpDown^  smoothing_param_beta;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::NumericUpDown^  smoothing_param_alpha;
	private: System::Windows::Forms::NumericUpDown^  smoothing_param_seq_length;
	private: System::Windows::Forms::Button^  b_smooth_exec;
	private: System::Windows::Forms::TabPage^  tab_load;
	private: System::Windows::Forms::GroupBox^  gb_setparam;

	private: System::Windows::Forms::Button^  b_loadparameter;
	private: System::Windows::Forms::GroupBox^  gb_setbackground;
	private: System::Windows::Forms::Label^  label_bcgdimagename;
	private: System::Windows::Forms::GroupBox^  gb_createbackground;
	private: System::Windows::Forms::Button^  b_savebcgdimage;
	private: System::Windows::Forms::Button^  b_1stimage;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Button^  b_2ndimage;
	private: System::Windows::Forms::Button^  b_showbackground;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  b_3rdimage;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  b_createbackground;
	private: System::Windows::Forms::Button^  b_loadbackground;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Label^  label_videofilename;
	private: System::Windows::Forms::Button^  b_loadvideofile;
	private: System::Windows::Forms::TabControl^  tab;
	private: System::Windows::Forms::Panel^  panel2;
	private: System::Windows::Forms::Label^  label38;
	private: System::Windows::Forms::Label^  label_heightarea;

	private: System::Windows::Forms::Label^  label_widtharea;
	private: System::ComponentModel::BackgroundWorker^  bgworker_writevideo;

	private: System::Windows::Forms::GroupBox^  gb_detecterror;

	private: System::Windows::Forms::Label^  label36;
	private: System::Windows::Forms::Button^  b_detecterror;
	private: System::Windows::Forms::Label^  label_time;

	private: System::Windows::Forms::Label^  label_numframes;
	private: System::Windows::Forms::CheckBox^  cb_numjoints;

	private: System::Windows::Forms::CheckBox^  cb_fish_size;
	private: System::Windows::Forms::CheckBox^  cb_roinum_area;


	private: System::Windows::Forms::CheckBox^  cb_box_area;

	private: System::Windows::Forms::CheckBox^  cb_videofile_name;
	private: System::Windows::Forms::CheckBox^  cb_date_exp;
	private: System::Windows::Forms::TextBox^  tb_exp_date;
	private: System::Windows::Forms::CheckBox^  cb_boxarea_real;
	private: System::Windows::Forms::Label^  label_readfromsettingfile;

	private: System::Windows::Forms::Label^  label41;
	private: System::Windows::Forms::Panel^  panel3;
	private: System::Windows::Forms::CheckBox^  cb_forclick;
	private: System::Windows::Forms::CheckBox^  cb_zoomin;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  LangToolStripMenuItem;

	private: System::Windows::Forms::ToolStripMenuItem^  englishToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  JapaneseToolStripMenuItem;
	private: System::Windows::Forms::PictureBox^  pictureBoxDone;
	private: System::Windows::Forms::CheckBox^  cb_usebinval;
	private: System::Windows::Forms::Button^  b_result_to_clip;
	private: System::Windows::Forms::Button^  b_anal_result_to_clip;
	private: System::Windows::Forms::Panel^  panel4;
private: System::Windows::Forms::GroupBox^  gb_referencepoint;
private: System::Windows::Forms::Label^  label37;
private: System::Windows::Forms::Button^  button1;
private: System::Windows::Forms::Button^  button2;
private: System::Windows::Forms::CheckBox^  cb_showrefpoint;
private: System::Windows::Forms::CheckBox^  cb_save_refpoint;
private: System::Windows::Forms::Label^  label39;
private: System::Windows::Forms::CheckBox^  cb_writebinary;






	private: System::Windows::Forms::Button^  b_clearroi;


	public: 

		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: ここにコンストラクター コードを追加します
			//

			////////////////////////////////
			/*Initialization of Variables*/
			///////////////////////////////
			//変更するとすれば、ここの初期値。
			//いろいろ変わります。
			////////////////////////////////

			/*Flags*/
			video_set = false;
			iframe_now = 0;
			background_set = false;

			show_box_area = false;

			bcgd1st_set = false;
			bcgd2nd_set = false;
			bcgd3rd_set = false;

			setting_box_area = false;
			drawing_box_area = false;
			box_area_set = false;

			setting_reference_point = false;//3.1 eijwat
			drawing_reference_point = false;//3.1 eijwat
			reference_point_set = false;//3.1 eijwat

			refpoint.x = 0; refpoint.y = 0;//3.1 eijwat

			setting_roi = false;
			drawing_roi = false;
			roi_set = false;
			roi_x_set = false;
			roi_y_set = false;
			roi_width_set = false;
			roi_height_set = false;

			/*Box Size*/
			boxarea_realsize.x = 150;
			boxarea_realsize.y = 150;


			/*Colors*/
			ROI_color.push_back(CV_RGB(255,0,0));
			ROI_color.push_back(CV_RGB(255,255,128));
			ROI_color.push_back(CV_RGB(128,255,0));
			ROI_color.push_back(CV_RGB(64,128,128));
			ROI_color.push_back(CV_RGB(150,190,0));

			/*Trackbar*/
			trackbarImg = cv::Mat::ones(pictureBox_trackbar->Height, pictureBox_trackbar->Width, CV_8UC3);
			cv::rectangle(trackbarImg,cv::Rect(cv::Point(0,0),trackbarImg.size()),CV_RGB(255,255,255),-1);
			
			/*Selecting the target frames*/
			target_frame_set = false;
			sttime = 0;
			lsttime = 0;
			sttime_mdown = false;
			on_done_frames = false;

			/*Determining size*/
			setting_size = false;
			size_fish = 300;
			bin_threshold = 1;
			blur_sigma = 0.01;
			size_set = false;

			/*Tracking*/
			tracking_done= false;
			tracking_now =false;
			tracking_cancelled = false;
			jump_i = 0;

			
		}

	protected:
		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}



	private: System::Windows::Forms::PictureBox^  pictureBox;

	private: System::Windows::Forms::RichTextBox^  log_viewer;

	private: System::Windows::Forms::Button^  b_play;
	private: System::Windows::Forms::Button^  b_backward;

	private: System::Windows::Forms::Button^  b_forward;
	private: System::Windows::Forms::Button^  b_skip_back;

	private: System::Windows::Forms::Button^  b_skip_ahead;
	private: System::Windows::Forms::Panel^  panel_playercontrol;

	private: System::Windows::Forms::TrackBar^  trackBar;

	private: System::Windows::Forms::ProgressBar^  progressBar;
	private: System::Windows::Forms::GroupBox^  gb_speedcontrol;

	private: System::Windows::Forms::RadioButton^  radio_pspeed_fast;
	private: System::Windows::Forms::RadioButton^  radio_pspeed_norm;
	private: System::Windows::Forms::RadioButton^  radio_pspeed_slow;
	private: System::Windows::Forms::CheckBox^  checkBox_showoriginal;

	private: System::Windows::Forms::PictureBox^  pictureBox_trackbar;
	public protected: System::Windows::Forms::GroupBox^  gb_ROI;

	private: System::Windows::Forms::ComboBox^  comboBox_ROI;

	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::TextBox^  textBox_roi_height;
	private: System::Windows::Forms::TextBox^  textBox_roi_width;
	private: System::Windows::Forms::TextBox^  textBox_roi_lty;
	private: System::Windows::Forms::TextBox^  textBox_roi_ltx;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label18;
	private: System::Windows::Forms::Button^  b_addROI;

	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Do not modify !!!
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->gb_ROI = (gcnew System::Windows::Forms::GroupBox());
			this->b_clearroi = (gcnew System::Windows::Forms::Button());
			this->comboBox_ROI = (gcnew System::Windows::Forms::ComboBox());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->textBox_roi_height = (gcnew System::Windows::Forms::TextBox());
			this->textBox_roi_width = (gcnew System::Windows::Forms::TextBox());
			this->textBox_roi_lty = (gcnew System::Windows::Forms::TextBox());
			this->textBox_roi_ltx = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->b_addROI = (gcnew System::Windows::Forms::Button());
			this->b_save_roianal = (gcnew System::Windows::Forms::Button());
			this->tb_head_angle = (gcnew System::Windows::Forms::TextBox());
			this->tb_anal_head_only = (gcnew System::Windows::Forms::TextBox());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->tb_anal_numframes = (gcnew System::Windows::Forms::TextBox());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->b_execanal = (gcnew System::Windows::Forms::Button());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->tb_roiangle = (gcnew System::Windows::Forms::TextBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->rb_roibottom = (gcnew System::Windows::Forms::RadioButton());
			this->rb_roileft = (gcnew System::Windows::Forms::RadioButton());
			this->rb_roiright = (gcnew System::Windows::Forms::RadioButton());
			this->rb_roitop = (gcnew System::Windows::Forms::RadioButton());
			this->label_barright = (gcnew System::Windows::Forms::Label());
			this->label_barleft = (gcnew System::Windows::Forms::Label());
			this->label_barbottom = (gcnew System::Windows::Forms::Label());
			this->label_bartop = (gcnew System::Windows::Forms::Label());
			this->comboBox_roianal = (gcnew System::Windows::Forms::ComboBox());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->b_debug = (gcnew System::Windows::Forms::Button());
			this->pictureBox = (gcnew System::Windows::Forms::PictureBox());
			this->log_viewer = (gcnew System::Windows::Forms::RichTextBox());
			this->b_play = (gcnew System::Windows::Forms::Button());
			this->b_backward = (gcnew System::Windows::Forms::Button());
			this->b_forward = (gcnew System::Windows::Forms::Button());
			this->b_skip_back = (gcnew System::Windows::Forms::Button());
			this->b_skip_ahead = (gcnew System::Windows::Forms::Button());
			this->panel_playercontrol = (gcnew System::Windows::Forms::Panel());
			this->trackBar = (gcnew System::Windows::Forms::TrackBar());
			this->progressBar = (gcnew System::Windows::Forms::ProgressBar());
			this->gb_speedcontrol = (gcnew System::Windows::Forms::GroupBox());
			this->radio_pspeed_fast = (gcnew System::Windows::Forms::RadioButton());
			this->radio_pspeed_norm = (gcnew System::Windows::Forms::RadioButton());
			this->radio_pspeed_slow = (gcnew System::Windows::Forms::RadioButton());
			this->checkBox_showoriginal = (gcnew System::Windows::Forms::CheckBox());
			this->pictureBox_trackbar = (gcnew System::Windows::Forms::PictureBox());
			this->cb_showboxarea = (gcnew System::Windows::Forms::CheckBox());
			this->cb_showroi = (gcnew System::Windows::Forms::CheckBox());
			this->timer = (gcnew System::Windows::Forms::Timer(this->components));
			this->bgworker_tracking = (gcnew System::ComponentModel::BackgroundWorker());
			this->checkBox_showmarkers = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->b_anal_result_to_clip = (gcnew System::Windows::Forms::Button());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label_heightarea = (gcnew System::Windows::Forms::Label());
			this->label_widtharea = (gcnew System::Windows::Forms::Label());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->gb_saveparam = (gcnew System::Windows::Forms::GroupBox());
			this->cb_save_refpoint = (gcnew System::Windows::Forms::CheckBox());
			this->cb_boxarea_real = (gcnew System::Windows::Forms::CheckBox());
			this->tb_exp_date = (gcnew System::Windows::Forms::TextBox());
			this->cb_numjoints = (gcnew System::Windows::Forms::CheckBox());
			this->cb_fish_size = (gcnew System::Windows::Forms::CheckBox());
			this->cb_roinum_area = (gcnew System::Windows::Forms::CheckBox());
			this->cb_box_area = (gcnew System::Windows::Forms::CheckBox());
			this->cb_videofile_name = (gcnew System::Windows::Forms::CheckBox());
			this->cb_date_exp = (gcnew System::Windows::Forms::CheckBox());
			this->b_saveparamfile = (gcnew System::Windows::Forms::Button());
			this->gb_writingvideo = (gcnew System::Windows::Forms::GroupBox());
			this->gb_writeoption = (gcnew System::Windows::Forms::GroupBox());
			this->cb_writebinary = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writeroi = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writeoriginal = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writebox = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writehead = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writejoint = (gcnew System::Windows::Forms::CheckBox());
			this->cb_writetail = (gcnew System::Windows::Forms::CheckBox());
			this->b_savemarksonoriginal = (gcnew System::Windows::Forms::Button());
			this->gb_saveresult = (gcnew System::Windows::Forms::GroupBox());
			this->b_result_to_clip = (gcnew System::Windows::Forms::Button());
			this->gb_saving_as = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton_csv = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton_txt = (gcnew System::Windows::Forms::RadioButton());
			this->b_saveresultdata = (gcnew System::Windows::Forms::Button());
			this->tab_tracking = (gcnew System::Windows::Forms::TabPage());
			this->gb_referencepoint = (gcnew System::Windows::Forms::GroupBox());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->gb_detecterror = (gcnew System::Windows::Forms::GroupBox());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->b_detecterror = (gcnew System::Windows::Forms::Button());
			this->gb_determinesize = (gcnew System::Windows::Forms::GroupBox());
			this->b_check = (gcnew System::Windows::Forms::Button());
			this->trackBar_sizebinary = (gcnew System::Windows::Forms::TrackBar());
			this->b_setsize = (gcnew System::Windows::Forms::Button());
			this->b_startsize = (gcnew System::Windows::Forms::Button());
			this->gb_boxarea = (gcnew System::Windows::Forms::GroupBox());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->textBox_boxarea_height = (gcnew System::Windows::Forms::TextBox());
			this->textBox_boxarea_width = (gcnew System::Windows::Forms::TextBox());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->b_set_boxarea = (gcnew System::Windows::Forms::Button());
			this->gb_bonecalc = (gcnew System::Windows::Forms::GroupBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->b_getbone_all = (gcnew System::Windows::Forms::Button());
			this->b_getbone_frame = (gcnew System::Windows::Forms::Button());
			this->gb_tracking = (gcnew System::Windows::Forms::GroupBox());
			this->cb_usebinval = (gcnew System::Windows::Forms::CheckBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->track_num_joint_points = (gcnew System::Windows::Forms::NumericUpDown());
			this->b_track_exec = (gcnew System::Windows::Forms::Button());
			this->gb_smoothing = (gcnew System::Windows::Forms::GroupBox());
			this->smoothing_param_beta = (gcnew System::Windows::Forms::NumericUpDown());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->smoothing_param_alpha = (gcnew System::Windows::Forms::NumericUpDown());
			this->smoothing_param_seq_length = (gcnew System::Windows::Forms::NumericUpDown());
			this->b_smooth_exec = (gcnew System::Windows::Forms::Button());
			this->tab_load = (gcnew System::Windows::Forms::TabPage());
			this->gb_setparam = (gcnew System::Windows::Forms::GroupBox());
			this->label_readfromsettingfile = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->b_loadparameter = (gcnew System::Windows::Forms::Button());
			this->gb_setbackground = (gcnew System::Windows::Forms::GroupBox());
			this->label_bcgdimagename = (gcnew System::Windows::Forms::Label());
			this->gb_createbackground = (gcnew System::Windows::Forms::GroupBox());
			this->b_savebcgdimage = (gcnew System::Windows::Forms::Button());
			this->b_1stimage = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->b_2ndimage = (gcnew System::Windows::Forms::Button());
			this->b_showbackground = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->b_3rdimage = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->b_createbackground = (gcnew System::Windows::Forms::Button());
			this->b_loadbackground = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label_videofilename = (gcnew System::Windows::Forms::Label());
			this->b_loadvideofile = (gcnew System::Windows::Forms::Button());
			this->tab = (gcnew System::Windows::Forms::TabControl());
			this->bgworker_writevideo = (gcnew System::ComponentModel::BackgroundWorker());
			this->label_time = (gcnew System::Windows::Forms::Label());
			this->label_numframes = (gcnew System::Windows::Forms::Label());
			this->cb_forclick = (gcnew System::Windows::Forms::CheckBox());
			this->cb_zoomin = (gcnew System::Windows::Forms::CheckBox());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->LangToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->englishToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->JapaneseToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pictureBoxDone = (gcnew System::Windows::Forms::PictureBox());
			this->cb_showrefpoint = (gcnew System::Windows::Forms::CheckBox());
			this->gb_ROI->SuspendLayout();
			this->panel1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->BeginInit();
			this->panel_playercontrol->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar))->BeginInit();
			this->gb_speedcontrol->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox_trackbar))->BeginInit();
			this->groupBox3->SuspendLayout();
			this->panel4->SuspendLayout();
			this->panel3->SuspendLayout();
			this->panel2->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->gb_saveparam->SuspendLayout();
			this->gb_writingvideo->SuspendLayout();
			this->gb_writeoption->SuspendLayout();
			this->gb_saveresult->SuspendLayout();
			this->gb_saving_as->SuspendLayout();
			this->tab_tracking->SuspendLayout();
			this->gb_referencepoint->SuspendLayout();
			this->gb_detecterror->SuspendLayout();
			this->gb_determinesize->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_sizebinary))->BeginInit();
			this->gb_boxarea->SuspendLayout();
			this->gb_bonecalc->SuspendLayout();
			this->gb_tracking->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->track_num_joint_points))->BeginInit();
			this->gb_smoothing->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_beta))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_alpha))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_seq_length))->BeginInit();
			this->tab_load->SuspendLayout();
			this->gb_setparam->SuspendLayout();
			this->gb_setbackground->SuspendLayout();
			this->gb_createbackground->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->tab->SuspendLayout();
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBoxDone))->BeginInit();
			this->SuspendLayout();
			// 
			// gb_ROI
			// 
			this->gb_ROI->Controls->Add(this->b_clearroi);
			this->gb_ROI->Controls->Add(this->comboBox_ROI);
			this->gb_ROI->Controls->Add(this->label17);
			this->gb_ROI->Controls->Add(this->label16);
			this->gb_ROI->Controls->Add(this->label15);
			this->gb_ROI->Controls->Add(this->label14);
			this->gb_ROI->Controls->Add(this->textBox_roi_height);
			this->gb_ROI->Controls->Add(this->textBox_roi_width);
			this->gb_ROI->Controls->Add(this->textBox_roi_lty);
			this->gb_ROI->Controls->Add(this->textBox_roi_ltx);
			this->gb_ROI->Controls->Add(this->label11);
			this->gb_ROI->Controls->Add(this->label12);
			this->gb_ROI->Controls->Add(this->label13);
			this->gb_ROI->Controls->Add(this->label18);
			this->gb_ROI->Controls->Add(this->b_addROI);
			this->gb_ROI->Enabled = false;
			this->gb_ROI->Location = System::Drawing::Point(150, 6);
			this->gb_ROI->Name = L"gb_ROI";
			this->gb_ROI->Size = System::Drawing::Size(320, 111);
			this->gb_ROI->TabIndex = 17;
			this->gb_ROI->TabStop = false;
			this->gb_ROI->Text = L"Region of Interestの設定";
			// 
			// b_clearroi
			// 
			this->b_clearroi->Location = System::Drawing::Point(197, 22);
			this->b_clearroi->Name = L"b_clearroi";
			this->b_clearroi->Size = System::Drawing::Size(104, 23);
			this->b_clearroi->TabIndex = 38;
			this->b_clearroi->Text = L"全消去";
			this->b_clearroi->UseVisualStyleBackColor = true;
			this->b_clearroi->Click += gcnew System::EventHandler(this, &Form1::b_clearroi_Click);
			// 
			// comboBox_ROI
			// 
			this->comboBox_ROI->FormattingEnabled = true;
			this->comboBox_ROI->Location = System::Drawing::Point(116, 24);
			this->comboBox_ROI->Name = L"comboBox_ROI";
			this->comboBox_ROI->Size = System::Drawing::Size(53, 20);
			this->comboBox_ROI->TabIndex = 36;
			this->comboBox_ROI->SelectedValueChanged += gcnew System::EventHandler(this, &Form1::comboBox_ROI_SelectedValueChanged);
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(268, 88);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(23, 12);
			this->label17->TabIndex = 35;
			this->label17->Text = L"mm";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(139, 87);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(23, 12);
			this->label16->TabIndex = 34;
			this->label16->Text = L"mm";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(269, 59);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(23, 12);
			this->label15->TabIndex = 33;
			this->label15->Text = L"mm";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(139, 61);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(23, 12);
			this->label14->TabIndex = 32;
			this->label14->Text = L"mm";
			// 
			// textBox_roi_height
			// 
			this->textBox_roi_height->Location = System::Drawing::Point(213, 84);
			this->textBox_roi_height->Name = L"textBox_roi_height";
			this->textBox_roi_height->Size = System::Drawing::Size(49, 19);
			this->textBox_roi_height->TabIndex = 26;
			this->textBox_roi_height->Text = L"0";
			this->textBox_roi_height->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_roi_height->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_roi_height_PreviewKeyDown);
			// 
			// textBox_roi_width
			// 
			this->textBox_roi_width->Location = System::Drawing::Point(86, 83);
			this->textBox_roi_width->Name = L"textBox_roi_width";
			this->textBox_roi_width->Size = System::Drawing::Size(47, 19);
			this->textBox_roi_width->TabIndex = 25;
			this->textBox_roi_width->Text = L"0";
			this->textBox_roi_width->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_roi_width->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_roi_width_PreviewKeyDown);
			// 
			// textBox_roi_lty
			// 
			this->textBox_roi_lty->Location = System::Drawing::Point(213, 58);
			this->textBox_roi_lty->Name = L"textBox_roi_lty";
			this->textBox_roi_lty->Size = System::Drawing::Size(49, 19);
			this->textBox_roi_lty->TabIndex = 24;
			this->textBox_roi_lty->Text = L"0";
			this->textBox_roi_lty->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_roi_lty->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_roi_lty_PreviewKeyDown);
			// 
			// textBox_roi_ltx
			// 
			this->textBox_roi_ltx->BackColor = System::Drawing::SystemColors::Window;
			this->textBox_roi_ltx->Location = System::Drawing::Point(86, 58);
			this->textBox_roi_ltx->Name = L"textBox_roi_ltx";
			this->textBox_roi_ltx->Size = System::Drawing::Size(47, 19);
			this->textBox_roi_ltx->TabIndex = 23;
			this->textBox_roi_ltx->Text = L"0";
			this->textBox_roi_ltx->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_roi_ltx->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_roi_ltx_PreviewKeyDown);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(168, 88);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(40, 12);
			this->label11->TabIndex = 22;
			this->label11->Text = L"Height:";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(44, 86);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(35, 12);
			this->label12->TabIndex = 21;
			this->label12->Text = L"Width:";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(188, 62);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(13, 12);
			this->label13->TabIndex = 20;
			this->label13->Text = L"y:";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(20, 62);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(60, 12);
			this->label18->TabIndex = 19;
			this->label18->Text = L"Left Top x:";
			// 
			// b_addROI
			// 
			this->b_addROI->Location = System::Drawing::Point(22, 22);
			this->b_addROI->Name = L"b_addROI";
			this->b_addROI->Size = System::Drawing::Size(88, 23);
			this->b_addROI->TabIndex = 18;
			this->b_addROI->Text = L"ROI追加";
			this->b_addROI->UseVisualStyleBackColor = true;
			this->b_addROI->Click += gcnew System::EventHandler(this, &Form1::b_addROI_Click);
			// 
			// b_save_roianal
			// 
			this->b_save_roianal->Enabled = false;
			this->b_save_roianal->Location = System::Drawing::Point(3, 6);
			this->b_save_roianal->Name = L"b_save_roianal";
			this->b_save_roianal->Size = System::Drawing::Size(92, 23);
			this->b_save_roianal->TabIndex = 21;
			this->b_save_roianal->Text = L"解析結果保存";
			this->b_save_roianal->UseVisualStyleBackColor = true;
			this->b_save_roianal->Click += gcnew System::EventHandler(this, &Form1::b_save_roianal_Click);
			// 
			// tb_head_angle
			// 
			this->tb_head_angle->Location = System::Drawing::Point(322, 76);
			this->tb_head_angle->Name = L"tb_head_angle";
			this->tb_head_angle->Size = System::Drawing::Size(59, 19);
			this->tb_head_angle->TabIndex = 20;
			this->tb_head_angle->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// tb_anal_head_only
			// 
			this->tb_anal_head_only->Location = System::Drawing::Point(322, 45);
			this->tb_anal_head_only->Name = L"tb_anal_head_only";
			this->tb_anal_head_only->Size = System::Drawing::Size(59, 19);
			this->tb_anal_head_only->TabIndex = 19;
			this->tb_anal_head_only->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(210, 79);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(216, 12);
			this->label35->TabIndex = 18;
			this->label35->Text = L"頭部・角度が範囲内： 　　　　　　　　フレーム";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(245, 49);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(181, 12);
			this->label34->TabIndex = 17;
			this->label34->Text = L"頭部がROI内：　　 　　　　　　フレーム";
			// 
			// tb_anal_numframes
			// 
			this->tb_anal_numframes->Location = System::Drawing::Point(229, 17);
			this->tb_anal_numframes->Name = L"tb_anal_numframes";
			this->tb_anal_numframes->Size = System::Drawing::Size(67, 19);
			this->tb_anal_numframes->TabIndex = 16;
			this->tb_anal_numframes->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(173, 20);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(188, 12);
			this->label33->TabIndex = 15;
			this->label33->Text = L"解析対象　　　　　　　  　　フレーム中：";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(10, 7);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(59, 12);
			this->label32->TabIndex = 14;
			this->label32->Text = L"解析結果：";
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->label30);
			this->panel1->Controls->Add(this->label31);
			this->panel1->Controls->Add(this->label26);
			this->panel1->Controls->Add(this->label27);
			this->panel1->Controls->Add(this->label29);
			this->panel1->Controls->Add(this->label28);
			this->panel1->Location = System::Drawing::Point(12, 39);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(159, 53);
			this->panel1->TabIndex = 13;
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->BackColor = System::Drawing::Color::Yellow;
			this->label30->Location = System::Drawing::Point(12, 37);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(13, 12);
			this->label30->TabIndex = 11;
			this->label30->Text = L"  ";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(31, 37);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(126, 12);
			this->label31->TabIndex = 12;
			this->label31->Text = L"頭部ROI内・角度範囲内";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->BackColor = System::Drawing::Color::Black;
			this->label26->Location = System::Drawing::Point(12, 5);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 12);
			this->label26->TabIndex = 7;
			this->label26->Text = L"  ";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(31, 5);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(36, 12);
			this->label27->TabIndex = 8;
			this->label27->Text = L"ROI外";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(31, 21);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(60, 12);
			this->label29->TabIndex = 10;
			this->label29->Text = L"頭部ROI内";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->BackColor = System::Drawing::Color::Red;
			this->label28->Location = System::Drawing::Point(12, 21);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(13, 12);
			this->label28->TabIndex = 9;
			this->label28->Text = L"  ";
			// 
			// b_execanal
			// 
			this->b_execanal->Enabled = false;
			this->b_execanal->Location = System::Drawing::Point(257, 98);
			this->b_execanal->Name = L"b_execanal";
			this->b_execanal->Size = System::Drawing::Size(92, 23);
			this->b_execanal->TabIndex = 6;
			this->b_execanal->Text = L"解析実行";
			this->b_execanal->UseVisualStyleBackColor = true;
			this->b_execanal->Click += gcnew System::EventHandler(this, &Form1::b_execanal_Click);
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(388, 57);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(17, 12);
			this->label25->TabIndex = 5;
			this->label25->Text = L"°";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(278, 57);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(71, 12);
			this->label24->TabIndex = 4;
			this->label24->Text = L"角度範囲: ±";
			// 
			// tb_roiangle
			// 
			this->tb_roiangle->Location = System::Drawing::Point(346, 54);
			this->tb_roiangle->Name = L"tb_roiangle";
			this->tb_roiangle->Size = System::Drawing::Size(36, 19);
			this->tb_roiangle->TabIndex = 3;
			this->tb_roiangle->Text = L"30.0";
			this->tb_roiangle->TextChanged += gcnew System::EventHandler(this, &Form1::tb_roiangle_TextChanged);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->rb_roibottom);
			this->groupBox2->Controls->Add(this->rb_roileft);
			this->groupBox2->Controls->Add(this->rb_roiright);
			this->groupBox2->Controls->Add(this->rb_roitop);
			this->groupBox2->Controls->Add(this->label_barright);
			this->groupBox2->Controls->Add(this->label_barleft);
			this->groupBox2->Controls->Add(this->label_barbottom);
			this->groupBox2->Controls->Add(this->label_bartop);
			this->groupBox2->Location = System::Drawing::Point(13, 56);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(230, 128);
			this->groupBox2->TabIndex = 2;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"対象辺の指定";
			// 
			// rb_roibottom
			// 
			this->rb_roibottom->AutoSize = true;
			this->rb_roibottom->Location = System::Drawing::Point(99, 107);
			this->rb_roibottom->Name = L"rb_roibottom";
			this->rb_roibottom->Size = System::Drawing::Size(35, 16);
			this->rb_roibottom->TabIndex = 7;
			this->rb_roibottom->Text = L"下";
			this->rb_roibottom->UseVisualStyleBackColor = true;
			this->rb_roibottom->CheckedChanged += gcnew System::EventHandler(this, &Form1::rb_roibottom_CheckedChanged);
			// 
			// rb_roileft
			// 
			this->rb_roileft->AutoSize = true;
			this->rb_roileft->Location = System::Drawing::Point(5, 64);
			this->rb_roileft->Name = L"rb_roileft";
			this->rb_roileft->Size = System::Drawing::Size(35, 16);
			this->rb_roileft->TabIndex = 6;
			this->rb_roileft->Text = L"左";
			this->rb_roileft->UseVisualStyleBackColor = true;
			this->rb_roileft->CheckedChanged += gcnew System::EventHandler(this, &Form1::rb_roileft_CheckedChanged);
			// 
			// rb_roiright
			// 
			this->rb_roiright->AutoSize = true;
			this->rb_roiright->Location = System::Drawing::Point(189, 64);
			this->rb_roiright->Name = L"rb_roiright";
			this->rb_roiright->Size = System::Drawing::Size(35, 16);
			this->rb_roiright->TabIndex = 5;
			this->rb_roiright->Text = L"右";
			this->rb_roiright->UseVisualStyleBackColor = true;
			this->rb_roiright->CheckedChanged += gcnew System::EventHandler(this, &Form1::rb_roiright_CheckedChanged);
			// 
			// rb_roitop
			// 
			this->rb_roitop->AutoSize = true;
			this->rb_roitop->Checked = true;
			this->rb_roitop->Location = System::Drawing::Point(98, 20);
			this->rb_roitop->Name = L"rb_roitop";
			this->rb_roitop->Size = System::Drawing::Size(35, 16);
			this->rb_roitop->TabIndex = 4;
			this->rb_roitop->TabStop = true;
			this->rb_roitop->Text = L"上";
			this->rb_roitop->UseVisualStyleBackColor = true;
			this->rb_roitop->CheckedChanged += gcnew System::EventHandler(this, &Form1::rb_roitop_CheckedChanged);
			// 
			// label_barright
			// 
			this->label_barright->AutoSize = true;
			this->label_barright->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label_barright->Location = System::Drawing::Point(173, 42);
			this->label_barright->Name = L"label_barright";
			this->label_barright->Size = System::Drawing::Size(17, 60);
			this->label_barright->TabIndex = 3;
			this->label_barright->Text = L"｜\n｜\n｜\n｜\n｜";
			// 
			// label_barleft
			// 
			this->label_barleft->AutoSize = true;
			this->label_barleft->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label_barleft->Location = System::Drawing::Point(46, 41);
			this->label_barleft->Name = L"label_barleft";
			this->label_barleft->Size = System::Drawing::Size(17, 60);
			this->label_barleft->TabIndex = 2;
			this->label_barleft->Text = L"｜\n｜\n｜\n｜\n｜";
			// 
			// label_barbottom
			// 
			this->label_barbottom->AutoSize = true;
			this->label_barbottom->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			this->label_barbottom->Location = System::Drawing::Point(51, 91);
			this->label_barbottom->Name = L"label_barbottom";
			this->label_barbottom->Size = System::Drawing::Size(133, 12);
			this->label_barbottom->TabIndex = 1;
			this->label_barbottom->Text = L"________________________________";
			// 
			// label_bartop
			// 
			this->label_bartop->AutoSize = true;
			this->label_bartop->ForeColor = System::Drawing::Color::Blue;
			this->label_bartop->Location = System::Drawing::Point(51, 29);
			this->label_bartop->Name = L"label_bartop";
			this->label_bartop->Size = System::Drawing::Size(133, 12);
			this->label_bartop->TabIndex = 0;
			this->label_bartop->Text = L"________________________________";
			// 
			// comboBox_roianal
			// 
			this->comboBox_roianal->FormattingEnabled = true;
			this->comboBox_roianal->Location = System::Drawing::Point(58, 6);
			this->comboBox_roianal->Name = L"comboBox_roianal";
			this->comboBox_roianal->Size = System::Drawing::Size(61, 20);
			this->comboBox_roianal->TabIndex = 1;
			this->comboBox_roianal->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox_roianal_SelectedIndexChanged);
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(3, 9);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(50, 12);
			this->label23->TabIndex = 0;
			this->label23->Text = L"対象ROI:";
			// 
			// b_debug
			// 
			this->b_debug->Enabled = false;
			this->b_debug->Location = System::Drawing::Point(497, 603);
			this->b_debug->Name = L"b_debug";
			this->b_debug->Size = System::Drawing::Size(54, 23);
			this->b_debug->TabIndex = 18;
			this->b_debug->TabStop = false;
			this->b_debug->Text = L"debug";
			this->b_debug->UseVisualStyleBackColor = true;
			this->b_debug->Visible = false;
			this->b_debug->Click += gcnew System::EventHandler(this, &Form1::b_debug_Click);
			// 
			// pictureBox
			// 
			this->pictureBox->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->pictureBox->Location = System::Drawing::Point(501, 27);
			this->pictureBox->Name = L"pictureBox";
			this->pictureBox->Size = System::Drawing::Size(640, 480);
			this->pictureBox->TabIndex = 1;
			this->pictureBox->TabStop = false;
			this->pictureBox->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox_MouseDown);
			this->pictureBox->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox_MouseMove);
			this->pictureBox->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBox_MouseUp);
			// 
			// log_viewer
			// 
			this->log_viewer->Location = System::Drawing::Point(15, 27);
			this->log_viewer->Name = L"log_viewer";
			this->log_viewer->Size = System::Drawing::Size(476, 125);
			this->log_viewer->TabIndex = 2;
			this->log_viewer->Text = L"";
			// 
			// b_play
			// 
			this->b_play->Location = System::Drawing::Point(171, 3);
			this->b_play->Name = L"b_play";
			this->b_play->Size = System::Drawing::Size(75, 50);
			this->b_play->TabIndex = 3;
			this->b_play->Text = L"Play";
			this->b_play->UseVisualStyleBackColor = true;
			this->b_play->Click += gcnew System::EventHandler(this, &Form1::b_play_Click);
			// 
			// b_backward
			// 
			this->b_backward->Location = System::Drawing::Point(90, 3);
			this->b_backward->Name = L"b_backward";
			this->b_backward->Size = System::Drawing::Size(75, 50);
			this->b_backward->TabIndex = 4;
			this->b_backward->Text = L"<";
			this->b_backward->UseVisualStyleBackColor = true;
			this->b_backward->Click += gcnew System::EventHandler(this, &Form1::b_backward_Click);
			// 
			// b_forward
			// 
			this->b_forward->Location = System::Drawing::Point(252, 3);
			this->b_forward->Name = L"b_forward";
			this->b_forward->Size = System::Drawing::Size(75, 50);
			this->b_forward->TabIndex = 5;
			this->b_forward->Text = L">";
			this->b_forward->UseVisualStyleBackColor = true;
			this->b_forward->Click += gcnew System::EventHandler(this, &Form1::b_forward_Click);
			// 
			// b_skip_back
			// 
			this->b_skip_back->Enabled = false;
			this->b_skip_back->Location = System::Drawing::Point(9, 3);
			this->b_skip_back->Name = L"b_skip_back";
			this->b_skip_back->Size = System::Drawing::Size(75, 50);
			this->b_skip_back->TabIndex = 6;
			this->b_skip_back->Text = L"Previous\r\n  Error";
			this->b_skip_back->UseVisualStyleBackColor = true;
			this->b_skip_back->Click += gcnew System::EventHandler(this, &Form1::b_skip_back_Click);
			// 
			// b_skip_ahead
			// 
			this->b_skip_ahead->Enabled = false;
			this->b_skip_ahead->Location = System::Drawing::Point(333, 3);
			this->b_skip_ahead->Name = L"b_skip_ahead";
			this->b_skip_ahead->Size = System::Drawing::Size(75, 50);
			this->b_skip_ahead->TabIndex = 7;
			this->b_skip_ahead->Text = L"Next\r\n Error";
			this->b_skip_ahead->UseVisualStyleBackColor = true;
			this->b_skip_ahead->Click += gcnew System::EventHandler(this, &Form1::b_skip_ahead_Click);
			// 
			// panel_playercontrol
			// 
			this->panel_playercontrol->Controls->Add(this->b_play);
			this->panel_playercontrol->Controls->Add(this->b_skip_ahead);
			this->panel_playercontrol->Controls->Add(this->b_forward);
			this->panel_playercontrol->Controls->Add(this->b_backward);
			this->panel_playercontrol->Controls->Add(this->b_skip_back);
			this->panel_playercontrol->Enabled = false;
			this->panel_playercontrol->Location = System::Drawing::Point(561, 603);
			this->panel_playercontrol->Name = L"panel_playercontrol";
			this->panel_playercontrol->Size = System::Drawing::Size(421, 57);
			this->panel_playercontrol->TabIndex = 8;
			// 
			// trackBar
			// 
			this->trackBar->Enabled = false;
			this->trackBar->Location = System::Drawing::Point(501, 552);
			this->trackBar->Name = L"trackBar";
			this->trackBar->Size = System::Drawing::Size(640, 45);
			this->trackBar->TabIndex = 9;
			this->trackBar->Scroll += gcnew System::EventHandler(this, &Form1::trackBar_Scroll);
			this->trackBar->ValueChanged += gcnew System::EventHandler(this, &Form1::trackBar_ValueChanged);
			// 
			// progressBar
			// 
			this->progressBar->Location = System::Drawing::Point(15, 159);
			this->progressBar->Name = L"progressBar";
			this->progressBar->Size = System::Drawing::Size(476, 35);
			this->progressBar->TabIndex = 10;
			// 
			// gb_speedcontrol
			// 
			this->gb_speedcontrol->Controls->Add(this->radio_pspeed_fast);
			this->gb_speedcontrol->Controls->Add(this->radio_pspeed_norm);
			this->gb_speedcontrol->Controls->Add(this->radio_pspeed_slow);
			this->gb_speedcontrol->Enabled = false;
			this->gb_speedcontrol->Location = System::Drawing::Point(991, 591);
			this->gb_speedcontrol->Name = L"gb_speedcontrol";
			this->gb_speedcontrol->Size = System::Drawing::Size(109, 91);
			this->gb_speedcontrol->TabIndex = 11;
			this->gb_speedcontrol->TabStop = false;
			this->gb_speedcontrol->Text = L"再生速度";
			// 
			// radio_pspeed_fast
			// 
			this->radio_pspeed_fast->AutoSize = true;
			this->radio_pspeed_fast->Location = System::Drawing::Point(21, 65);
			this->radio_pspeed_fast->Name = L"radio_pspeed_fast";
			this->radio_pspeed_fast->Size = System::Drawing::Size(46, 16);
			this->radio_pspeed_fast->TabIndex = 2;
			this->radio_pspeed_fast->Text = L"Fast";
			this->radio_pspeed_fast->UseVisualStyleBackColor = true;
			this->radio_pspeed_fast->CheckedChanged += gcnew System::EventHandler(this, &Form1::radio_pspeed_fast_CheckedChanged);
			// 
			// radio_pspeed_norm
			// 
			this->radio_pspeed_norm->AutoSize = true;
			this->radio_pspeed_norm->Checked = true;
			this->radio_pspeed_norm->Location = System::Drawing::Point(21, 42);
			this->radio_pspeed_norm->Name = L"radio_pspeed_norm";
			this->radio_pspeed_norm->Size = System::Drawing::Size(59, 16);
			this->radio_pspeed_norm->TabIndex = 1;
			this->radio_pspeed_norm->TabStop = true;
			this->radio_pspeed_norm->Text = L"Normal";
			this->radio_pspeed_norm->UseVisualStyleBackColor = true;
			this->radio_pspeed_norm->CheckedChanged += gcnew System::EventHandler(this, &Form1::radio_pspeed_norm_CheckedChanged);
			// 
			// radio_pspeed_slow
			// 
			this->radio_pspeed_slow->AutoSize = true;
			this->radio_pspeed_slow->Location = System::Drawing::Point(21, 19);
			this->radio_pspeed_slow->Name = L"radio_pspeed_slow";
			this->radio_pspeed_slow->Size = System::Drawing::Size(47, 16);
			this->radio_pspeed_slow->TabIndex = 0;
			this->radio_pspeed_slow->Text = L"Slow";
			this->radio_pspeed_slow->UseVisualStyleBackColor = true;
			this->radio_pspeed_slow->CheckedChanged += gcnew System::EventHandler(this, &Form1::radio_pspeed_slow_CheckedChanged);
			// 
			// checkBox_showoriginal
			// 
			this->checkBox_showoriginal->AutoSize = true;
			this->checkBox_showoriginal->Checked = true;
			this->checkBox_showoriginal->CheckState = System::Windows::Forms::CheckState::Checked;
			this->checkBox_showoriginal->Location = System::Drawing::Point(549, 666);
			this->checkBox_showoriginal->Name = L"checkBox_showoriginal";
			this->checkBox_showoriginal->Size = System::Drawing::Size(72, 16);
			this->checkBox_showoriginal->TabIndex = 17;
			this->checkBox_showoriginal->Text = L"動画表示";
			this->checkBox_showoriginal->UseVisualStyleBackColor = true;
			this->checkBox_showoriginal->CheckedChanged += gcnew System::EventHandler(this, &Form1::checkBox_showorigin_CheckedChanged);
			// 
			// pictureBox_trackbar
			// 
			this->pictureBox_trackbar->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBox_trackbar->Location = System::Drawing::Point(510, 531);
			this->pictureBox_trackbar->Name = L"pictureBox_trackbar";
			this->pictureBox_trackbar->Size = System::Drawing::Size(623, 15);
			this->pictureBox_trackbar->TabIndex = 18;
			this->pictureBox_trackbar->TabStop = false;
			// 
			// cb_showboxarea
			// 
			this->cb_showboxarea->AutoSize = true;
			this->cb_showboxarea->Enabled = false;
			this->cb_showboxarea->Location = System::Drawing::Point(635, 666);
			this->cb_showboxarea->Name = L"cb_showboxarea";
			this->cb_showboxarea->Size = System::Drawing::Size(96, 16);
			this->cb_showboxarea->TabIndex = 19;
			this->cb_showboxarea->Text = L"水槽領域表示";
			this->cb_showboxarea->UseVisualStyleBackColor = true;
			this->cb_showboxarea->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_showboxarea_CheckedChanged);
			// 
			// cb_showroi
			// 
			this->cb_showroi->AutoSize = true;
			this->cb_showroi->Enabled = false;
			this->cb_showroi->Location = System::Drawing::Point(839, 666);
			this->cb_showroi->Name = L"cb_showroi";
			this->cb_showroi->Size = System::Drawing::Size(67, 16);
			this->cb_showroi->TabIndex = 20;
			this->cb_showroi->Text = L"ROI表示";
			this->cb_showroi->UseVisualStyleBackColor = true;
			this->cb_showroi->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_showroi_CheckedChanged);
			// 
			// timer
			// 
			this->timer->Interval = 50;
			this->timer->Tick += gcnew System::EventHandler(this, &Form1::timer_Tick);
			// 
			// bgworker_tracking
			// 
			this->bgworker_tracking->WorkerReportsProgress = true;
			this->bgworker_tracking->WorkerSupportsCancellation = true;
			this->bgworker_tracking->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::bgworker_tracking_DoWork);
			this->bgworker_tracking->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::bgworker_tracking_ProgressChanged);
			this->bgworker_tracking->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::bgworker_tracking_RunWorkerCompleted);
			// 
			// checkBox_showmarkers
			// 
			this->checkBox_showmarkers->AutoSize = true;
			this->checkBox_showmarkers->Enabled = false;
			this->checkBox_showmarkers->Location = System::Drawing::Point(741, 666);
			this->checkBox_showmarkers->Name = L"checkBox_showmarkers";
			this->checkBox_showmarkers->Size = System::Drawing::Size(86, 16);
			this->checkBox_showmarkers->TabIndex = 21;
			this->checkBox_showmarkers->Text = L"マーカー表示";
			this->checkBox_showmarkers->UseVisualStyleBackColor = true;
			this->checkBox_showmarkers->CheckedChanged += gcnew System::EventHandler(this, &Form1::checkBox_showmarkers_CheckedChanged);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->panel4);
			this->groupBox3->Controls->Add(this->panel3);
			this->groupBox3->Controls->Add(this->panel2);
			this->groupBox3->Controls->Add(this->groupBox2);
			this->groupBox3->Controls->Add(this->tb_roiangle);
			this->groupBox3->Controls->Add(this->label24);
			this->groupBox3->Controls->Add(this->label25);
			this->groupBox3->Controls->Add(this->b_execanal);
			this->groupBox3->Enabled = false;
			this->groupBox3->Location = System::Drawing::Point(6, 123);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(457, 311);
			this->groupBox3->TabIndex = 22;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"ROIの解析";
			// 
			// panel4
			// 
			this->panel4->Controls->Add(this->b_save_roianal);
			this->panel4->Controls->Add(this->b_anal_result_to_clip);
			this->panel4->Location = System::Drawing::Point(257, 139);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(191, 33);
			this->panel4->TabIndex = 25;
			// 
			// b_anal_result_to_clip
			// 
			this->b_anal_result_to_clip->Enabled = false;
			this->b_anal_result_to_clip->Location = System::Drawing::Point(101, 6);
			this->b_anal_result_to_clip->Name = L"b_anal_result_to_clip";
			this->b_anal_result_to_clip->Size = System::Drawing::Size(87, 23);
			this->b_anal_result_to_clip->TabIndex = 24;
			this->b_anal_result_to_clip->Text = L"クリップボードへ";
			this->b_anal_result_to_clip->UseVisualStyleBackColor = true;
			this->b_anal_result_to_clip->Click += gcnew System::EventHandler(this, &Form1::b_anal_result_to_clip_Click);
			// 
			// panel3
			// 
			this->panel3->BackColor = System::Drawing::Color::LightGoldenrodYellow;
			this->panel3->Controls->Add(this->comboBox_roianal);
			this->panel3->Controls->Add(this->label23);
			this->panel3->Location = System::Drawing::Point(13, 18);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(126, 33);
			this->panel3->TabIndex = 23;
			// 
			// panel2
			// 
			this->panel2->BackColor = System::Drawing::Color::WhiteSmoke;
			this->panel2->Controls->Add(this->tb_anal_head_only);
			this->panel2->Controls->Add(this->tb_anal_numframes);
			this->panel2->Controls->Add(this->label32);
			this->panel2->Controls->Add(this->panel1);
			this->panel2->Controls->Add(this->label34);
			this->panel2->Controls->Add(this->tb_head_angle);
			this->panel2->Controls->Add(this->label35);
			this->panel2->Controls->Add(this->label33);
			this->panel2->Location = System::Drawing::Point(13, 190);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(441, 106);
			this->panel2->TabIndex = 22;
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->label38);
			this->tabPage2->Controls->Add(this->label_heightarea);
			this->tabPage2->Controls->Add(this->label_widtharea);
			this->tabPage2->Controls->Add(this->groupBox3);
			this->tabPage2->Controls->Add(this->gb_ROI);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(476, 452);
			this->tabPage2->TabIndex = 4;
			this->tabPage2->Text = L"ROI解析";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(11, 6);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(77, 12);
			this->label38->TabIndex = 25;
			this->label38->Text = L"水槽領域実寸";
			// 
			// label_heightarea
			// 
			this->label_heightarea->AutoSize = true;
			this->label_heightarea->Location = System::Drawing::Point(22, 64);
			this->label_heightarea->Name = L"label_heightarea";
			this->label_heightarea->Size = System::Drawing::Size(84, 12);
			this->label_heightarea->TabIndex = 24;
			this->label_heightarea->Text = L"Height: 150 mm";
			// 
			// label_widtharea
			// 
			this->label_widtharea->AutoSize = true;
			this->label_widtharea->Location = System::Drawing::Point(27, 39);
			this->label_widtharea->Name = L"label_widtharea";
			this->label_widtharea->Size = System::Drawing::Size(79, 12);
			this->label_widtharea->TabIndex = 23;
			this->label_widtharea->Text = L"Width: 150 mm";
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->gb_saveparam);
			this->tabPage1->Controls->Add(this->gb_writingvideo);
			this->tabPage1->Controls->Add(this->gb_saveresult);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(476, 452);
			this->tabPage1->TabIndex = 3;
			this->tabPage1->Text = L"結果保存";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// gb_saveparam
			// 
			this->gb_saveparam->Controls->Add(this->cb_save_refpoint);
			this->gb_saveparam->Controls->Add(this->cb_boxarea_real);
			this->gb_saveparam->Controls->Add(this->tb_exp_date);
			this->gb_saveparam->Controls->Add(this->cb_numjoints);
			this->gb_saveparam->Controls->Add(this->cb_fish_size);
			this->gb_saveparam->Controls->Add(this->cb_roinum_area);
			this->gb_saveparam->Controls->Add(this->cb_box_area);
			this->gb_saveparam->Controls->Add(this->cb_videofile_name);
			this->gb_saveparam->Controls->Add(this->cb_date_exp);
			this->gb_saveparam->Controls->Add(this->b_saveparamfile);
			this->gb_saveparam->Enabled = false;
			this->gb_saveparam->Location = System::Drawing::Point(40, 266);
			this->gb_saveparam->Name = L"gb_saveparam";
			this->gb_saveparam->Size = System::Drawing::Size(376, 140);
			this->gb_saveparam->TabIndex = 3;
			this->gb_saveparam->TabStop = false;
			this->gb_saveparam->Text = L"解析情報の保存";
			// 
			// cb_save_refpoint
			// 
			this->cb_save_refpoint->AutoSize = true;
			this->cb_save_refpoint->Enabled = false;
			this->cb_save_refpoint->Location = System::Drawing::Point(134, 109);
			this->cb_save_refpoint->Name = L"cb_save_refpoint";
			this->cb_save_refpoint->Size = System::Drawing::Size(98, 16);
			this->cb_save_refpoint->TabIndex = 10;
			this->cb_save_refpoint->Text = L"基準点 (座標）";
			this->cb_save_refpoint->UseVisualStyleBackColor = true;
			this->cb_save_refpoint->Visible = false;
			// 
			// cb_boxarea_real
			// 
			this->cb_boxarea_real->AutoSize = true;
			this->cb_boxarea_real->Checked = true;
			this->cb_boxarea_real->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_boxarea_real->Location = System::Drawing::Point(154, 38);
			this->cb_boxarea_real->Name = L"cb_boxarea_real";
			this->cb_boxarea_real->Size = System::Drawing::Size(110, 16);
			this->cb_boxarea_real->TabIndex = 9;
			this->cb_boxarea_real->Text = L"水槽領域 (実寸）";
			this->cb_boxarea_real->UseVisualStyleBackColor = true;
			// 
			// tb_exp_date
			// 
			this->tb_exp_date->ForeColor = System::Drawing::SystemColors::WindowText;
			this->tb_exp_date->Location = System::Drawing::Point(21, 60);
			this->tb_exp_date->Name = L"tb_exp_date";
			this->tb_exp_date->Size = System::Drawing::Size(111, 19);
			this->tb_exp_date->TabIndex = 8;
			this->tb_exp_date->Text = L"yyyy/mm/dd";
			this->tb_exp_date->Enter += gcnew System::EventHandler(this, &Form1::tb_exp_date_Enter);
			this->tb_exp_date->Leave += gcnew System::EventHandler(this, &Form1::tb_exp_date_Leave);
			// 
			// cb_numjoints
			// 
			this->cb_numjoints->AutoSize = true;
			this->cb_numjoints->Enabled = false;
			this->cb_numjoints->Location = System::Drawing::Point(21, 109);
			this->cb_numjoints->Name = L"cb_numjoints";
			this->cb_numjoints->Size = System::Drawing::Size(72, 16);
			this->cb_numjoints->TabIndex = 7;
			this->cb_numjoints->Text = L"骨格点数";
			this->cb_numjoints->UseVisualStyleBackColor = true;
			this->cb_numjoints->Visible = false;
			// 
			// cb_fish_size
			// 
			this->cb_fish_size->AutoSize = true;
			this->cb_fish_size->Checked = true;
			this->cb_fish_size->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_fish_size->Location = System::Drawing::Point(154, 60);
			this->cb_fish_size->Name = L"cb_fish_size";
			this->cb_fish_size->Size = System::Drawing::Size(89, 16);
			this->cb_fish_size->TabIndex = 6;
			this->cb_fish_size->Text = L"魚領域サイズ";
			this->cb_fish_size->UseVisualStyleBackColor = true;
			// 
			// cb_roinum_area
			// 
			this->cb_roinum_area->AutoSize = true;
			this->cb_roinum_area->Checked = true;
			this->cb_roinum_area->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_roinum_area->Location = System::Drawing::Point(275, 16);
			this->cb_roinum_area->Name = L"cb_roinum_area";
			this->cb_roinum_area->Size = System::Drawing::Size(95, 16);
			this->cb_roinum_area->TabIndex = 5;
			this->cb_roinum_area->Text = L"ROIの数・実寸";
			this->cb_roinum_area->UseVisualStyleBackColor = true;
			this->cb_roinum_area->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_roinum_area_CheckedChanged);
			// 
			// cb_box_area
			// 
			this->cb_box_area->AutoSize = true;
			this->cb_box_area->Checked = true;
			this->cb_box_area->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_box_area->Location = System::Drawing::Point(154, 16);
			this->cb_box_area->Name = L"cb_box_area";
			this->cb_box_area->Size = System::Drawing::Size(110, 16);
			this->cb_box_area->TabIndex = 4;
			this->cb_box_area->Text = L"水槽領域 (座標）";
			this->cb_box_area->UseVisualStyleBackColor = true;
			this->cb_box_area->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_box_area_CheckedChanged);
			// 
			// cb_videofile_name
			// 
			this->cb_videofile_name->AutoSize = true;
			this->cb_videofile_name->Checked = true;
			this->cb_videofile_name->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_videofile_name->Location = System::Drawing::Point(21, 16);
			this->cb_videofile_name->Name = L"cb_videofile_name";
			this->cb_videofile_name->Size = System::Drawing::Size(94, 16);
			this->cb_videofile_name->TabIndex = 3;
			this->cb_videofile_name->Text = L"動画ファイル名";
			this->cb_videofile_name->UseVisualStyleBackColor = true;
			// 
			// cb_date_exp
			// 
			this->cb_date_exp->AutoSize = true;
			this->cb_date_exp->Checked = true;
			this->cb_date_exp->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_date_exp->Location = System::Drawing::Point(21, 38);
			this->cb_date_exp->Name = L"cb_date_exp";
			this->cb_date_exp->Size = System::Drawing::Size(60, 16);
			this->cb_date_exp->TabIndex = 2;
			this->cb_date_exp->Text = L"実験日";
			this->cb_date_exp->UseVisualStyleBackColor = true;
			this->cb_date_exp->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_date_exp_CheckedChanged);
			// 
			// b_saveparamfile
			// 
			this->b_saveparamfile->Location = System::Drawing::Point(265, 103);
			this->b_saveparamfile->Name = L"b_saveparamfile";
			this->b_saveparamfile->Size = System::Drawing::Size(96, 23);
			this->b_saveparamfile->TabIndex = 0;
			this->b_saveparamfile->Text = L"保存";
			this->b_saveparamfile->UseVisualStyleBackColor = true;
			this->b_saveparamfile->Click += gcnew System::EventHandler(this, &Form1::b_saveparamfile_Click);
			// 
			// gb_writingvideo
			// 
			this->gb_writingvideo->Controls->Add(this->gb_writeoption);
			this->gb_writingvideo->Controls->Add(this->b_savemarksonoriginal);
			this->gb_writingvideo->Enabled = false;
			this->gb_writingvideo->Location = System::Drawing::Point(40, 16);
			this->gb_writingvideo->Name = L"gb_writingvideo";
			this->gb_writingvideo->Size = System::Drawing::Size(376, 158);
			this->gb_writingvideo->TabIndex = 0;
			this->gb_writingvideo->TabStop = false;
			this->gb_writingvideo->Text = L"動画保存";
			// 
			// gb_writeoption
			// 
			this->gb_writeoption->Controls->Add(this->cb_writebinary);
			this->gb_writeoption->Controls->Add(this->cb_writeroi);
			this->gb_writeoption->Controls->Add(this->cb_writeoriginal);
			this->gb_writeoption->Controls->Add(this->cb_writebox);
			this->gb_writeoption->Controls->Add(this->cb_writehead);
			this->gb_writeoption->Controls->Add(this->cb_writejoint);
			this->gb_writeoption->Controls->Add(this->cb_writetail);
			this->gb_writeoption->Location = System::Drawing::Point(21, 19);
			this->gb_writeoption->Name = L"gb_writeoption";
			this->gb_writeoption->Size = System::Drawing::Size(340, 100);
			this->gb_writeoption->TabIndex = 2;
			this->gb_writeoption->TabStop = false;
			this->gb_writeoption->Text = L"書出し対象をチェック";
			// 
			// cb_writebinary
			// 
			this->cb_writebinary->AutoSize = true;
			this->cb_writebinary->Cursor = System::Windows::Forms::Cursors::Default;
			this->cb_writebinary->Location = System::Drawing::Point(6, 49);
			this->cb_writebinary->Name = L"cb_writebinary";
			this->cb_writebinary->Size = System::Drawing::Size(90, 16);
			this->cb_writebinary->TabIndex = 6;
			this->cb_writebinary->Text = L"Binary Video";
			this->cb_writebinary->UseVisualStyleBackColor = true;
			// 
			// cb_writeroi
			// 
			this->cb_writeroi->AutoSize = true;
			this->cb_writeroi->Location = System::Drawing::Point(238, 49);
			this->cb_writeroi->Name = L"cb_writeroi";
			this->cb_writeroi->Size = System::Drawing::Size(43, 16);
			this->cb_writeroi->TabIndex = 4;
			this->cb_writeroi->Text = L"ROI";
			this->cb_writeroi->UseVisualStyleBackColor = true;
			// 
			// cb_writeoriginal
			// 
			this->cb_writeoriginal->AutoSize = true;
			this->cb_writeoriginal->Checked = true;
			this->cb_writeoriginal->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_writeoriginal->Location = System::Drawing::Point(6, 27);
			this->cb_writeoriginal->Name = L"cb_writeoriginal";
			this->cb_writeoriginal->Size = System::Drawing::Size(130, 16);
			this->cb_writeoriginal->TabIndex = 5;
			this->cb_writeoriginal->Text = L"撮影動画（オリジナル）";
			this->cb_writeoriginal->UseVisualStyleBackColor = true;
			// 
			// cb_writebox
			// 
			this->cb_writebox->AutoSize = true;
			this->cb_writebox->Location = System::Drawing::Point(238, 27);
			this->cb_writebox->Name = L"cb_writebox";
			this->cb_writebox->Size = System::Drawing::Size(96, 16);
			this->cb_writebox->TabIndex = 3;
			this->cb_writebox->Text = L"水槽領域矩形";
			this->cb_writebox->UseVisualStyleBackColor = true;
			// 
			// cb_writehead
			// 
			this->cb_writehead->AutoSize = true;
			this->cb_writehead->Checked = true;
			this->cb_writehead->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_writehead->Location = System::Drawing::Point(156, 27);
			this->cb_writehead->Name = L"cb_writehead";
			this->cb_writehead->Size = System::Drawing::Size(48, 16);
			this->cb_writehead->TabIndex = 0;
			this->cb_writehead->Text = L"頭部";
			this->cb_writehead->UseVisualStyleBackColor = true;
			// 
			// cb_writejoint
			// 
			this->cb_writejoint->AutoSize = true;
			this->cb_writejoint->Enabled = false;
			this->cb_writejoint->Location = System::Drawing::Point(98, 78);
			this->cb_writejoint->Name = L"cb_writejoint";
			this->cb_writejoint->Size = System::Drawing::Size(48, 16);
			this->cb_writejoint->TabIndex = 2;
			this->cb_writejoint->Text = L"骨格";
			this->cb_writejoint->UseVisualStyleBackColor = true;
			this->cb_writejoint->Visible = false;
			// 
			// cb_writetail
			// 
			this->cb_writetail->AutoSize = true;
			this->cb_writetail->Checked = true;
			this->cb_writetail->CheckState = System::Windows::Forms::CheckState::Checked;
			this->cb_writetail->Location = System::Drawing::Point(156, 49);
			this->cb_writetail->Name = L"cb_writetail";
			this->cb_writetail->Size = System::Drawing::Size(48, 16);
			this->cb_writetail->TabIndex = 1;
			this->cb_writetail->Text = L"尾部";
			this->cb_writetail->UseVisualStyleBackColor = true;
			// 
			// b_savemarksonoriginal
			// 
			this->b_savemarksonoriginal->Location = System::Drawing::Point(134, 129);
			this->b_savemarksonoriginal->Name = L"b_savemarksonoriginal";
			this->b_savemarksonoriginal->Size = System::Drawing::Size(114, 23);
			this->b_savemarksonoriginal->TabIndex = 0;
			this->b_savemarksonoriginal->Text = L"動画の書出し";
			this->b_savemarksonoriginal->UseVisualStyleBackColor = true;
			this->b_savemarksonoriginal->Click += gcnew System::EventHandler(this, &Form1::b_savemarksonoriginal_Click);
			// 
			// gb_saveresult
			// 
			this->gb_saveresult->Controls->Add(this->b_result_to_clip);
			this->gb_saveresult->Controls->Add(this->gb_saving_as);
			this->gb_saveresult->Controls->Add(this->b_saveresultdata);
			this->gb_saveresult->Enabled = false;
			this->gb_saveresult->Location = System::Drawing::Point(40, 185);
			this->gb_saveresult->Name = L"gb_saveresult";
			this->gb_saveresult->Size = System::Drawing::Size(376, 61);
			this->gb_saveresult->TabIndex = 1;
			this->gb_saveresult->TabStop = false;
			this->gb_saveresult->Text = L"結果ファイル保存";
			// 
			// b_result_to_clip
			// 
			this->b_result_to_clip->Location = System::Drawing::Point(265, 26);
			this->b_result_to_clip->Name = L"b_result_to_clip";
			this->b_result_to_clip->Size = System::Drawing::Size(90, 23);
			this->b_result_to_clip->TabIndex = 6;
			this->b_result_to_clip->Text = L"クリップボードへ";
			this->b_result_to_clip->UseVisualStyleBackColor = true;
			this->b_result_to_clip->Click += gcnew System::EventHandler(this, &Form1::b_result_to_clip_Click);
			// 
			// gb_saving_as
			// 
			this->gb_saving_as->Controls->Add(this->radioButton_csv);
			this->gb_saving_as->Controls->Add(this->radioButton_txt);
			this->gb_saving_as->Location = System::Drawing::Point(6, 18);
			this->gb_saving_as->Name = L"gb_saving_as";
			this->gb_saving_as->Size = System::Drawing::Size(142, 38);
			this->gb_saving_as->TabIndex = 5;
			this->gb_saving_as->TabStop = false;
			this->gb_saving_as->Text = L"ファイル保存形式";
			// 
			// radioButton_csv
			// 
			this->radioButton_csv->AutoSize = true;
			this->radioButton_csv->Location = System::Drawing::Point(74, 16);
			this->radioButton_csv->Name = L"radioButton_csv";
			this->radioButton_csv->Size = System::Drawing::Size(41, 16);
			this->radioButton_csv->TabIndex = 1;
			this->radioButton_csv->Text = L"csv";
			this->radioButton_csv->UseVisualStyleBackColor = true;
			// 
			// radioButton_txt
			// 
			this->radioButton_txt->AutoSize = true;
			this->radioButton_txt->Checked = true;
			this->radioButton_txt->Location = System::Drawing::Point(15, 16);
			this->radioButton_txt->Name = L"radioButton_txt";
			this->radioButton_txt->Size = System::Drawing::Size(37, 16);
			this->radioButton_txt->TabIndex = 0;
			this->radioButton_txt->TabStop = true;
			this->radioButton_txt->Text = L"txt";
			this->radioButton_txt->UseVisualStyleBackColor = true;
			// 
			// b_saveresultdata
			// 
			this->b_saveresultdata->Location = System::Drawing::Point(154, 27);
			this->b_saveresultdata->Name = L"b_saveresultdata";
			this->b_saveresultdata->Size = System::Drawing::Size(103, 23);
			this->b_saveresultdata->TabIndex = 0;
			this->b_saveresultdata->Text = L"保存";
			this->b_saveresultdata->UseVisualStyleBackColor = true;
			this->b_saveresultdata->Click += gcnew System::EventHandler(this, &Form1::b_saveresultdata_Click);
			// 
			// tab_tracking
			// 
			this->tab_tracking->Controls->Add(this->gb_referencepoint);
			this->tab_tracking->Controls->Add(this->gb_detecterror);
			this->tab_tracking->Controls->Add(this->gb_determinesize);
			this->tab_tracking->Controls->Add(this->gb_boxarea);
			this->tab_tracking->Controls->Add(this->gb_bonecalc);
			this->tab_tracking->Controls->Add(this->gb_tracking);
			this->tab_tracking->Controls->Add(this->gb_smoothing);
			this->tab_tracking->Location = System::Drawing::Point(4, 22);
			this->tab_tracking->Name = L"tab_tracking";
			this->tab_tracking->Padding = System::Windows::Forms::Padding(3);
			this->tab_tracking->Size = System::Drawing::Size(476, 452);
			this->tab_tracking->TabIndex = 1;
			this->tab_tracking->Text = L"トラッキング";
			this->tab_tracking->UseVisualStyleBackColor = true;
			// 
			// gb_referencepoint
			// 
			this->gb_referencepoint->Controls->Add(this->label37);
			this->gb_referencepoint->Controls->Add(this->button1);
			this->gb_referencepoint->Controls->Add(this->button2);
			this->gb_referencepoint->Enabled = false;
			this->gb_referencepoint->Location = System::Drawing::Point(27, 383);
			this->gb_referencepoint->Name = L"gb_referencepoint";
			this->gb_referencepoint->Size = System::Drawing::Size(196, 51);
			this->gb_referencepoint->TabIndex = 20;
			this->gb_referencepoint->TabStop = false;
			this->gb_referencepoint->Text = L"基準点の設定";
			this->gb_referencepoint->Visible = false;
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(9, 108);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(139, 12);
			this->label37->TabIndex = 13;
			this->label37->Text = L"表示フレームについて再計算";
			this->label37->Visible = false;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(46, 18);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(94, 23);
			this->button1->TabIndex = 11;
			this->button1->Text = L"基準点の選択";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(44, 130);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(69, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"実行";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Visible = false;
			// 
			// gb_detecterror
			// 
			this->gb_detecterror->Controls->Add(this->label36);
			this->gb_detecterror->Controls->Add(this->b_detecterror);
			this->gb_detecterror->Enabled = false;
			this->gb_detecterror->Location = System::Drawing::Point(247, 183);
			this->gb_detecterror->Name = L"gb_detecterror";
			this->gb_detecterror->Size = System::Drawing::Size(196, 84);
			this->gb_detecterror->TabIndex = 19;
			this->gb_detecterror->TabStop = false;
			this->gb_detecterror->Text = L"誤検出修正用";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(9, 36);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(67, 12);
			this->label36->TabIndex = 1;
			this->label36->Text = L"異常値検出:";
			// 
			// b_detecterror
			// 
			this->b_detecterror->Location = System::Drawing::Point(95, 31);
			this->b_detecterror->Name = L"b_detecterror";
			this->b_detecterror->Size = System::Drawing::Size(75, 23);
			this->b_detecterror->TabIndex = 0;
			this->b_detecterror->Text = L"実行";
			this->b_detecterror->UseVisualStyleBackColor = true;
			// 
			// gb_determinesize
			// 
			this->gb_determinesize->Controls->Add(this->b_check);
			this->gb_determinesize->Controls->Add(this->trackBar_sizebinary);
			this->gb_determinesize->Controls->Add(this->b_setsize);
			this->gb_determinesize->Controls->Add(this->b_startsize);
			this->gb_determinesize->Enabled = false;
			this->gb_determinesize->Location = System::Drawing::Point(247, 23);
			this->gb_determinesize->Name = L"gb_determinesize";
			this->gb_determinesize->Size = System::Drawing::Size(196, 154);
			this->gb_determinesize->TabIndex = 18;
			this->gb_determinesize->TabStop = false;
			this->gb_determinesize->Text = L"魚のサイズ設定";
			// 
			// b_check
			// 
			this->b_check->Enabled = false;
			this->b_check->Location = System::Drawing::Point(21, 115);
			this->b_check->Name = L"b_check";
			this->b_check->Size = System::Drawing::Size(68, 23);
			this->b_check->TabIndex = 4;
			this->b_check->Text = L"確認";
			this->b_check->UseVisualStyleBackColor = true;
			this->b_check->Click += gcnew System::EventHandler(this, &Form1::b_check_Click);
			// 
			// trackBar_sizebinary
			// 
			this->trackBar_sizebinary->BackColor = System::Drawing::SystemColors::Window;
			this->trackBar_sizebinary->Enabled = false;
			this->trackBar_sizebinary->Location = System::Drawing::Point(6, 60);
			this->trackBar_sizebinary->Maximum = 254;
			this->trackBar_sizebinary->Name = L"trackBar_sizebinary";
			this->trackBar_sizebinary->Size = System::Drawing::Size(184, 45);
			this->trackBar_sizebinary->TabIndex = 3;
			this->trackBar_sizebinary->Scroll += gcnew System::EventHandler(this, &Form1::trackBar_sizebinary_Scroll);
			// 
			// b_setsize
			// 
			this->b_setsize->Enabled = false;
			this->b_setsize->Location = System::Drawing::Point(111, 115);
			this->b_setsize->Name = L"b_setsize";
			this->b_setsize->Size = System::Drawing::Size(59, 23);
			this->b_setsize->TabIndex = 2;
			this->b_setsize->Text = L"完了";
			this->b_setsize->UseVisualStyleBackColor = true;
			this->b_setsize->Click += gcnew System::EventHandler(this, &Form1::b_setsize_Click);
			// 
			// b_startsize
			// 
			this->b_startsize->Location = System::Drawing::Point(6, 21);
			this->b_startsize->Name = L"b_startsize";
			this->b_startsize->Size = System::Drawing::Size(83, 23);
			this->b_startsize->TabIndex = 0;
			this->b_startsize->Text = L"設定開始";
			this->b_startsize->UseVisualStyleBackColor = true;
			this->b_startsize->Click += gcnew System::EventHandler(this, &Form1::b_startsize_Click);
			// 
			// gb_boxarea
			// 
			this->gb_boxarea->Controls->Add(this->label39);
			this->gb_boxarea->Controls->Add(this->label1);
			this->gb_boxarea->Controls->Add(this->label19);
			this->gb_boxarea->Controls->Add(this->label20);
			this->gb_boxarea->Controls->Add(this->textBox_boxarea_height);
			this->gb_boxarea->Controls->Add(this->textBox_boxarea_width);
			this->gb_boxarea->Controls->Add(this->label21);
			this->gb_boxarea->Controls->Add(this->label22);
			this->gb_boxarea->Controls->Add(this->b_set_boxarea);
			this->gb_boxarea->Enabled = false;
			this->gb_boxarea->Location = System::Drawing::Point(27, 23);
			this->gb_boxarea->Name = L"gb_boxarea";
			this->gb_boxarea->Size = System::Drawing::Size(195, 154);
			this->gb_boxarea->TabIndex = 16;
			this->gb_boxarea->TabStop = false;
			this->gb_boxarea->Text = L"水槽の設定";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(40, 87);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(125, 12);
			this->label39->TabIndex = 33;
			this->label39->Text = L"Press Enter for Change";
			this->label39->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(6, 32);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 12);
			this->label1->TabIndex = 32;
			this->label1->Text = L"実寸：";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(138, 66);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(23, 12);
			this->label19->TabIndex = 31;
			this->label19->Text = L"mm";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(138, 32);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(23, 12);
			this->label20->TabIndex = 30;
			this->label20->Text = L"mm";
			// 
			// textBox_boxarea_height
			// 
			this->textBox_boxarea_height->Location = System::Drawing::Point(81, 63);
			this->textBox_boxarea_height->Name = L"textBox_boxarea_height";
			this->textBox_boxarea_height->Size = System::Drawing::Size(54, 19);
			this->textBox_boxarea_height->TabIndex = 27;
			this->textBox_boxarea_height->Text = L"150";
			this->textBox_boxarea_height->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_boxarea_height->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_boxarea_height_PreviewKeyDown);
			// 
			// textBox_boxarea_width
			// 
			this->textBox_boxarea_width->Location = System::Drawing::Point(81, 29);
			this->textBox_boxarea_width->Name = L"textBox_boxarea_width";
			this->textBox_boxarea_width->Size = System::Drawing::Size(54, 19);
			this->textBox_boxarea_width->TabIndex = 26;
			this->textBox_boxarea_width->Text = L"150";
			this->textBox_boxarea_width->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox_boxarea_width->PreviewKeyDown += gcnew System::Windows::Forms::PreviewKeyDownEventHandler(this, &Form1::textBox_boxarea_width_PreviewKeyDown);
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(40, 66);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(40, 12);
			this->label21->TabIndex = 23;
			this->label21->Text = L"Height:";
			this->label21->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(42, 32);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(35, 12);
			this->label22->TabIndex = 22;
			this->label22->Text = L"Width:";
			this->label22->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// b_set_boxarea
			// 
			this->b_set_boxarea->Location = System::Drawing::Point(46, 115);
			this->b_set_boxarea->Name = L"b_set_boxarea";
			this->b_set_boxarea->Size = System::Drawing::Size(105, 23);
			this->b_set_boxarea->TabIndex = 17;
			this->b_set_boxarea->Text = L"水槽領域の選択";
			this->b_set_boxarea->UseVisualStyleBackColor = true;
			this->b_set_boxarea->Click += gcnew System::EventHandler(this, &Form1::b_set_boxarea_Click);
			// 
			// gb_bonecalc
			// 
			this->gb_bonecalc->Controls->Add(this->label6);
			this->gb_bonecalc->Controls->Add(this->label5);
			this->gb_bonecalc->Controls->Add(this->b_getbone_all);
			this->gb_bonecalc->Controls->Add(this->b_getbone_frame);
			this->gb_bonecalc->Enabled = false;
			this->gb_bonecalc->Location = System::Drawing::Point(247, 297);
			this->gb_bonecalc->Name = L"gb_bonecalc";
			this->gb_bonecalc->Size = System::Drawing::Size(196, 84);
			this->gb_bonecalc->TabIndex = 15;
			this->gb_bonecalc->TabStop = false;
			this->gb_bonecalc->Text = L"骨格点の再計算";
			this->gb_bonecalc->Visible = false;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(9, 108);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(139, 12);
			this->label6->TabIndex = 13;
			this->label6->Text = L"表示フレームについて再計算";
			this->label6->Visible = false;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(12, 28);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(127, 12);
			this->label5->TabIndex = 12;
			this->label5->Text = L"全フレームについて再計算";
			// 
			// b_getbone_all
			// 
			this->b_getbone_all->Location = System::Drawing::Point(48, 50);
			this->b_getbone_all->Name = L"b_getbone_all";
			this->b_getbone_all->Size = System::Drawing::Size(94, 23);
			this->b_getbone_all->TabIndex = 11;
			this->b_getbone_all->Text = L"実行";
			this->b_getbone_all->UseVisualStyleBackColor = true;
			// 
			// b_getbone_frame
			// 
			this->b_getbone_frame->Location = System::Drawing::Point(44, 130);
			this->b_getbone_frame->Name = L"b_getbone_frame";
			this->b_getbone_frame->Size = System::Drawing::Size(69, 23);
			this->b_getbone_frame->TabIndex = 1;
			this->b_getbone_frame->Text = L"実行";
			this->b_getbone_frame->UseVisualStyleBackColor = true;
			this->b_getbone_frame->Visible = false;
			// 
			// gb_tracking
			// 
			this->gb_tracking->Controls->Add(this->cb_usebinval);
			this->gb_tracking->Controls->Add(this->label7);
			this->gb_tracking->Controls->Add(this->label8);
			this->gb_tracking->Controls->Add(this->track_num_joint_points);
			this->gb_tracking->Controls->Add(this->b_track_exec);
			this->gb_tracking->Enabled = false;
			this->gb_tracking->Location = System::Drawing::Point(27, 183);
			this->gb_tracking->Name = L"gb_tracking";
			this->gb_tracking->Size = System::Drawing::Size(196, 154);
			this->gb_tracking->TabIndex = 13;
			this->gb_tracking->TabStop = false;
			this->gb_tracking->Text = L"トラッキング";
			// 
			// cb_usebinval
			// 
			this->cb_usebinval->AutoSize = true;
			this->cb_usebinval->Enabled = false;
			this->cb_usebinval->Location = System::Drawing::Point(31, 114);
			this->cb_usebinval->Name = L"cb_usebinval";
			this->cb_usebinval->Size = System::Drawing::Size(130, 16);
			this->cb_usebinval->TabIndex = 18;
			this->cb_usebinval->Text = L"指定した閾値で2値化";
			this->cb_usebinval->UseVisualStyleBackColor = true;
			this->cb_usebinval->Visible = false;
			this->cb_usebinval->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_usebinval_CheckedChanged);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(44, 36);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(37, 12);
			this->label7->TabIndex = 17;
			this->label7->Text = L"(2-10)";
			this->label7->Visible = false;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(14, 20);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(63, 12);
			this->label8->TabIndex = 16;
			this->label8->Text = L"骨格点の数";
			this->label8->Visible = false;
			// 
			// track_num_joint_points
			// 
			this->track_num_joint_points->Location = System::Drawing::Point(101, 20);
			this->track_num_joint_points->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 0 });
			this->track_num_joint_points->Name = L"track_num_joint_points";
			this->track_num_joint_points->Size = System::Drawing::Size(60, 19);
			this->track_num_joint_points->TabIndex = 15;
			this->track_num_joint_points->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2, 0, 0, 0 });
			this->track_num_joint_points->Visible = false;
			// 
			// b_track_exec
			// 
			this->b_track_exec->Location = System::Drawing::Point(27, 51);
			this->b_track_exec->Name = L"b_track_exec";
			this->b_track_exec->Size = System::Drawing::Size(134, 47);
			this->b_track_exec->TabIndex = 0;
			this->b_track_exec->Text = L"トラッキング実行";
			this->b_track_exec->UseVisualStyleBackColor = true;
			this->b_track_exec->Click += gcnew System::EventHandler(this, &Form1::b_track_exec_Click);
			// 
			// gb_smoothing
			// 
			this->gb_smoothing->Controls->Add(this->smoothing_param_beta);
			this->gb_smoothing->Controls->Add(this->label9);
			this->gb_smoothing->Controls->Add(this->label10);
			this->gb_smoothing->Controls->Add(this->smoothing_param_alpha);
			this->gb_smoothing->Controls->Add(this->smoothing_param_seq_length);
			this->gb_smoothing->Controls->Add(this->b_smooth_exec);
			this->gb_smoothing->Enabled = false;
			this->gb_smoothing->Location = System::Drawing::Point(229, 381);
			this->gb_smoothing->Name = L"gb_smoothing";
			this->gb_smoothing->Size = System::Drawing::Size(196, 56);
			this->gb_smoothing->TabIndex = 14;
			this->gb_smoothing->TabStop = false;
			this->gb_smoothing->Text = L"尾部のスムージング";
			this->gb_smoothing->Visible = false;
			// 
			// smoothing_param_beta
			// 
			this->smoothing_param_beta->DecimalPlaces = 1;
			this->smoothing_param_beta->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 65536 });
			this->smoothing_param_beta->Location = System::Drawing::Point(109, 166);
			this->smoothing_param_beta->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 65536 });
			this->smoothing_param_beta->Name = L"smoothing_param_beta";
			this->smoothing_param_beta->Size = System::Drawing::Size(42, 19);
			this->smoothing_param_beta->TabIndex = 20;
			this->smoothing_param_beta->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 4, 0, 0, 65536 });
			this->smoothing_param_beta->Visible = false;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(46, 168);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(57, 12);
			this->label9->TabIndex = 19;
			this->label9->Text = L"パラメータ2:";
			this->label9->Visible = false;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(46, 138);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(57, 12);
			this->label10->TabIndex = 18;
			this->label10->Text = L"パラメータ1:";
			this->label10->Visible = false;
			// 
			// smoothing_param_alpha
			// 
			this->smoothing_param_alpha->DecimalPlaces = 1;
			this->smoothing_param_alpha->Increment = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 65536 });
			this->smoothing_param_alpha->Location = System::Drawing::Point(109, 136);
			this->smoothing_param_alpha->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 10, 0, 0, 65536 });
			this->smoothing_param_alpha->Name = L"smoothing_param_alpha";
			this->smoothing_param_alpha->Size = System::Drawing::Size(42, 19);
			this->smoothing_param_alpha->TabIndex = 17;
			this->smoothing_param_alpha->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2, 0, 0, 65536 });
			this->smoothing_param_alpha->Visible = false;
			// 
			// smoothing_param_seq_length
			// 
			this->smoothing_param_seq_length->Location = System::Drawing::Point(108, 101);
			this->smoothing_param_seq_length->Name = L"smoothing_param_seq_length";
			this->smoothing_param_seq_length->Size = System::Drawing::Size(60, 19);
			this->smoothing_param_seq_length->TabIndex = 16;
			this->smoothing_param_seq_length->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { 11, 0, 0, 0 });
			this->smoothing_param_seq_length->Visible = false;
			// 
			// b_smooth_exec
			// 
			this->b_smooth_exec->Location = System::Drawing::Point(48, 20);
			this->b_smooth_exec->Name = L"b_smooth_exec";
			this->b_smooth_exec->Size = System::Drawing::Size(94, 23);
			this->b_smooth_exec->TabIndex = 2;
			this->b_smooth_exec->Text = L"スムージング実行";
			this->b_smooth_exec->UseVisualStyleBackColor = true;
			// 
			// tab_load
			// 
			this->tab_load->Controls->Add(this->gb_setparam);
			this->tab_load->Controls->Add(this->gb_setbackground);
			this->tab_load->Controls->Add(this->groupBox1);
			this->tab_load->Location = System::Drawing::Point(4, 22);
			this->tab_load->Name = L"tab_load";
			this->tab_load->Padding = System::Windows::Forms::Padding(3);
			this->tab_load->Size = System::Drawing::Size(476, 452);
			this->tab_load->TabIndex = 0;
			this->tab_load->Text = L"読込";
			this->tab_load->UseVisualStyleBackColor = true;
			// 
			// gb_setparam
			// 
			this->gb_setparam->Controls->Add(this->label_readfromsettingfile);
			this->gb_setparam->Controls->Add(this->label41);
			this->gb_setparam->Controls->Add(this->b_loadparameter);
			this->gb_setparam->Enabled = false;
			this->gb_setparam->Location = System::Drawing::Point(6, 321);
			this->gb_setparam->Name = L"gb_setparam";
			this->gb_setparam->Size = System::Drawing::Size(464, 117);
			this->gb_setparam->TabIndex = 2;
			this->gb_setparam->TabStop = false;
			this->gb_setparam->Text = L"設定ファイルの読込";
			this->gb_setparam->Visible = false;
			// 
			// label_readfromsettingfile
			// 
			this->label_readfromsettingfile->AutoSize = true;
			this->label_readfromsettingfile->Location = System::Drawing::Point(45, 83);
			this->label_readfromsettingfile->Name = L"label_readfromsettingfile";
			this->label_readfromsettingfile->Size = System::Drawing::Size(24, 12);
			this->label_readfromsettingfile->TabIndex = 2;
			this->label_readfromsettingfile->Text = L"なし";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(6, 56);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(348, 12);
			this->label41->TabIndex = 1;
			this->label41->Text = L"ファイルより以下の設定項目の読込完了（トラッキングタブにて変更可能）：\r\n";
			// 
			// b_loadparameter
			// 
			this->b_loadparameter->Location = System::Drawing::Point(8, 18);
			this->b_loadparameter->Name = L"b_loadparameter";
			this->b_loadparameter->Size = System::Drawing::Size(75, 23);
			this->b_loadparameter->TabIndex = 0;
			this->b_loadparameter->Text = L"読込";
			this->b_loadparameter->UseVisualStyleBackColor = true;
			// 
			// gb_setbackground
			// 
			this->gb_setbackground->Controls->Add(this->label_bcgdimagename);
			this->gb_setbackground->Controls->Add(this->gb_createbackground);
			this->gb_setbackground->Controls->Add(this->b_loadbackground);
			this->gb_setbackground->Enabled = false;
			this->gb_setbackground->Location = System::Drawing::Point(6, 128);
			this->gb_setbackground->Name = L"gb_setbackground";
			this->gb_setbackground->Size = System::Drawing::Size(464, 166);
			this->gb_setbackground->TabIndex = 1;
			this->gb_setbackground->TabStop = false;
			this->gb_setbackground->Text = L"背景画像の作成/読込";
			// 
			// label_bcgdimagename
			// 
			this->label_bcgdimagename->AutoSize = true;
			this->label_bcgdimagename->Location = System::Drawing::Point(89, 128);
			this->label_bcgdimagename->Name = L"label_bcgdimagename";
			this->label_bcgdimagename->Size = System::Drawing::Size(53, 12);
			this->label_bcgdimagename->TabIndex = 10;
			this->label_bcgdimagename->Text = L"ファイル名:";
			// 
			// gb_createbackground
			// 
			this->gb_createbackground->Controls->Add(this->b_savebcgdimage);
			this->gb_createbackground->Controls->Add(this->b_1stimage);
			this->gb_createbackground->Controls->Add(this->label4);
			this->gb_createbackground->Controls->Add(this->b_2ndimage);
			this->gb_createbackground->Controls->Add(this->b_showbackground);
			this->gb_createbackground->Controls->Add(this->label3);
			this->gb_createbackground->Controls->Add(this->b_3rdimage);
			this->gb_createbackground->Controls->Add(this->label2);
			this->gb_createbackground->Controls->Add(this->b_createbackground);
			this->gb_createbackground->Location = System::Drawing::Point(8, 18);
			this->gb_createbackground->Name = L"gb_createbackground";
			this->gb_createbackground->Size = System::Drawing::Size(450, 88);
			this->gb_createbackground->TabIndex = 9;
			this->gb_createbackground->TabStop = false;
			this->gb_createbackground->Text = L"背景画像作成";
			// 
			// b_savebcgdimage
			// 
			this->b_savebcgdimage->Enabled = false;
			this->b_savebcgdimage->Location = System::Drawing::Point(381, 59);
			this->b_savebcgdimage->Name = L"b_savebcgdimage";
			this->b_savebcgdimage->Size = System::Drawing::Size(60, 23);
			this->b_savebcgdimage->TabIndex = 0;
			this->b_savebcgdimage->Text = L"保存";
			this->b_savebcgdimage->UseVisualStyleBackColor = true;
			this->b_savebcgdimage->Click += gcnew System::EventHandler(this, &Form1::b_savebcgdimage_Click);
			// 
			// b_1stimage
			// 
			this->b_1stimage->Location = System::Drawing::Point(39, 22);
			this->b_1stimage->Name = L"b_1stimage";
			this->b_1stimage->Size = System::Drawing::Size(35, 23);
			this->b_1stimage->TabIndex = 1;
			this->b_1stimage->Text = L"1st";
			this->b_1stimage->UseVisualStyleBackColor = true;
			this->b_1stimage->Click += gcnew System::EventHandler(this, &Form1::b_1stimage_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(193, 27);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(17, 12);
			this->label4->TabIndex = 8;
			this->label4->Text = L"->";
			// 
			// b_2ndimage
			// 
			this->b_2ndimage->Location = System::Drawing::Point(93, 22);
			this->b_2ndimage->Name = L"b_2ndimage";
			this->b_2ndimage->Size = System::Drawing::Size(35, 23);
			this->b_2ndimage->TabIndex = 2;
			this->b_2ndimage->Text = L"2nd";
			this->b_2ndimage->UseVisualStyleBackColor = true;
			this->b_2ndimage->Click += gcnew System::EventHandler(this, &Form1::b_2ndimage_Click);
			// 
			// b_showbackground
			// 
			this->b_showbackground->Location = System::Drawing::Point(310, 59);
			this->b_showbackground->Name = L"b_showbackground";
			this->b_showbackground->Size = System::Drawing::Size(65, 23);
			this->b_showbackground->TabIndex = 5;
			this->b_showbackground->Text = L"表示";
			this->b_showbackground->UseVisualStyleBackColor = true;
			this->b_showbackground->Click += gcnew System::EventHandler(this, &Form1::b_showbackground_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(134, 27);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(17, 12);
			this->label3->TabIndex = 7;
			this->label3->Text = L"->";
			// 
			// b_3rdimage
			// 
			this->b_3rdimage->Location = System::Drawing::Point(152, 22);
			this->b_3rdimage->Name = L"b_3rdimage";
			this->b_3rdimage->Size = System::Drawing::Size(35, 23);
			this->b_3rdimage->TabIndex = 3;
			this->b_3rdimage->Text = L"3rd";
			this->b_3rdimage->UseVisualStyleBackColor = true;
			this->b_3rdimage->Click += gcnew System::EventHandler(this, &Form1::b_3rdimage_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(75, 27);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(17, 12);
			this->label2->TabIndex = 6;
			this->label2->Text = L"->";
			// 
			// b_createbackground
			// 
			this->b_createbackground->Location = System::Drawing::Point(216, 22);
			this->b_createbackground->Name = L"b_createbackground";
			this->b_createbackground->Size = System::Drawing::Size(75, 23);
			this->b_createbackground->TabIndex = 4;
			this->b_createbackground->Text = L"作成！";
			this->b_createbackground->UseVisualStyleBackColor = true;
			this->b_createbackground->Click += gcnew System::EventHandler(this, &Form1::b_createbackground_Click);
			// 
			// b_loadbackground
			// 
			this->b_loadbackground->Location = System::Drawing::Point(8, 122);
			this->b_loadbackground->Name = L"b_loadbackground";
			this->b_loadbackground->Size = System::Drawing::Size(75, 23);
			this->b_loadbackground->TabIndex = 0;
			this->b_loadbackground->Text = L"読込";
			this->b_loadbackground->UseVisualStyleBackColor = true;
			this->b_loadbackground->Click += gcnew System::EventHandler(this, &Form1::b_loadbackground_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label_videofilename);
			this->groupBox1->Controls->Add(this->b_loadvideofile);
			this->groupBox1->Location = System::Drawing::Point(6, 6);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(464, 116);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"ビデオ読込(MP4)";
			// 
			// label_videofilename
			// 
			this->label_videofilename->AutoSize = true;
			this->label_videofilename->Location = System::Drawing::Point(6, 78);
			this->label_videofilename->Name = L"label_videofilename";
			this->label_videofilename->Size = System::Drawing::Size(53, 12);
			this->label_videofilename->TabIndex = 1;
			this->label_videofilename->Text = L"ファイル名:";
			// 
			// b_loadvideofile
			// 
			this->b_loadvideofile->Location = System::Drawing::Point(6, 29);
			this->b_loadvideofile->Name = L"b_loadvideofile";
			this->b_loadvideofile->Size = System::Drawing::Size(77, 23);
			this->b_loadvideofile->TabIndex = 0;
			this->b_loadvideofile->Text = L"読込(MP4)";
			this->b_loadvideofile->UseVisualStyleBackColor = true;
			this->b_loadvideofile->Click += gcnew System::EventHandler(this, &Form1::b_loadvideofile_Click);
			// 
			// tab
			// 
			this->tab->Controls->Add(this->tab_load);
			this->tab->Controls->Add(this->tab_tracking);
			this->tab->Controls->Add(this->tabPage1);
			this->tab->Controls->Add(this->tabPage2);
			this->tab->Location = System::Drawing::Point(11, 200);
			this->tab->Name = L"tab";
			this->tab->SelectedIndex = 0;
			this->tab->Size = System::Drawing::Size(484, 478);
			this->tab->TabIndex = 0;
			// 
			// bgworker_writevideo
			// 
			this->bgworker_writevideo->WorkerReportsProgress = true;
			this->bgworker_writevideo->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::bgworker_writevideo_DoWork);
			this->bgworker_writevideo->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::bgworker_writevideo_ProgressChanged);
			this->bgworker_writevideo->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::bgworker_writevideo_RunWorkerCompleted);
			// 
			// label_time
			// 
			this->label_time->AutoSize = true;
			this->label_time->Location = System::Drawing::Point(513, 585);
			this->label_time->Name = L"label_time";
			this->label_time->Size = System::Drawing::Size(11, 12);
			this->label_time->TabIndex = 22;
			this->label_time->Text = L"0";
			// 
			// label_numframes
			// 
			this->label_numframes->AutoSize = true;
			this->label_numframes->Location = System::Drawing::Point(1107, 585);
			this->label_numframes->Name = L"label_numframes";
			this->label_numframes->Size = System::Drawing::Size(23, 12);
			this->label_numframes->TabIndex = 23;
			this->label_numframes->Text = L"100";
			// 
			// cb_forclick
			// 
			this->cb_forclick->AutoSize = true;
			this->cb_forclick->Enabled = false;
			this->cb_forclick->Location = System::Drawing::Point(423, 649);
			this->cb_forclick->Name = L"cb_forclick";
			this->cb_forclick->Size = System::Drawing::Size(128, 16);
			this->cb_forclick->TabIndex = 24;
			this->cb_forclick->Text = L"Forward with a click";
			this->cb_forclick->UseVisualStyleBackColor = true;
			this->cb_forclick->Visible = false;
			// 
			// cb_zoomin
			// 
			this->cb_zoomin->AutoSize = true;
			this->cb_zoomin->Enabled = false;
			this->cb_zoomin->Location = System::Drawing::Point(918, 666);
			this->cb_zoomin->Name = L"cb_zoomin";
			this->cb_zoomin->Size = System::Drawing::Size(67, 16);
			this->cb_zoomin->TabIndex = 25;
			this->cb_zoomin->Text = L"Zoom-in";
			this->cb_zoomin->UseVisualStyleBackColor = true;
			this->cb_zoomin->CheckedChanged += gcnew System::EventHandler(this, &Form1::cb_zoomin_CheckedChanged);
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->LangToolStripMenuItem });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1150, 26);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// LangToolStripMenuItem
			// 
			this->LangToolStripMenuItem->AccessibleRole = System::Windows::Forms::AccessibleRole::None;
			this->LangToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->englishToolStripMenuItem,
					this->JapaneseToolStripMenuItem
			});
			this->LangToolStripMenuItem->Name = L"LangToolStripMenuItem";
			this->LangToolStripMenuItem->Size = System::Drawing::Size(76, 22);
			this->LangToolStripMenuItem->Text = L"Language";
			// 
			// englishToolStripMenuItem
			// 
			this->englishToolStripMenuItem->Name = L"englishToolStripMenuItem";
			this->englishToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->englishToolStripMenuItem->Text = L"English";
			this->englishToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::englishToolStripMenuItem_Click);
			// 
			// JapaneseToolStripMenuItem
			// 
			this->JapaneseToolStripMenuItem->Checked = true;
			this->JapaneseToolStripMenuItem->CheckState = System::Windows::Forms::CheckState::Checked;
			this->JapaneseToolStripMenuItem->Name = L"JapaneseToolStripMenuItem";
			this->JapaneseToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->JapaneseToolStripMenuItem->Text = L"日本語";
			this->JapaneseToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::JapaneseToolStripMenuItem_Click);
			// 
			// pictureBoxDone
			// 
			this->pictureBoxDone->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->pictureBoxDone->Cursor = System::Windows::Forms::Cursors::Arrow;
			this->pictureBoxDone->Location = System::Drawing::Point(510, 513);
			this->pictureBoxDone->Name = L"pictureBoxDone";
			this->pictureBoxDone->Size = System::Drawing::Size(623, 15);
			this->pictureBoxDone->TabIndex = 26;
			this->pictureBoxDone->TabStop = false;
			this->pictureBoxDone->MouseClick += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBoxDone_MouseClick);
			this->pictureBoxDone->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBoxDone_MouseDown);
			this->pictureBoxDone->MouseLeave += gcnew System::EventHandler(this, &Form1::pictureBoxDone_MouseLeave);
			this->pictureBoxDone->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBoxDone_MouseMove);
			this->pictureBoxDone->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &Form1::pictureBoxDone_MouseUp);
			// 
			// cb_showrefpoint
			// 
			this->cb_showrefpoint->AutoSize = true;
			this->cb_showrefpoint->Enabled = false;
			this->cb_showrefpoint->Location = System::Drawing::Point(471, 630);
			this->cb_showrefpoint->Name = L"cb_showrefpoint";
			this->cb_showrefpoint->Size = System::Drawing::Size(84, 16);
			this->cb_showrefpoint->TabIndex = 27;
			this->cb_showrefpoint->Text = L"基準点表示";
			this->cb_showrefpoint->UseVisualStyleBackColor = true;
			this->cb_showrefpoint->Visible = false;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 12);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1150, 695);
			this->Controls->Add(this->cb_showrefpoint);
			this->Controls->Add(this->cb_zoomin);
			this->Controls->Add(this->cb_forclick);
			this->Controls->Add(this->label_numframes);
			this->Controls->Add(this->label_time);
			this->Controls->Add(this->gb_speedcontrol);
			this->Controls->Add(this->trackBar);
			this->Controls->Add(this->tab);
			this->Controls->Add(this->pictureBox_trackbar);
			this->Controls->Add(this->b_debug);
			this->Controls->Add(this->checkBox_showmarkers);
			this->Controls->Add(this->cb_showroi);
			this->Controls->Add(this->cb_showboxarea);
			this->Controls->Add(this->checkBox_showoriginal);
			this->Controls->Add(this->progressBar);
			this->Controls->Add(this->panel_playercontrol);
			this->Controls->Add(this->log_viewer);
			this->Controls->Add(this->pictureBox);
			this->Controls->Add(this->menuStrip1);
			this->Controls->Add(this->pictureBoxDone);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->Text = L"Medaka_Fish_Tracker v3.7, Nibb & Ku, Japan";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->gb_ROI->ResumeLayout(false);
			this->gb_ROI->PerformLayout();
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox))->EndInit();
			this->panel_playercontrol->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar))->EndInit();
			this->gb_speedcontrol->ResumeLayout(false);
			this->gb_speedcontrol->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox_trackbar))->EndInit();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->panel4->ResumeLayout(false);
			this->panel3->ResumeLayout(false);
			this->panel3->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->tabPage1->ResumeLayout(false);
			this->gb_saveparam->ResumeLayout(false);
			this->gb_saveparam->PerformLayout();
			this->gb_writingvideo->ResumeLayout(false);
			this->gb_writeoption->ResumeLayout(false);
			this->gb_writeoption->PerformLayout();
			this->gb_saveresult->ResumeLayout(false);
			this->gb_saving_as->ResumeLayout(false);
			this->gb_saving_as->PerformLayout();
			this->tab_tracking->ResumeLayout(false);
			this->gb_referencepoint->ResumeLayout(false);
			this->gb_referencepoint->PerformLayout();
			this->gb_detecterror->ResumeLayout(false);
			this->gb_detecterror->PerformLayout();
			this->gb_determinesize->ResumeLayout(false);
			this->gb_determinesize->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->trackBar_sizebinary))->EndInit();
			this->gb_boxarea->ResumeLayout(false);
			this->gb_boxarea->PerformLayout();
			this->gb_bonecalc->ResumeLayout(false);
			this->gb_bonecalc->PerformLayout();
			this->gb_tracking->ResumeLayout(false);
			this->gb_tracking->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->track_num_joint_points))->EndInit();
			this->gb_smoothing->ResumeLayout(false);
			this->gb_smoothing->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_beta))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_alpha))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->smoothing_param_seq_length))->EndInit();
			this->tab_load->ResumeLayout(false);
			this->gb_setparam->ResumeLayout(false);
			this->gb_setparam->PerformLayout();
			this->gb_setbackground->ResumeLayout(false);
			this->gb_setbackground->PerformLayout();
			this->gb_createbackground->ResumeLayout(false);
			this->gb_createbackground->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->tab->ResumeLayout(false);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBoxDone))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion



		////////////////////////////////
		/*Invoking Functions*/
		///////////////////////////////
        //////////関数内で呼び出す関数//

private: void textToLog(System::String^ text)
		 {
			 log_viewer->Text +=  "\n" + text;
			 log_viewer->SelectionStart = log_viewer->Text->Length;
			 log_viewer->ScrollToCaret();
		 }


private: void cvtMat2uchar(cv::Mat img, uchar *uchar_img)
{
	int width = img.cols;
	int height = img.rows;

	for(int i=0;i<width*height;i++)
	{
		uchar_img[i] = img.data[i];
	}
}



public: std::string cvtStrStr(System::String^ str)
{
	char* temp_char = (char*)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(str).ToPointer();
	std::string out(temp_char);
	return out;
}



private: std::vector<std::string> split(std::string str, std::string delim)
	{


		std::vector<std::string> result;
		int cutAt;
		while( (cutAt = str.find_first_of(delim)) != str.npos )	//(delim)で指定した文字列が初めに出てくる位置を取得 cutAtに代入
		{
			if(cutAt > 0)
			{
				result.push_back(str.substr(0, cutAt));



			}else{
				result.push_back("NO_DATA");
				//cout<<"スペース有" <<endl;
			}

			str = str.substr(cutAt + 1);
		}
		if(str.length() > 0)
		{
			result.push_back(str);
		}
		return result;
	}





		 /////////////////////
		 /*Drawing of Images*/
		 /////////////////////

private: System::Void DrawCvImage(IplImage *CvImage, PictureBox^ pbox_name) 
		 { 
			 //Drawing IplImage in Picture Box

			 //
			 //  Graphicsの確保 
			 //
			 
			 if ((pbox_name->Image == nullptr) 
				 || (pbox_name->Width != CvImage->width) 
				 || (pbox_name->Height != CvImage->height)){ 
					 //ピクチャボックスをビットマップ画像サイズに合わせる 
					 pbox_name->Width = CvImage->width; 
					 pbox_name->Height = CvImage->height; 
					 //PictureBoxと同じ大きさのBitmapクラスを作成する。 
					 Bitmap^ bmpPicBox = gcnew Bitmap(pbox_name->Width, pbox_name->Height); 
					 //空のBitmapをPictureBoxのImageに指定する。 
					 pbox_name->Image = bmpPicBox; 
			 }

			 //Graphicsクラスの作成(空のピクチャボックスからGraphicsを作成する) 
			 Graphics^g = Graphics::FromImage(pbox_name->Image); 

			 /////////////////////////////////// 
			 //  IplImageからBitmapの確保 
			 //      
			 //IplImageの画像データのポインタ(imageData)をBitmapへ渡し、Bitmapを作成 
			 Bitmap^ bmp = gcnew Bitmap(CvImage->width, CvImage->height, CvImage->widthStep, 
				 System::Drawing::Imaging::PixelFormat::Format24bppRgb, IntPtr(CvImage->imageData)); 

			 /////////////////////////////////// 
			 //  画像の描画 
			 // 
			 //ピクチャボックスのImageへ 
			 g->DrawImage(bmp, 0, 0, CvImage->width, CvImage->height);  
			 pbox_name->Refresh(); 

			 delete g; 
		 }




private: void DrawMatImageC1(cv::Mat mimg, PictureBox^ pbox)
		 {
			 int width = mimg.cols;
			 int height = mimg.rows;

			 IplImage* temp_iplimg_to_show = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
			 cv::Mat colormat(cv::Size(width,height),CV_8UC3);
			 for(int y=0;y<height;y++)
			 {
				 for(int x=0;x<width;x++)
				 {
					 colormat.data[3*(y*width+x) + 0] = mimg.data[y*width+x];
					 colormat.data[3*(y*width+x) + 1] = mimg.data[y*width+x];
					 colormat.data[3*(y*width+x) + 2] = mimg.data[y*width+x];
				 }
			 }
			 //cv::Mat for_resize_mat;
			 //cv::Size dsize(pbox->Width,pbox->Height);
			 //cv::resize(colormat,for_resize_mat,dsize);
			 matToIplImage3(colormat,temp_iplimg_to_show);
			 DrawCvImage(temp_iplimg_to_show,pbox);
			 cvReleaseImage(&temp_iplimg_to_show);
		 }



private: void DrawMatImageC3(cv::Mat mimg, PictureBox^ pbox)
		 {
			 int width = mimg.cols;
			 int height = mimg.rows;

			 //cv::Mat for_resize_mat;
			 //cv::Size dsize(pbox->Width,pbox->Height);
			 //cv::resize(mimg,for_resize_mat,dsize);
			 IplImage* temp_iplimg_to_show = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
			 matToIplImage3(mimg,temp_iplimg_to_show);
			 DrawCvImage(temp_iplimg_to_show,pbox);
			 cvReleaseImage(&temp_iplimg_to_show);
		 }




private: void DrawMatResizedC3(cv::Mat mimg, PictureBox^ pbox)
		 {
			 if (mimg.data == NULL)//エラー処理eijwat ver3.1
			 {
				 if (englishToolStripMenuItem->Checked == false)
				 {
					 textToLog("\n・動画データが破損している可能性があります。\n");
				 }
				 else
				 {
					 textToLog("\n・Error has been detected !!!.\n");
				 };
			 return; };

			 int width = pbox->Width;
			 int height = pbox->Height;

			 cv::Mat mimg_resized;

			 cv::resize(mimg,mimg_resized,cv::Size(width,height));

			 if (mimg_resized.data == NULL)//エラー処理eijwat ver3.1
			 {
				 if (englishToolStripMenuItem->Checked == false)
				 {
					 textToLog("\n・動画データが破損している可能性があります。\n");
				 }
				 else
				 {
					 textToLog("\n・Error has been detected !!!.\n");
				 };
				 return;
			 };


			 DrawMatImageC3(mimg_resized,pbox);
		 }



private: void DrawMatResizedC1(cv::Mat mimg, PictureBox^ pbox)
		 {
			 
			 if (mimg.data == NULL)//エラー処理eijwat ver3.2
			 {
				 return;
			 };
			 
			 int width = pbox->Width;
			 int height = pbox->Height;
			 cv::Mat mimg_resized;
			 cv::resize(mimg,mimg_resized,cv::Size(width,height));

			 if (mimg_resized.data == NULL)//エラー処理eijwat ver3.2
			 {
				 return;
			 };

			 DrawMatImageC1(mimg_resized,pbox);
		 }



private: void matToIplImage3(cv::Mat mimg, IplImage* iimg)//Self-made Function which works well!
		  {
			  //IplImage は　imageDataのwidthStepを4バイト単位（0 4 8 , ... , 1024, 1028,...)とするが，
			  //単純にMatの画素値をIplImageの画素値に代入すると
			  //widthStep = 3 * width (3はチャネル数）　となってしまい，
			  //IplImageをbitmapに変換するときに画像が斜めってしまうので，
			  //widthStepを 3*width　よりも大きい 4の倍数にして，
			  // width, height は　Matと同様にすることで，
			  // bitMapに変換するときにうまくいく！！！
			  //なるほど。。。


			  int width = mimg.cols;
			  int height = mimg.rows;
			  int widthstep = 3*width;
			  if(widthstep%4!=0)
			  {
				  widthstep = ((3*width)/4 + 1 ) * 4 ;
			  }
			  for(int y=0;y<height;y++)
			  {
				  for(int x=0;x<width;x++)
				  {
					  iimg->imageData[y*widthstep + x*3 +0] = (signed char)mimg.data[(y*width+x)*3+0];
					  iimg->imageData[y*widthstep + x*3 +1] = (signed char)mimg.data[(y*width+x)*3+1];
					  iimg->imageData[y*widthstep + x*3 +2] = (signed char)mimg.data[(y*width+x)*3+2];
				  }
			  }
			  iimg->width = width;
			  iimg->height = height;
			  iimg->widthStep = widthstep;
		  }



private: void showDisp()
		 {

			 int fn = iframe_now;

			cv::Mat mimg(cv::Size(width0,height0),CV_8UC3,CV_RGB(0,0,0));


			 if(checkBox_showoriginal->Checked)
			 {

				 if (cap.isOpened()) {
					 cap.set(CV_CAP_PROP_POS_FRAMES, fn);
					 do{
						 cap >> mimg;		// キャプチャ
					 } while (mimg.empty());

				 };




			 }

			 /////////////////////////////////////////////ここでmimgにいろいろ描くよよよよよよよよよよよよ～ん

			//基準点//ver3.1a＝使わない
			 if (reference_point_set && cb_showrefpoint->Checked)
			 {
				 cv::circle(mimg, refpoint, 3, CV_RGB(0, 255, 0), -1, CV_AA);

			 }


			 /*トラッキング結果*/
			 if(tracking_done && checkBox_showmarkers->Checked)
			 {

				 cv::circle(mimg,heads[fn],4,CV_RGB(255,0,0),1,CV_AA);
				 cv::circle(mimg,tails[fn],3,CV_RGB(0,0,255),1,CV_AA);//もともとは半径４
				 /*//joints廃止に伴う変更eijwat
				 
				 for(int i=0;i<(int)joints[fn].size();i++)
				 {
				 cv::circle(mimg,joints[fn][i],1,CV_RGB(0,255,255),1,CV_AA);
				 }
				 
				 */

			 }


			 /*水槽領域指定中*///ver3.1
			 drawBox(mimg);

			 //ズームで描くか、そのまま描くか。
			 if(cb_zoomin->Checked)
			 {
				 cv::Mat mimg_roi = mimg(aquabox);
				 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.height*pictureBox->Width/pictureBox->Height,aquabox.height),CV_8UC3,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(mimgshow.cols*0.5-aquabox.width*0.5,0,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC3(mimgshow,pictureBox);
				 }
				 else
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.width,aquabox.width*pictureBox->Height/pictureBox->Width),CV_8UC3,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(0,mimgshow.rows*0.5-aquabox.height*0.5,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC3(mimgshow,pictureBox);
				 }				 
				 
			 }
			 else
			 {
				 DrawMatResizedC3(mimg, pictureBox);
				 
			 }

		 }




//TrackBar
private: void showTrackInfo()
		 {
			 //trackbarImgの初期化
			 cv::Rect rectangl(cv::Point(0,0),trackbarImg.size());
			 cv::rectangle(trackbarImg,rectangl,CV_RGB(255,255,255),-1);

			 for(int i=0;i<(int)suspecious_frame.size();i++)
			 {
				 drawTrackbarLine(trackbarImg,pictureBox_trackbar,suspecious_frame[i],CV_RGB(255,0,0));
			 }
		 }




//BackGround Images
private: void createBackground()
			 {
				 if(bcgd1st_set && bcgd2nd_set && bcgd3rd_set)
				 {
					 //背景画像はグレースケール画像
					 bcgdImg =cv::Mat::zeros(bcgd1st.rows, bcgd1st.cols, CV_8UC1);
					 int width = bcgdImg.cols;
					 int height = bcgdImg.rows;
					 for(int i=0; i<width*height;i++)
					 {
						 int dif12, dif13, dif23;
						 dif12 = abs((int)bcgd1st.data[i] - (int)bcgd2nd.data[i]);
						 int min=dif12;
						 int min_at = 12;
						 dif13 = abs((int)bcgd1st.data[i] - (int)bcgd3rd.data[i]);
						 if(min > dif13)
						 {
							 min = dif13;
							 min_at = 13;
						 }
						 dif23 = abs((int)bcgd2nd.data[i] - (int)bcgd3rd.data[i]);
						 if(min > dif23)
						 {
							 min = dif23;
							 min_at = 23;
						 }

						 if(min_at==12)
						 {
							 bcgdImg.data[i] = cvRound((double)((int)bcgd1st.data[i]+(int)bcgd2nd.data[i])*0.5);
						 }else if(min_at==13)
						 {
							 bcgdImg.data[i] = cvRound((double)((int)bcgd1st.data[i]+(int)bcgd3rd.data[i])*0.5);
						 }else
						 {
							 bcgdImg.data[i] = cvRound((double)((int)bcgd2nd.data[i]+(int)bcgd3rd.data[i])*0.5);
						 }
					 }
					 background_set = true;
					 gb_boxarea->Enabled = true;
					 //gb_determinesize->Enabled = true;


				 }
		 }




//Drawing Aquarium Area
private: void drawBox(cv::Mat& mimg)
		 {
			 cv::Point md;
			 cv::Point mc;
			 if(cb_zoomin->Checked)
				 {
					 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {

						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 md.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 md.y=cvRound(ybar+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 mc.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 mc.y=cvRound(ybar+aquabox.y);
						 
					 }
					 else
					 {

						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 md.x=cvRound(xbar+aquabox.x);
						 md.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 mc.x=cvRound(xbar+aquabox.x);
						 mc.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);
						 
					 }
				 }
			 else
			 {


				 md.x = cvRound((double)mousedown.x * (double)Form1::width0/(double)pictureBox->Width);
				 md.y = cvRound((double)mousedown.y*(double)Form1::height0/(double)pictureBox->Height);

				 mc.x = cvRound((double)mousenow.x * (double)Form1::width0/(double)pictureBox->Width);
				 mc.y = cvRound((double)mousenow.y*(double)Form1::height0/(double)pictureBox->Height);
			 }
			 int width = mc.x - md.x;
			 int height =mc.y-md.y;


			 if(setting_box_area)
			 {
				 if(drawing_box_area)
				 {
					 cv::rectangle(mimg,cv::Rect(md.x,md.y,width,height),CV_RGB(100,100,255),1);
				 }
			 }
			 else if(box_area_set && cb_showboxarea->Checked)
			 {
				 cv::rectangle(mimg,aquabox,CV_RGB(0,0,255),2);
			 }

			 if(setting_roi)
			 {
				 for(int i=0;i<(int)ROIs.size()-1;i++)
				 {
					 cv::rectangle(mimg,ROIs[i],ROI_color[i],2);

				 }
				 if(drawing_roi)
				 {
					 
					 cv::rectangle(mimg,cv::Rect(md.x,md.y,width,height),ROI_color[ROIs.size()-1],1);
				 }
			 }
			 else if(roi_set && cb_showroi->Checked)
			 {
				 for(int i=0;i<(signed int)ROIs.size();i++)
				 {
					 cv::rectangle(mimg,ROIs[i],ROI_color[i],2);
					 
				 }
			 }

		 }




private: void showROIsize(int number)
		 {
			 textBox_roi_ltx->Text=""+ROI_realsize[number].x;
			 textBox_roi_lty->Text=""+ROI_realsize[number].y;
			 textBox_roi_width->Text=""+ROI_realsize[number].width;
			 textBox_roi_height->Text=""+ROI_realsize[number].height;
		 }




//framne-by-frame playBack
private: void movePlayerPosForward(double num)
	{
		//if (trackBar->Value + num < trackBar->Maximum)
		if(trackBar->Value+num < trackBar->Maximum+1)//eijwat
		{
			iframe_now += (int)num;
			label_time->Text = ""+iframe_now;
			trackBar->Value += (int)num;
		}
		else
		{

			timer->Enabled = false;
			b_play->Text ="Play";
		}

		cv::Mat trackbarImg_now = trackbarImg.clone();

		drawTrackbarLine(trackbarImg_now,pictureBox_trackbar,iframe_now,CV_RGB(0,255,255));
		DrawMatResizedC3(trackbarImg_now,pictureBox_trackbar);

		showDisp();
	}




private:void movePlayerPosBack(double num)
	{
		if(trackBar->Value - num >=0){
			trackBar->Value -= (int)num;
			iframe_now -= (int)num;
			label_time->Text = ""+iframe_now;
			//log_viewer->Text += "\nPosition: "+player_position;
		}
		else
		{
			trackBar->Value  = 0;
			iframe_now = 0;
		}
		cv::Mat trackbarImg_now = trackbarImg.clone();
		drawTrackbarLine(trackbarImg_now,pictureBox_trackbar,iframe_now,CV_RGB(0,255,255));
		DrawMatResizedC3(trackbarImg_now,pictureBox_trackbar);
		showDisp();
		}





private: void drawTrackbarLine(cv::Mat trackbarImg, PictureBox^  pbox,int itime, cv::Scalar color)
		 {
			 int width = trackbarImg.cols;
			 int height = trackbarImg.rows;
			 
			 int x = cvRound((double)width*(double)itime/(double)num_frames);
			 int x_next = cvRound((double)width*(double)(itime+1)/(double)num_frames);
			 cv::Point pt1(x,0);
			 cv::Point pt2(x,height);
			 
			 if (x_next > x+1)
			 {
				 cv::rectangle(trackbarImg,cv::Rect(pt1,cv::Size(x_next-x,height)),color,-1,CV_AA);
			 }
			 else
			 {
				cv::line(trackbarImg,pt1,pt2,color,1);
			 }
			 DrawMatResizedC3(trackbarImg,pbox);
		 }





private: void drawMarked(bool mouseon, int sttime, int lsttime, cv::Scalar color)
		 {
			 cv::Mat mimg(cv::Size(pictureBoxDone->Width,pictureBoxDone->Height),CV_8UC3,CV_RGB(255,255,255));

			 		 
			 for(std::set<int>::iterator it=head_marked.begin();it!=head_marked.end();it++)
			 {
				 int t = (*it);
				 if(tail_marked.find(t) != tail_marked.end())
				 {
					 int width = mimg.cols;
					 int height = mimg.rows;
					 int x = cvRound((double)width*(double)t/(double)num_frames);
					 int x_next = cvRound((double)width*(double)(t+1)/(double)num_frames);
					 cv::Point pt1(x,0);
					 cv::Point pt2(x,height);

					 if(mouseon)
					 {
						 if(t>=sttime && t <=lsttime)
						 {
							 if (x_next > x+1)
							 {
								 cv::rectangle(mimg,cv::Rect(pt1,cv::Size(x_next-x,height)),color,-1,CV_AA);
							 }
							 else
							 {
								 cv::line(mimg,pt1,pt2,color,1);
							 }
						 }
						 else
						 {
							 if (x_next > x+1)
							 {
								 cv::rectangle(mimg,cv::Rect(pt1,cv::Size(x_next-x,height)),CV_RGB(0,255,255),-1,CV_AA);
							 }
							 else
							 {
								 cv::line(mimg,pt1,pt2,CV_RGB(0,255,255),1);
							 }
						 }
					 }
					 else
					 {
						 if (x_next > x+1)
							 {
								 cv::rectangle(mimg,cv::Rect(pt1,cv::Size(x_next-x,height)),CV_RGB(0,255,255),-1,CV_AA);
							 }
							 else
							 {
								 cv::line(mimg,pt1,pt2,CV_RGB(0,255,255),1);
							 }
					 }
				 }
			 }
			 DrawMatResizedC3(mimg,pictureBoxDone);

		 }





//////////////////////////////////////////////////////////////////////////////
///////////////////フォームからのアクションに対する振る舞い///////////////////
///////////////////Response to Form actions///////////////////////////////////
//////////////////////////////////////////////////////////////////////////////


private: System::Void b_loadvideofile_Click(System::Object^  sender, System::EventArgs^  e) {
			 //ﾌｧｲﾙを開くダイアログの作成 
			 OpenFileDialog^ dlg = gcnew OpenFileDialog; 
			 //ファイルフィルタ 
			 dlg->Filter = "動画ファイル(*.avi,*.mp4)|*.avi;*.mp4"; 
			 //ダイアログの表示 
			 if (dlg->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return; 
			 //System::String^型のファイル名 
			 strfilename = dlg->FileName;

			 //パスを含まないファイル名
			 std::vector<std::string> fnames0;
			 fnames0 = split(cvtStrStr(strfilename),"\\");
			 filename_nopath = (*(fnames0.end()-1));

			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・動画ファイルを読み込みました.\n　→背景画像の作成（または読込）");
			 }
			 else
			 {
				 textToLog("・A video file has been loaded.\n	→Make a background image (or load one)");
			 }
			 cap.open(cvtStrStr(strfilename));
			 trackBar->Enabled = true;
			 trackBar->Maximum = (int)cap.get(CV_CAP_PROP_FRAME_COUNT)-1;
			 num_frames = (int)cap.get(CV_CAP_PROP_FRAME_COUNT);
			 label_numframes->Text = ""+(num_frames-1);

			 video_set = true;
			 gb_setbackground->Enabled = true;


			 panel_playercontrol->Enabled = true;
			 gb_speedcontrol->Enabled = true;

			 width0 = (int)cap.get(CV_CAP_PROP_FRAME_WIDTH);
			 height0 = (int)cap.get(CV_CAP_PROP_FRAME_HEIGHT);

			 boxarea = cv::Rect(cv::Point(0,0),cv::Size(width0,height0));//boxareaの初期値を設定（重要＝動画サイズに固定）ver3.1
			 aquabox = cv::Rect(cv::Point(0, 0), cv::Size(width0, height0));//aquaboxの初期値を設定ver3.1（初期値は動画サイズ）

			 if(englishToolStripMenuItem->Checked==false)
			 {
			 label_videofilename->Text = "ファイル名: " + strfilename;
			 }
			 else
			 {
				 label_videofilename->Text = "Filename: " + strfilename;
			 
			 }
			 DrawMatResizedC3(trackbarImg,pictureBox_trackbar);

			 //初期化処理（続けて読む場合に必要
			 //時間
			 iframe_now = 0;
			 trackBar->Value = 0;

			 //結果
			 heads.clear();
			 tails.clear();
			 //joints.clear();//joints廃止に伴う変更eijwat
			 calc_pts.clear();
			 suspecious_frame.clear();
			 checkBox_showmarkers->Enabled = false;
			 tracking_done= false;
			 tracking_now =false;

			 //結果コンテイナーの初期化
			 cv::Point pt_init(0,0);
			 /*//joints廃止に伴う変更eijwat
			 std::vector<cv::Point> jts_init;
			 for(int n=0;n<(int)track_num_joint_points->Value;n++)
			 {
				 jts_init.push_back(pt_init);
			 }*/
			 for(int t=0;t<(int)cap.get(CV_CAP_PROP_FRAME_COUNT);t++)
			 {
				 heads[t] = pt_init;
				 tails[t] = pt_init;
				 //joints[t] = jts_init;//joints廃止に伴う変更eijwat
			 }

				 
				 


			 //////////////////////初期設定////////
			 //Initial Configuration //////////////


			 //対象領域
			 show_box_area = false;
			 setting_box_area = false;
			 drawing_box_area = false;
			 box_area_set = false;
			 cb_showboxarea->Enabled = false;

			 //ROI
			 setting_roi = false;
			 drawing_roi = false;
			 roi_set = false;
			 roi_x_set = false;
			 roi_y_set = false;
			 roi_width_set = false;
			 roi_height_set = false;
			 cb_showroi->Enabled = false;
			 b_execanal->Enabled = false;
			 b_save_roianal->Enabled = false;
			  b_anal_result_to_clip->Enabled = false;
			 ROIs.clear();
			 ROI_realsize.clear();
			 ROI_targetline.clear();
	         ROI_targetangle.clear();
			 ROI_whenhot.clear();
		     ROI_totalhot.clear();

			 //トラックバー画像
			 cv::rectangle(trackbarImg,cv::Rect(cv::Point(0,0),trackbarImg.size()),CV_RGB(255,255,255),-1);
			 DrawMatResizedC3(trackbarImg,pictureBox_trackbar);

			 drawMarked(true,0,num_frames-1,CV_RGB(255,255,255));
			 
			 /*selecting the target frames*/
			target_frame_set = false;
			sttime = 0;
			lsttime = 0;
			sttime_temp = 0;
			lsttime_temp = 0;
			sttime_mdown  = false;
			on_done_frames = false;
			head_marked.clear();
			tail_marked.clear();

			 //サイズ決定
			 setting_size = false;
			 size_fish = 300;
			 bin_threshold = 1;
			 size_set = false;
			 gb_tracking->Enabled = false;

			 //誤検出修正
			 jump_i = 0;
			 jump_frame.clear();

			 //インターフェース初期設定
			 gb_tracking->Enabled = false;
			 gb_detecterror->Enabled = false;
			 gb_smoothing->Enabled = false;
			 gb_bonecalc->Enabled = false;
			 b_skip_back->Enabled = false;
			 b_skip_ahead->Enabled = false;

			 comboBox_ROI->Items->Clear();
			 comboBox_roianal->Items->Clear();
			 comboBox_ROI->Text = "";
			 comboBox_roianal->Text = "";
			 textBox_roi_ltx->Text = "";
			 textBox_roi_lty->Text ="";
			 textBox_roi_width->Text = "";
			 textBox_roi_height->Text = "";

			 cb_zoomin->Checked=false;
			 cb_zoomin->Enabled=false;


			 showDisp();
		 }



private: System::Void b_loadbackground_Click(System::Object^  sender, System::EventArgs^  e) {
			 //ﾌｧｲﾙを開くダイアログの作成 
			 OpenFileDialog^ dlg = gcnew OpenFileDialog; 
			 //ファイルフィルタ 
			 dlg->Filter = "背景画像ファイル(*.png, *.jpg)|*.png;*.jpg"; 
			 //ダイアログの表示 
			 if (dlg->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return; 
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・背景画像を読み込みました．\n    →トラッキングタブにて対象領域の指定");
			 }
			 else
			 {
				 textToLog("・The background image has been loaded.\n	→load a setting file (skippable)\n	→Set a box in the tracking tab.");
			 }
			 bcgdImg = cv::imread(cvtStrStr(dlg->FileName),0);
			 DrawMatResizedC1(bcgdImg,pictureBox);
			 background_set = true;
			 gb_setparam->Enabled = true;
			 gb_boxarea->Enabled = true;
			 gb_determinesize->Enabled = true;

			 if(englishToolStripMenuItem->Checked==false)
			 {
				 label_bcgdimagename->Text = "ファイル名: " + dlg->FileName;
			 }
			 else
			 {
				 label_bcgdimagename->Text = "Filename: " + dlg->FileName;
			 }
		 }




private: System::Void b_showbackground_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(background_set)
			 {
				 DrawMatResizedC1(bcgdImg,pictureBox);
			 }else{
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("背景画像の作成（読込）を行なって下さい．");
				 }
				 else
				 {
					 MessageBox::Show("Make/Load a background image frist.");
				 }
			 }
		 }



private: System::Void b_1stimage_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(video_set){
				 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
				 cap>>bcgd1st;
				 cv::cvtColor(bcgd1st,bcgd1st,CV_RGB2GRAY);
				 bcgd1st_set = true;
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・1枚目の画像を指定しました．");
				 }
				 else
				 {
					 textToLog("・The first frame was captured.");
				 }
			 }else{
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("はじめに動画ファイルを読み込んで下さい．");
				 }
				 else
				 {
					 MessageBox::Show("Load a video file first.");
				 }
			 }
		 }



private: System::Void b_2ndimage_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(video_set){
				 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
				 cap>>bcgd2nd;
				 cv::cvtColor(bcgd2nd,bcgd2nd,CV_RGB2GRAY);
				 bcgd2nd_set = true;
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・2枚目の画像を指定しました．");
				 }
				 else
				 {
					 textToLog("・The second frame was captured.");
				 }

			 }else{
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("はじめに動画ファイルを読み込んで下さい．");
				 }
				 else
				 {
					 MessageBox::Show("Load a video file first.");
				 }
			 }
		 }



private: System::Void b_3rdimage_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(video_set){
				 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
				 cap>>bcgd3rd;
				 cv::cvtColor(bcgd3rd,bcgd3rd,CV_RGB2GRAY);
				 bcgd3rd_set = true;
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・3枚目の画像を指定しました．");
				 }
				 else
				 {
					 textToLog("・The third frame was captured.");
				 }

			 }else{
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("はじめに動画ファイルを読み込んで下さい．");
				 }
				 else
				 {
					 MessageBox::Show("Load a video file first.");
				 }
			 }
		 }



private: System::Void b_createbackground_Click(System::Object^  sender, System::EventArgs^  e) {

	        if (bcgd1st_set && bcgd2nd_set && bcgd3rd_set){ createBackground(); }//eijwat ver3.2
			else{ return; }

			 
			 gb_setbackground->Enabled = true;
			 b_savebcgdimage->Enabled = true;//ver3.1

			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・背景画像を作成しました．\n    →トラッキングタブにてサイズ指定");//eijwat 3.1
			 }
			 else
			 {
				 textToLog("・A background image has been created");
			 }
			 DrawMatResizedC1(bcgdImg,pictureBox);
		 }



/**********TrackBar******************/
private: System::Void trackBar_Scroll(System::Object^  sender, System::EventArgs^  e) {
			 iframe_now = trackBar->Value;
			 
			// label_now->Text = ""+ iframe_now;
			 cv::Mat trackbarImg_now = trackbarImg.clone();
			 drawTrackbarLine(trackbarImg_now,pictureBox_trackbar,iframe_now,CV_RGB(0,255,255));
			 DrawMatResizedC3(trackbarImg_now,pictureBox_trackbar);
			 //textToLog("Position: "+iframe_now);
			// label_position->Text = ""+player_position;
			 showDisp();
			 
			
		 }



/*********Aquarium Area***************************/
private: System::Void b_set_boxarea_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・画面上で水槽部分を選択して下さい");
			 }
			 else
			 {
				 textToLog("・Select the aquarium by clicking on the screen");
			 }
			 setting_box_area = true;
			 tab->Enabled = false;
			 trackBar->Enabled = false;
			 panel_playercontrol->Enabled = false;
			 gb_speedcontrol->Enabled = false;
			 checkBox_showoriginal->Enabled = false;
			 showDisp();
		 }



//pictureBoxでのマウスイベント：水槽指定／ROI指定／座標修正
private: System::Void pictureBox_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 mousedown.x = e->X;
			 mousedown.y = e->Y;


			 if (setting_reference_point){
				 //基準点の指定
				 drawing_reference_point = true;
				 showDisp();

			 }
			 else if(setting_box_area)
			 {
				 //水槽領域指定
				 drawing_box_area = true;
				 showDisp();
			 }
			 else if(setting_roi)
			 {
				 //ROI指定
				 drawing_roi = true;

				 if(cb_zoomin->Checked)
				 {
					 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {
						 double w = (double)aquabox.width * (double)pictureBox->Height / (double)aquabox.height;
						 double xsclt = pictureBox->Width*0.5-w*0.5;
						 
						 double mousedownx2,mousedowny2;
						 mousedownx2 = aquabox.x + ((double)mousedown.x -xsclt)* (double)aquabox.height / (double)pictureBox->Height; //画像中の座標へ
						 mousedownx2 = mousedownx2 * (double)pictureBox->Width/(double)width0;//スクリーン上の座標へ

						 mousedowny2 = aquabox.y + (double)mousedown.y*(double)aquabox.height /(double)pictureBox->Height; 
						 mousedowny2 = mousedowny2 * (double)pictureBox->Height/(double)height0;
						 (*(ROI_realsize.end()-1)).x = cvRound((double)mousedownx2 * (double)boxarea_realsize.x/pictureBox->Width
							 *(double)width0/(double)aquabox.width
							 - aquabox.x * boxarea_realsize.x/aquabox.width);

						 (*(ROI_realsize.end()-1)).y = cvRound((double)mousedowny2 * (double)boxarea_realsize.y/pictureBox->Height
							 *(double)height0/(double)aquabox.height
							 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);
					 }
					 else
					 {
						 double h = (double)aquabox.height * (double)pictureBox->Width/ (double)aquabox.width;
						 double ysclt = pictureBox->Height*0.5-h*0.5;
						 double mousedownx2,mousedowny2;

						 mousedownx2 = aquabox.x + (double)mousedown.x * (double)aquabox.width / (double)pictureBox->Width; //画像中の座標へ
						 mousedownx2 = mousedownx2 * (double)pictureBox->Width/(double)width0;//スクリーン上の座標へ

						 mousedowny2 = aquabox.y + ((double)mousedown.y - ysclt)*(double)aquabox.width /(double)pictureBox->Width; 
						 mousedowny2 = mousedowny2 * (double)pictureBox->Height/(double)height0;
						 (*(ROI_realsize.end()-1)).x = cvRound((double)mousedownx2 * (double)boxarea_realsize.x/pictureBox->Width
							 *(double)width0/(double)aquabox.width
							 - aquabox.x * boxarea_realsize.x/aquabox.width);

						 (*(ROI_realsize.end()-1)).y = cvRound((double)mousedowny2 * (double)boxarea_realsize.y/pictureBox->Height
							 *(double)height0/(double)aquabox.height
							 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);

					 }
				 }
				 else
				 {
					 (*(ROI_realsize.end()-1)).x = cvRound((double)mousedown.x * (double)boxarea_realsize.x/pictureBox->Width
						 *(double)width0/(double)aquabox.width
						 - aquabox.x * boxarea_realsize.x/aquabox.width);

					 (*(ROI_realsize.end()-1)).y = cvRound((double)mousedown.y * (double)boxarea_realsize.y/pictureBox->Height
						 *(double)height0/(double)aquabox.height
						 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);
				 }
				 textBox_roi_ltx->Text = ""+(*(ROI_realsize.end()-1)).x;
				 textBox_roi_lty->Text = ""+(*(ROI_realsize.end()-1)).y;


				showDisp();
			 }
			 else if (tracking_done && iframe_now<(int)heads.size()) //マウスによる座標の修正イベント
			 {
				 cv::Point new_pt(cvRound((double)e->X * (double)Form1::width0/(double)pictureBox->Width),
					 cvRound((double)e->Y*(double)Form1::height0/(double)pictureBox->Height));

				 if(cb_zoomin->Checked)
				 {
					 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = (double)e->X;
						 y = (double)e->Y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 new_pt.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 new_pt.y=cvRound(ybar+aquabox.y);
					 }
					 else
					 {
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = (double)e->X;
						 y = (double)e->Y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 new_pt.x=cvRound(xbar+aquabox.x);
						 new_pt.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);
					 }
				 }


				 //左ボタン＝ヘッド位置の修正
				 if(e->Button == System::Windows::Forms::MouseButtons::Left)
				 {
					 int fn = iframe_now;
					 heads[fn].x = new_pt.x;
					 heads[fn].y = new_pt.y;
					 head_marked.insert(fn);
					 
					 /*//joints廃止に伴う変更eijwat
					 gb_boxarea->Enabled = false;
					 gb_ROI->Enabled = false;
					 //gb_smoothing->Enabled = false;//joints廃止に伴う変更eijwat
					 gb_tracking->Enabled = false;
					 gb_bonecalc->Enabled = false;
					 gb_bonecalc->Text ="Calculating...";
					 gb_determinesize->Enabled =false;
					 panel_playercontrol->Enabled = false;
					 checkBox_showmarkers->Enabled = false;
					 checkBox_showmarkers->Checked = true;

					 if(recalcBone(fn)<0)
					 {
					 //textToLog("再計算失敗");
					 }
					 gb_boxarea->Enabled = true;
					 gb_ROI->Enabled = true;
					 //gb_smoothing->Enabled = true;//joints廃止に伴う変更eijwat
					 gb_tracking->Enabled = true;
					 gb_bonecalc->Enabled = true;
					 //gb_bonecalc->Text = "This frame";
					 gb_determinesize->Enabled =true;
					 panel_playercontrol->Enabled = true;
					 checkBox_showmarkers->Enabled = true;
					 					 
					 */



					 showDisp();

					 if(target_frame_set)
					 {
						 drawMarked(true,sttime,lsttime,CV_RGB(0,30,255));
					 }
					 else
					 {
						 drawMarked(false,0,0,CV_RGB(0,0,0));
					 }
					 if(cb_forclick->Checked)
					 {
						 movePlayerPosForward(1.0);
					 }

				//右ボタン＝テール位置の修正
				 }else if(e->Button == System::Windows::Forms::MouseButtons::Right)
				 {
					 int fn = iframe_now;
					 tails[fn].x = new_pt.x;
					 tails[fn].y = new_pt.y;
					 tail_marked.insert(fn);
					 

					 /*//joints廃止に伴う変更eijwat
					 gb_boxarea->Enabled = false;
					 gb_ROI->Enabled = false;
					 //gb_smoothing->Enabled = false;//joints廃止に伴う変更eijwat
					 gb_tracking->Enabled = false;
					 gb_bonecalc->Enabled = false;
					 gb_bonecalc->Text ="Calculating...";
					 gb_determinesize->Enabled =false;
					 panel_playercontrol->Enabled = false;
					 checkBox_showmarkers->Enabled = false;
					 checkBox_showmarkers->Checked = true;

					 if(recalcBone(fn)<0)
					 {
					 // textToLog("再計算失敗");
					 }
					 gb_boxarea->Enabled = true;
					 gb_ROI->Enabled = true;
					 //gb_smoothing->Enabled = true;//joints廃止に伴う変更eijwat
					 gb_tracking->Enabled = true;
					 gb_bonecalc->Enabled = true;
					 //gb_bonecalc->Text = "This frame";
					 gb_determinesize->Enabled =true;
					 panel_playercontrol->Enabled = true;
					 checkBox_showmarkers->Enabled = true;
					 
					 */




					 showDisp();


					 if(target_frame_set)
					 {
						 drawMarked(true,sttime,lsttime,CV_RGB(0,30,255));
					 }
					 else
					 {
						 drawMarked(false,0,0,CV_RGB(0,0,0));
					 }
					 if(cb_forclick->Checked)
					 {
						 movePlayerPosForward(1.0);
					 }
				 }else if(e->Button == System::Windows::Forms::MouseButtons::Middle)
				 {
					 movePlayerPosForward(1.0);
					 drawMarked(false,0,0,CV_RGB(0,0,0));
				 }

			 }
		 }



private: System::Void pictureBox_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 mousenow.x = e->X;
			 mousenow.y = e->Y;
			 if(setting_box_area)
			 {
				 showDisp();
			 }
			 if(setting_roi)
			 {
				 showDisp();
			 }
		 }



private: System::Void pictureBox_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
	
	
	if (setting_reference_point)//ver3.1 eijwat 使わないことにした
	{
		setting_reference_point = false;
		drawing_reference_point = false;
		tab->Enabled = true;
		trackBar->Enabled = true;
		panel_playercontrol->Enabled = true;
		gb_speedcontrol->Enabled = true;
		checkBox_showoriginal->Enabled = true;

		refpoint.x = mousedown.x;
		refpoint.y = mousedown.y;


		cb_showrefpoint->Enabled = true;
		cb_showrefpoint->Checked = true;

		reference_point_set = true;

		
		if (englishToolStripMenuItem->Checked == false)
		{
			textToLog("・基準点が設定されました\n    →魚領域サイズ指定\n        ([設定開始]クリック）\n ");
		}
		else
		{
			textToLog("・The reference point has been set\n	→Set the fish size\n		(click on [Start setting])\n ");
		}
		showDisp();	
	
	}
	
	
	else if(setting_box_area)
			 {
				 setting_box_area = false;
				 drawing_box_area = false;
				 tab->Enabled = true;
				 trackBar->Enabled = true;
				 panel_playercontrol->Enabled = true;
				 gb_speedcontrol->Enabled = true;
				 checkBox_showoriginal->Enabled = true;
				 gb_determinesize->Enabled = true;

				 int width, height;
				 if(cb_zoomin->Checked)
				 {
					 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {
						 cv::Point md,mc;
						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 md.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 md.y=cvRound(ybar+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 mc.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 mc.y=cvRound(ybar+aquabox.y);
						 width = mc.x - md.x;
						 height = mc.y - md.y;
						 aquabox = cv::Rect(md,cv::Size(width,height));
					 }
					 else
					 {
						 cv::Point md,mc;
						 
						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 md.x=cvRound(xbar+aquabox.x);
						 md.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 mc.x=cvRound(xbar+aquabox.x);
						 mc.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);

						 width = mc.x - md.x;
						 height = mc.y-md.y;
						 aquabox = cv::Rect(md,cv::Size(width,height));
					 }
				 }
				 else
				 {
					 cv::Point md(cvRound((double)mousedown.x * (double)Form1::width0/(double)pictureBox->Width),
						 cvRound((double)mousedown.y*(double)Form1::height0/(double)pictureBox->Height));

					 cv::Point mc(cvRound((double)mousenow.x * (double)Form1::width0/(double)pictureBox->Width),
						 cvRound((double)mousenow.y*(double)Form1::height0/(double)pictureBox->Height));

					 width = mc.x - md.x;
					 height =mc.y-md.y;
					 aquabox = cv::Rect(md,cv::Size(width,height));
				 }
				 
				 box_area_set = true;
				 cb_zoomin->Enabled=true;

				 for(int i=0; i<(signed int)ROIs.size(); i++)
				 {
					 ROI_realsize[i].x = cvRound((double)boxarea_realsize.x * (double)(ROIs[i].x - aquabox.x) /(double)aquabox.width);
					 ROI_realsize[i].width = cvRound((double)boxarea_realsize.x*(double)ROIs[i].width/(double)aquabox.width);
					 ROI_realsize[i].y = cvRound((double)boxarea_realsize.y * (double)(ROIs[i].y - aquabox.y) /(double)aquabox.height);
					 ROI_realsize[i].height = cvRound((double)boxarea_realsize.y*(double)ROIs[i].height/(double)aquabox.height);

					 if(comboBox_ROI->SelectedItem!="")
					 {
						 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
						 showROIsize(number);
					 }
				 }

				 cb_showboxarea->Enabled = true;
				 cb_showboxarea->Checked = true;

				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・水槽領域が設定されました\n    →魚領域サイズ指定\n        ([設定開始]クリック）");
				 }
				 else
				 {
					 textToLog("・The aquarium has been set\n	→Set the fish size\n		(click on [Start setting])");
				 }
				 showDisp();

			 }
			 else if(setting_roi)
			 {
				 setting_roi = false;
				 drawing_roi = false;

				 mousenow.x = e->X;
				 mousenow.y = e->Y;
				 cv::Point md,mc;
				  if(cb_zoomin->Checked)
				 {
					if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {

						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 md.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 md.y=cvRound(ybar+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*hb/hpic;
						 ybar = y*hb/hpic;
						 mc.x=cvRound(xbar-(hb*wpic/hpic*0.5)+wb*0.5+aquabox.x);
						 mc.y=cvRound(ybar+aquabox.y);
						 
					 }
					 else
					 {

						 //md
						 double x,y,hpic,wpic,hb,wb,xbar,ybar,xr,yr;
						 x = mousedown.x;
						 y = mousedown.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 md.x=cvRound(xbar+aquabox.x);
						 md.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);

						 //mc
						 x = mousenow.x;
						 y = mousenow.y;
						 hpic = (double)pictureBox->Height;
						 wpic = (double)pictureBox->Width;
						 hb = (double)aquabox.height;
						 wb = (double)aquabox.width;
						 xbar = x*wb/wpic;
						 ybar = y*wb/wpic;
						 mc.x=cvRound(xbar+aquabox.x);
						 mc.y=cvRound(ybar-(wb*hpic/wpic*0.5)+hb*0.5+aquabox.y);
						 
					 }
				  }
				  else
				  {
					  md.x = cvRound((double)mousedown.x * (double)Form1::width0/(double)pictureBox->Width);
					  md.y = cvRound((double)mousedown.y*(double)Form1::height0/(double)pictureBox->Height);

					  mc.x = cvRound((double)mousenow.x * (double)Form1::width0/(double)pictureBox->Width);
					  mc.y = cvRound((double)mousenow.y*(double)Form1::height0/(double)pictureBox->Height);
				  }
				  int width = mc.x - md.x;
				  int height =mc.y-md.y;

				  (*(ROIs.end()-1)).x = md.x;
				 (*(ROIs.end()-1)).y = md.y;
				 (*(ROIs.end()-1)).width = width;
				 (*(ROIs.end()-1)).height = height;
				 roi_set = true;
				 groupBox3->Enabled = true;
				 
				 textBox_roi_ltx->BackColor = System::Drawing::SystemColors::Window;
				 textBox_roi_lty->BackColor = System::Drawing::SystemColors::Window;
				 textBox_roi_width->BackColor = System::Drawing::SystemColors::Window;
				 textBox_roi_height->BackColor = System::Drawing::SystemColors::Window;

				 int real_br_x, real_br_y;

				 if(cb_zoomin->Checked)
				 {
					 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
					 {
						 double w = (double)aquabox.width * (double)pictureBox->Height/ (double)aquabox.height;
						 double xsclt = pictureBox->Width*0.5-w*0.5;

						 int mousenowx2,mousenowy2;

						 mousenowx2 = aquabox.x + ((double)mousenow.x - xsclt) * (double)aquabox.height / (double)pictureBox->Height;
						 mousenowx2 = mousenowx2 * (double)pictureBox->Width/(double)width0;//スクリーン上の座標へ
						 mousenowy2 = aquabox.y + (double)mousenow.y*(double)aquabox.height /(double)pictureBox->Height; 
						 mousenowy2 = mousenowy2 * (double)pictureBox->Height/(double)height0;

						 real_br_x = cvRound((double)mousenowx2 * (double)boxarea_realsize.x/pictureBox->Width
							 *(double)width0/(double)aquabox.width
							 - (double)aquabox.x * boxarea_realsize.x/(double)aquabox.width);

						 real_br_y = cvRound((double)mousenowy2 * (double)boxarea_realsize.y/pictureBox->Height
							 *(double)height0/(double)aquabox.height
							 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);

					 }
					 else
					 {
						 double h = (double)aquabox.height * (double)pictureBox->Width/ (double)aquabox.width;
						 double ysclt = pictureBox->Height*0.5-h*0.5;

						 int mousenowx2,mousenowy2;

						 mousenowx2 = aquabox.x + (double)mousenow.x * (double)aquabox.width / (double)pictureBox->Width;
						 mousenowx2 = mousenowx2 * (double)pictureBox->Width/(double)width0;//スクリーン上の座標へ
						 mousenowy2 = aquabox.y + ((double)mousenow.y - ysclt)*(double)aquabox.width /(double)pictureBox->Width; 
						 mousenowy2 = mousenowy2 * (double)pictureBox->Height/(double)height0;

						 real_br_x = cvRound((double)mousenowx2 * (double)boxarea_realsize.x/pictureBox->Width
							 *(double)width0/(double)aquabox.width
							 - (double)aquabox.x * boxarea_realsize.x/(double)aquabox.width);

						 real_br_y = cvRound((double)mousenowy2 * (double)boxarea_realsize.y/pictureBox->Height
							 *(double)height0/(double)aquabox.height
							 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);

					 }
				 }
				 else
				 {
					 real_br_x = cvRound((double)mousenow.x * (double)boxarea_realsize.x/pictureBox->Width
						 *(double)width0/(double)aquabox.width
						 - (double)aquabox.x * boxarea_realsize.x/(double)aquabox.width);

					 real_br_y = cvRound((double)mousenow.y * (double)boxarea_realsize.y/pictureBox->Height
						 *(double)height0/(double)aquabox.height
						 - (double)aquabox.y * boxarea_realsize.y/(double)aquabox.height);

				 }


				 (*(ROI_realsize.end()-1)).width = real_br_x - (*(ROI_realsize.end()-1)).x;
				 (*(ROI_realsize.end()-1)).height = real_br_y - (*(ROI_realsize.end()-1)).y;
				 textBox_roi_width->Text = ""+(*(ROI_realsize.end()-1)).width;
				 textBox_roi_height->Text = ""+(*(ROI_realsize.end()-1)).height;

				 (*(ROIs.end()-1)).x = aquabox.x + (*(ROI_realsize.end()-1)).x * aquabox.width / boxarea_realsize.x;
				 (*(ROIs.end()-1)).y = aquabox.y + (*(ROI_realsize.end()-1)).y * aquabox.height / boxarea_realsize.y;
				 (*(ROIs.end()-1)).width = (*(ROI_realsize.end()-1)).width * aquabox.width /boxarea_realsize.x;
				 (*(ROIs.end()-1)).height = (*(ROI_realsize.end()-1)).height * aquabox.height / boxarea_realsize.y;

				 cb_showroi->Enabled = true;
				 cb_showroi->Checked = true;
				 b_addROI->Enabled = true;

				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・ROIが追加されました");
				 }
				 else
				 {
					 textToLog("・A new ROI has been added");
				 }
				 showDisp();
			 }
		 }



private: System::Void textBox_boxarea_width_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 boxarea_realsize.x = Convert::ToInt32(textBox_boxarea_width->Text);

				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・矩形領域の幅: " + boxarea_realsize.x +" mm");
				 }
				 else
				 {
					 textToLog("・The box's width: "+boxarea_realsize.x +" mm");
				 }
				 label_widtharea->Text ="Width: "+boxarea_realsize.x + " mm";

				 for(int i=0; i<(signed int)ROIs.size(); i++)
				 {
					 //ROIs[i].x = boxarea.x + ROI_realsize[i].x * boxarea.width / boxarea_realsize.x;
					 //ROIs[i].y = boxarea.y + ROI_realsize[i].y * boxarea.height / boxarea_realsize.y;
					 //ROIs[i].width = ROI_realsize[i].width * boxarea.width / boxarea_realsize.x;
					 //ROIs[i].height = ROI_realsize[i].height * boxarea.height / boxarea_realsize.y;
					 ROI_realsize[i].x = cvRound((double)boxarea_realsize.x * (double)(ROIs[i].x - aquabox.x) /(double)aquabox.width);//保留
					 ROI_realsize[i].width = cvRound((double)boxarea_realsize.x*(double)ROIs[i].width/(double)aquabox.width);
					 
					 if(comboBox_ROI->SelectedItem!="")
					 {
						 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
						 showROIsize(number);
					 }
				 }
				 showDisp();
			 }
		 }



private: System::Void textBox_boxarea_height_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 boxarea_realsize.y = Convert::ToInt32(textBox_boxarea_height->Text);

				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・矩形領域の高さ: " + boxarea_realsize.y+" mm");
					 }
				 else
				 {
					 textToLog("・The box's height: "+boxarea_realsize.x +" mm");
				 }
				 label_heightarea->Text = "Height: "+boxarea_realsize.y+" mm";
				 for(int i=0; i<(signed int)ROIs.size(); i++)
				 {
					 //ROIs[i].x = boxarea.x + ROI_realsize[i].x * boxarea.width / boxarea_realsize.x;
					 //ROIs[i].y = boxarea.y + ROI_realsize[i].y * boxarea.height / boxarea_realsize.y;
					 //ROIs[i].width = ROI_realsize[i].width * boxarea.width / boxarea_realsize.x;
					 //ROIs[i].height = ROI_realsize[i].height * boxarea.height / boxarea_realsize.y;
					 ROI_realsize[i].y = cvRound((double)boxarea_realsize.y * (double)(ROIs[i].y - aquabox.y) /(double)aquabox.height);//保留
					 ROI_realsize[i].height = cvRound((double)boxarea_realsize.y*(double)ROIs[i].height/(double)aquabox.height);

					 if(comboBox_ROI->SelectedItem!="")
					 {
						 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
						 showROIsize(number);
					 }
				 }
				 showDisp();
			 }
		 }




private: System::Void b_addROI_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(video_set)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・ROIの設定");
					 textToLog("  →画面上で領域を指定，もしくは下のボックスに実寸を入力");
				 }
				 else
				 {
					 textToLog("・Setting a new ROI");
					 textToLog("  →Select the region on the screen, or type in measures in the boxes below.");
				 }
				 textBox_roi_ltx->BackColor = System::Drawing::SystemColors::Info;
				 textBox_roi_lty->BackColor = System::Drawing::SystemColors::Info;
				 textBox_roi_width->BackColor = System::Drawing::SystemColors::Info;
				 textBox_roi_height->BackColor = System::Drawing::SystemColors::Info;

				 setting_roi = true;

				 cv::Rect r(cv::Point(0,0),cv::Size(0,0));
				 ROIs.push_back(r);
				 ROI_realsize.push_back(r);
				 int targetline_temp = 1;
				 ROI_targetline.push_back(targetline_temp);
				 ROI_targetangle.push_back(30.0);
				 std::map<int,int> whenhot_temp;
				 ROI_whenhot.push_back(whenhot_temp);
				 ROI_totalhot.push_back(0);
				 System::String^ str = ""+ROIs.size();
				 comboBox_ROI->Items->Add(str);
				 comboBox_ROI->SelectedItem = str;
				 comboBox_roianal->Items->Add(str);
				 comboBox_roianal->SelectedItem = str;
				 if(ROIs.size()>5) ROI_color.push_back(CV_RGB(100,100,100));

				 b_addROI->Enabled = false;

				 b_execanal->Enabled = true;
				 b_save_roianal->Enabled = true;
				 b_anal_result_to_clip->Enabled = true;
			 }
			 else
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("動画の読込が必要です");
				 }
				 else
				 {
					 MessageBox::Show("A video file must be loaded first");
				 }
			 }

		 }




private: System::Void textBox_roi_ltx_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 if(setting_roi)
				 {
					 int number = ROIs.size()-1;
					 ROI_realsize[number].x = Convert::ToInt32(textBox_roi_ltx->Text);
					 showROIsize(number);
					 ROIs[number].x = aquabox.x + ROI_realsize[number].x * aquabox.width / boxarea_realsize.x;
					 roi_x_set = true;
					 textBox_roi_ltx->BackColor = System::Drawing::SystemColors::Window;
					 if(roi_x_set&&roi_y_set&&roi_width_set&&roi_height_set)
					 {
						 roi_set = true;
						 groupBox3->Enabled = true;

						 setting_roi = false;
						 roi_x_set = false;
						 roi_y_set = false;
						 roi_width_set = false;
						 roi_height_set = false;
						 b_addROI->Enabled = true;
						 cb_showroi->Enabled = true;
						 cb_showroi->Checked = true;
						 if(englishToolStripMenuItem->Checked==false)
						 {
							 textToLog("・ROIが追加されました");
						 }
						 else
						 {
							 textToLog("A new ROI has been added.");
						 }
						 showDisp();
					 }
					 

				 }
				 else
				 {
					 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
					 ROI_realsize[number].x = Convert::ToInt32(textBox_roi_ltx->Text);
					 showROIsize(number);
					 ROIs[number].x = aquabox.x + ROI_realsize[number].x * aquabox.width / boxarea_realsize.x;
					 showDisp();
				 }
			 }
		 }



private: System::Void textBox_roi_lty_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 if(setting_roi)
				 {
					 int number = ROIs.size()-1;
					 ROI_realsize[number].y = Convert::ToInt32(textBox_roi_lty->Text);
					 showROIsize(number);
					 ROIs[number].y = aquabox.y + ROI_realsize[number].y * aquabox.height / boxarea_realsize.y;
					 roi_y_set = true;
					 textBox_roi_lty->BackColor = System::Drawing::SystemColors::Window;
					 if(roi_x_set&&roi_y_set&&roi_width_set&&roi_height_set)
					 {
						 roi_set = true;
						 groupBox3->Enabled = true;

						 setting_roi = false;
						 roi_x_set = false;
						 roi_y_set = false;
						 roi_width_set = false;
						 roi_height_set = false;
						 b_addROI->Enabled = true;
						 cb_showroi->Enabled = true;
						 cb_showroi->Checked = true;
						 if(englishToolStripMenuItem->Checked==false)
						 {
							 textToLog("・ROIが追加されました");
						 }
						 else
						 {
							 textToLog("A new ROI has been added.");
						 }
						 showDisp();
					 }

				 }
				 else
				 {
					 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
					 ROI_realsize[number].y = Convert::ToInt32(textBox_roi_lty->Text);
					 showROIsize(number);
					 ROIs[number].y = aquabox.y + ROI_realsize[number].y * aquabox.height / boxarea_realsize.y;
					 showDisp();
				 }
			 }
		 }




private: System::Void textBox_roi_width_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 if(setting_roi)
				 {
					 int number = ROIs.size()-1;
					 ROI_realsize[number].width = Convert::ToInt32(textBox_roi_width->Text);
					 showROIsize(number);
					 ROIs[number].width = ROI_realsize[number].width * aquabox.width / boxarea_realsize.x;
					 roi_width_set = true;
					 textBox_roi_width->BackColor = System::Drawing::SystemColors::Window;
					 if(roi_x_set&&roi_y_set&&roi_width_set&&roi_height_set)
					 {
						 roi_set = true;
						 groupBox3->Enabled = true;

						 setting_roi = false;
						 roi_x_set = false;
						 roi_y_set = false;
						 roi_width_set = false;
						 roi_height_set = false;
						 b_addROI->Enabled = true;
						 cb_showroi->Enabled = true;
						 cb_showroi->Checked = true;
						 if(englishToolStripMenuItem->Checked==false)
						 {
							 textToLog("・ROIが追加されました");
						 }
						 else
						 {
							 textToLog("A new ROI has been added.");
						 }
						 showDisp();
					 }
				 }
				 else
				 {
					 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
					 ROI_realsize[number].width = Convert::ToInt32(textBox_roi_width->Text);
					 showROIsize(number);
					 ROIs[number].width = ROI_realsize[number].width * aquabox.width / boxarea_realsize.x;
					 showDisp();
				 }
			 }
		 }



private: System::Void textBox_roi_height_PreviewKeyDown(System::Object^  sender, System::Windows::Forms::PreviewKeyDownEventArgs^  e) {
			 if(e->KeyCode == System::Windows::Forms::Keys::Enter ||
				 e->KeyCode == System::Windows::Forms::Keys::Tab)
			 {
				 if(setting_roi)
				 {
					 int number = ROIs.size()-1;
					 ROI_realsize[number].height = Convert::ToInt32(textBox_roi_height->Text);
					 showROIsize(number);
					 ROIs[number].height = ROI_realsize[number].height * aquabox.height / boxarea_realsize.y;
					 roi_height_set = true;
					 textBox_roi_height->BackColor = System::Drawing::SystemColors::Window;
					 if(roi_x_set&&roi_y_set&&roi_width_set&&roi_height_set)
					 {
						 roi_set = true;
						 groupBox3->Enabled = true;

						 setting_roi = false;
						 roi_x_set = false;
						 roi_y_set = false;
						 roi_width_set = false;
						 roi_height_set = false;
						 b_addROI->Enabled = true;
						 cb_showroi->Enabled = true;
						 cb_showroi->Checked = true;
						 if(englishToolStripMenuItem->Checked==false)
						 {
							 textToLog("・ROIが追加されました");
						 }
						 else
						 {
							 textToLog("A new ROI has been added.");
						 }
						 showDisp();
					 }
					 
				 }
				 else
				 {
					 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
					 ROI_realsize[number].height = Convert::ToInt32(textBox_roi_height->Text);
					 showROIsize(number);
					 ROIs[number].height = ROI_realsize[number].height * aquabox.height / boxarea_realsize.y;
					 showDisp();

				 }
			 }
		 }



private: System::Void comboBox_ROI_SelectedValueChanged(System::Object^  sender, System::EventArgs^  e) {

			 int number = Convert::ToInt32(comboBox_ROI->SelectedItem)-1;
			 showROIsize(number);
		 }



private: System::Void b_clearroi_Click(System::Object^  sender, System::EventArgs^  e) {
			 comboBox_ROI->Items->Clear();
			 comboBox_roianal->Items->Clear();
			 ROIs.clear();
			 ROI_realsize.clear();
			 ROIs.clear();
			 ROI_realsize.clear();
			 ROI_targetline.clear();
			 ROI_targetangle.clear();
			 ROI_whenhot.clear();
			 ROI_totalhot.clear();

			 roi_set = false;
			 groupBox3->Enabled = false;

			 cb_showroi->Enabled = false;
			 b_execanal->Enabled = true;
			 b_save_roianal->Enabled = true;
			 comboBox_ROI->Text = "";
			 comboBox_roianal->Text = "";
			 textBox_roi_ltx->Text = "";
			 textBox_roi_lty->Text ="";
			 textBox_roi_width->Text = "";
			 textBox_roi_height->Text = "";
			 showDisp();
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・ROIを全て削除しました");
			 }
			 else
			 {
				 textToLog("・All the ROIs have been removed.");
			 }
		 }

////////////////////////////////////////////////////////////
/****************CHECK BOX**************************/
////////////////////////////////////////////////////////////

private: System::Void checkBox_showorigin_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 showDisp();
		 }

private: System::Void cb_showboxarea_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 showDisp();
		 }

private: System::Void cb_showroi_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 showDisp();
		 }


//////////////////////////////////////////////////////////////
/****************PLAY MOVIE*********************************/
/////////////////////////////////////////////////////////////

private: System::Void timer_Tick(System::Object^  sender, System::EventArgs^  e) {
			 movePlayerPosForward(1.0);
		 }

private: System::Void b_play_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(timer->Enabled == false)
			 {
				 timer->Enabled = true;
				 b_play->Text ="Pause";
			 }
			 else
			 {
				 timer->Enabled = false;
				 b_play->Text ="Play";
			 }
			 
		 }

private: System::Void b_forward_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(timer->Enabled)
			 {
				 timer->Enabled = false;
				 b_play->Text ="Play";
			 }
			 movePlayerPosForward(1.0);

		 }

private: System::Void b_backward_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(timer->Enabled)
			 {
				 timer->Enabled = false;
				 b_play->Text ="Play";
			 }
			 movePlayerPosBack(1.0);
		 }

private: System::Void b_skip_ahead_Click(System::Object^  sender, System::EventArgs^  e) {

			 jump_i++;
			 if(jump_i==(int)jump_frame.size())
			 {
				 jump_i=0;
			 }
			 iframe_now = jump_frame[jump_i];
			 trackBar->Value = iframe_now;
			 showDisp();

		 }

private: System::Void b_skip_back_Click(System::Object^  sender, System::EventArgs^  e) {
			 //if(timer->Enabled)
			 //{
				// timer->Enabled = false;
				// b_play->Text ="Play";
			 //}
			 //movePlayerPosBack(10.0);
			 jump_i--;
			 if(jump_i<0)
			 {
				 jump_i=(int)jump_frame.size()-1;
			 }
			 iframe_now = jump_frame[jump_i];
			 trackBar->Value = iframe_now;
			 showDisp();
		 }

private: System::Void radio_pspeed_slow_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 timer->Interval = 250;
		 }

private: System::Void radio_pspeed_norm_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 timer->Interval = 80;
		 }

private: System::Void radio_pspeed_fast_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 timer->Interval = 5;
		 }





//////////////////////////////////////////////////////////////////////////////////////
//////////////////////Functions Related to Tracking //////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

private: int tracking(bool debuging)
		 {
			 //vectorからmapに変更したので，途中からでもトラッキングが可能に。
			 ///よって各出力先配列の初期化は不要。


			 ///フラッグ
			 ///初期処理をすべきかどうか
			 bool need_initial_process = true;
			 ///ループするか
			 bool repeat = true;

			///ROIのサイズ
			 cv::Rect roi_default(cv::Point(0,0),cv::Size(boxarea.width/3,boxarea.height/3));
			 //cv::Rect roi_default(cv::Point(0, 0), cv::Size(boxarea.width / 2, boxarea.height / 2));//ver3.1 eijwat

			 cv::Rect roi_act(cv::Point(0,0),cv::Size(100,100));//roi_actの宣言
			 

			 ///変数
			 int ith = iframe_now;

			 ///入力画像
			 cv::Mat ori;
			 cv::Mat ori_masked;

			 ///マスクと背景
			 cv::Mat mask(cv::Size(width0,height0),CV_8UC1,cv::Scalar(0));
			 cv::rectangle(mask,boxarea,cv::Scalar(1),-1,CV_AA);
			 cv::Mat bcgdImg_masked;
			 bcgdImg.copyTo(bcgdImg_masked,mask);


			/////条件確認
			 if(!background_set)
			 {
				 return -1;
			 }
			 else if(!video_set)
			 {
				 return -2;
			 }
			
			 int width,height,total_pix;
			 width = width0;
			 height = height0;
			 total_pix = width*height;


			 ///////////////////////////////////
			 while(repeat)//全体を支配するループ
			 {
				 
				 //キャンセルが押された場合
				 if(bgworker_tracking->CancellationPending)
				 {
					 tracking_cancelled = true;
					 //trackBar->Enabled = true;//err=eijwat
					 bgworker_tracking->ReportProgress(0);

					 return -4;
				 }

				

				 cap.set(CV_CAP_PROP_POS_FRAMES,ith);
				 cap >> ori;
				 if(ori.empty())
				 {
					 break;
				 }

				 //ithをmarked(=set<int>)に加える
				 head_marked.insert(ith);
				 tail_marked.insert(ith);
				 
				 ori.copyTo(ori_masked,mask);
				 bgworker_tracking->ReportProgress(cvRound(100.0*(double)ith/(double)(num_frames-1)));
				 cv::Mat grayImg;
				 cv::cvtColor(ori_masked,grayImg,CV_RGB2GRAY);




				 //////////////////////////////////////////////////////////////////////////////////////////////////
				 ////初期処理をすべきかどうかで場合分け
				 //// With Initial Proccessing
				 ///////////////////////////////////////////////////////////////////////////////////////////////////
				 //
				 if(need_initial_process)
				 {
					 cv::Mat processedImg(grayImg.size(),CV_8UC1,cv::Scalar(0));
					 cv::Mat subImg(grayImg.size(),CV_8UC1,cv::Scalar(0));
					 cv::absdiff(grayImg,bcgdImg_masked,subImg);
					 cv::Mat otsuImg(grayImg.size(),CV_8UC1);
					 



					 //正規化距離による背景差分
					 if (normDistSub(grayImg, bcgdImg_masked, processedImg, 5, 10, 0.08, size_fish / 3) <0)//size_fish/3より小さいとエラー
					 {
						 //エラー発生
						 need_initial_process = true;
						 suspecious_frame.push_back(ith);
						 
						 if(ith>0)
						 {
							 heads[ith] = heads[ith-1];
							 tails[ith] = tails[ith-1];
							 //joints[ith] = joints[ith-1];//joints廃止に伴う変更eijwat
							 calc_pts.insert(std::map<int,cv::Point>::value_type(ith, calc_pts[ith-1]));
							  ith++;
							 continue;
						 }
						 else
						 {

							 heads[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);
							 tails[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);

							 //joints廃止に伴う変更eijwat
							 //std::vector<cv::Point> initJointTemp;
							 //initJointTemp.push_back(cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2));
							  //for(int j=0;j<(int)track_num_joint_points->Value;j++)initJointTemp.push_back(cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2));
							  //joints[ith] = initJointTemp;//??元々ここにはなかった（下にはある）

							 calc_pts[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);
							  ith++;
							 continue;
						 }
						
					 }
					 
					 //モルフォロジー演算によるクロージング
					 cv::Mat element0(3,3,CV_8UC1,cv::Scalar(0));
					 circle(element0,cv::Point(1,1),1,CV_RGB(255,255,255));

					 cv::morphologyEx(processedImg,processedImg,cv::MORPH_CLOSE,element0,cv::Point(-1,-1),3);

					 //ゴミ取りのためのラベリング処理と２値化処理のためにデータ形式を変更
					 unsigned char *uchar_img = new unsigned char[width*height];
					 short *labeling_first = new short[width*height];
					 cvtMat2uchar(processedImg,uchar_img);

					 
					 LabelingBS label_first;
					 //label_first.Exec(uchar_img, labeling_first, width, height, true, cvRound(0.5*size_fish));//ラベリングの実行　0.5*size_fishより小さいのは無視するオリジナル
					 label_first.Exec(uchar_img, labeling_first, width, height, true, cvRound(0.1*size_fish));//ラベリングの実行　0.1*size_fishより小さいのは無視

					 //マスクベクトル生成＋２値化の入力画像代入
					 std::vector<cv::Point> masq;
					  int *in_img = new int[width*height];
					  cv::Mat NotImg(cv::Size(width,height),CV_8UC1);
					 for(int y=0; y<height;y++)
					 {
						 for(int x=0;x<width;x++)
						 {
							 in_img[y*width+x] = 255-(int)grayImg.data[y*width+x];
							 NotImg.data[y*width+x] = 255-(int)grayImg.data[y*width+x];

							 if((int)labeling_first[y*width+x] > 0)
							 {
								 masq.push_back(cv::Point(x,y));
								 processedImg.data[y*width+x] = 255;
							 }else{
								 processedImg.data[y*width+x] = 0;
							 }
						 }
					 }
					 delete [] labeling_first;
					 delete [] uchar_img;//バッファーを開放


					 brightRegionBlock(in_img,masq,processedImg,width,height,cvRound(size_fish*1.5));//size_fish*1.5
					 //brightRegionBlock(in_img, masq, processedImg, width, height, cvRound(size_fish*6.0));
					 delete [] in_img;//バッファーを開放

					 //きれいなメダカ形状の取得（再）
					 cv::Mat morphImg;
					 cv::morphologyEx(processedImg,morphImg,cv::MORPH_CLOSE,element0,cv::Point(-1,-1),3);

					 //morphological opening (removes small objects from the foreground)
					 //cv::erode(processedImg, morphImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
					 //cv::dilate(morphImg, morphImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));

					 //morphological closing (removes small holes from the foreground)
					 //cv::dilate(morphImg, morphImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
					 //cv::erode(morphImg, morphImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));

					 
					 //頭の取得
					 cv::Point head;
					 head.x = 0; head.y = 0;

					 if(findHead(morphImg,head)<0)
					 {
						 //エラー発生
						 need_initial_process = true;
						 suspecious_frame.push_back(ith);
						 if(ith>0)
						 {
							 heads[ith] = heads[ith-1];
							 tails[ith] = tails[ith-1];
							 //joints[ith] = joints[ith-1];//joints廃止に伴う変更eijwat
							 calc_pts[ith] = calc_pts[ith-1];
							  ith++;
							 continue;
						 }
						 else
						 {
							 heads[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);
							 tails[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);
							 //joints廃止に伴う変更eijwat
							 //std::vector<cv::Point> initJointTemp;
							 //for(int j=0;j<(int)track_num_joint_points->Value;j++)initJointTemp.push_back(cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2));
							 //joints[ith] = initJointTemp;

							 calc_pts[ith] = cv::Point(boxarea.x+boxarea.width/2,boxarea.y+boxarea.height/2);
							  ith++;
							 continue;
						 }
					 }
					 
					 
					 					 //eijwat ver 3.2 この補正がないほうがよりメダカの先頭に座標が近づくので一旦はずす
					 //ver 3.3 オリジナルコードとして復活させる
					 //ガウス分布との相互相関による頭位置の補正
					 cv::Point gaus_mtc_pt;
					 gaus_mtc_pt.x = 0; gaus_mtc_pt.y = 0;
					 cv::Mat match_map(cv::Size(width,height),CV_8UC1,cv::Scalar(0));
					 gaussianMatching(subImg,match_map,morphImg,5.0f,25,head,9,gaus_mtc_pt);	//各値はメダカの頭の大きさを加味して指定 //暫定 sigma=4.0f, patch_size = 25, search_area = 19
					 head = gaus_mtc_pt;


					 heads[ith] = head;
					 


					 //しっぽの取得
					  //ゴミ取りのためのラベリング処理と２値化処理のために，データ形式を変更
					 unsigned char *uchar_img_tail = new unsigned char[width*height];
					 short *labeling_tail = new short[width*height];
					 cvtMat2uchar(morphImg,uchar_img_tail);



					 LabelingBS label_tail;
					 label_first.Exec(uchar_img_tail, labeling_tail, width, height, true, cvRound(0.1*size_fish));//ラベリングの実行　0.1*size_fishより小さいのは無視する
					 //label_first.Exec(uchar_img_tail, labeling_tail, width, height, true, cvRound(0.5*size_fish));//ラベリングの実行　0.1*size_fishより小さいのは無視する

					 //マスクベクトル生成＋２値化の入力画像代入
					 for(int y=0; y<height;y++)
					 {
						 for(int x=0;x<width;x++)
						 {
							 
							 if((int)labeling_tail[y*width+x] == 1)
							 {
								 morphImg.data[y*width+x] = 255;
							 }else{
								 morphImg.data[y*width+x] = 0;
							 }
						 }
					 }

					 delete [] labeling_tail;
					 delete [] uchar_img_tail;


					 /*
					 					 if (morphImg.data == NULL)//エラー発生eijwat 3.2
					 {

						 need_initial_process = true;
						 suspecious_frame.push_back(ith);

						 if (ith>0)
						 {
							 tails[ith] = tails[ith - 1];
							 calc_pts.insert(std::map<int, cv::Point>::value_type(ith, calc_pts[ith - 1]));
							 ith++;
							 continue;
						 }
						 else
						 {
							 tails[ith] = cv::Point(boxarea.x + boxarea.width / 2, boxarea.y + boxarea.height / 2);
							 calc_pts[ith] = cv::Point(boxarea.x + boxarea.width / 2, boxarea.y + boxarea.height / 2);
							 ith++;
							 continue;
						 }

					 }
					 
					 */


					 cv::Mat tailPosMat;	//Point2fが入っている
					 cv::goodFeaturesToTrack(morphImg,tailPosMat,10,0.02,5,cv::noArray(),2);

					 int max_dist_to_head = 0;
					 cv::Point tail;
					 tail.x = 0; tail.y = 0;

					 for(int i=0;i<tailPosMat.rows;i++)
					 {
						 int tx = (int)tailPosMat.at<cv::Point2f>(i,0).x;
						 int ty = (int)tailPosMat.at<cv::Point2f>(i,0).y;
						 int dist = (head.x - tx)*(head.x - tx)+(head.y - ty)*(head.y - ty);
						 if(max_dist_to_head<dist)
						 {
							 tail.x = (int)tailPosMat.at<cv::Point2f>(i,0).x;
							 tail.y = (int)tailPosMat.at<cv::Point2f>(i,0).y;
							 max_dist_to_head = dist;
						 }

					 }
					 tails[ith] = tail;



					//切り取り枠の決定

					cv::Point temp;

					temp.x = (int)((head.x + tail.x) / 2);//ver3.1 eijwat//もともとはheadではなくjoint[n]//joints廃止に伴う変更eijwat
					temp.y = (int)((head.y + tail.y) / 2);//ver3.1 eijwat

					int iCoo = temp.x + roi_act.x;//roi_act上の座標をもとのピクチャー座標へ変換

					if (iCoo - roi_default.width / 2<0)
					{
						roi_act.x = 0;
						roi_act.width = roi_default.width;
					}
					else if (iCoo + roi_default.width / 2>width){
						//roi_act.x = iCoo - roi_default.width / 2;
						//roi_act.width = width - iCoo + roi_default.width / 2;
						roi_act.x = width - roi_default.width-1;//ver3.1 eijwat
						roi_act.width = roi_default.width;//ver3.1 eijwat
					}
					else{
						roi_act.x = iCoo - roi_default.width / 2;
						roi_act.width = roi_default.width;
					}

					iCoo = temp.y + roi_act.y;

					if (iCoo - roi_default.height / 2<0)
					{
						roi_act.y = 0;
						roi_act.height = roi_default.height;
					}
					else if (iCoo + roi_default.height / 2>height){
						//roi_act.y = iCoo - roi_default.height / 2;
						//roi_act.height = height - iCoo + roi_default.height / 2;
						roi_act.y = height - roi_default.height-1;//ver3.1 eijwat
						roi_act.height = roi_default.height;//ver3.1 eijwat
					}
					else{
						roi_act.y = iCoo - roi_default.height / 2;
						roi_act.height = roi_default.height;
					}
					




					 //正常に終了したのでsuspecioius_frameからithを削除
					 std::vector<int>::iterator it_sus_del = find(suspecious_frame.begin(),suspecious_frame.end(),ith);
					 if(it_sus_del !=suspecious_frame.end())
					 {
						 suspecious_frame.erase(it_sus_del);
					 }

					 need_initial_process = false;
					 ith++;
				 }//---if(need_initial_process)---//





				 //////////////////////////////////////////////////////////////////////////////////////////////////
				 ////初期処理なしへの分岐＝２回目以降
				 //// Without Initial Proccessing
				 ///////////////////////////////////////////////////////////////////////////////////////////////////
				 //
				 else
				 {
					 while (roi_act.y + roi_act.height > height - 1)roi_act.y--;//watanabee この処理はよくない。これが動くのはどこか間違えている証拠。
					 while (roi_act.x + roi_act.width > width- 1)roi_act.x--;//watanabee この処理はよくない。これが動くのはどこか間違えている証拠。

					 cv::Mat grayRoi0(grayImg,cv::Rect(roi_act.x,roi_act.y,roi_act.width,roi_act.height));
					 cv::Mat backRoi0(bcgdImg_masked,cv::Rect(roi_act.x,roi_act.y,roi_act.width,roi_act.height));
					 cv::Mat grayRoi = grayRoi0.clone();
					 cv::Mat backRoi = backRoi0.clone();
					 //cv::Mat processedImg(grayRoi.size(),CV_8UC1,cv::Scalar(0));//eijwat v3.2

					 cv::Mat subImg(grayRoi.size(),CV_8UC1,cv::Scalar(0));
					 cv::absdiff(grayRoi,backRoi,subImg);
					 cv::Mat otsuImg;

					 if(cb_usebinval->Checked)
					 {
						 cv::threshold(subImg,otsuImg,bin_threshold,255,CV_THRESH_BINARY);
					 }
					 else
					 {
						cv::threshold(subImg,otsuImg,1,255,CV_THRESH_BINARY|CV_THRESH_OTSU);
					 }

					if(debuging)
					 {
						 DrawMatResizedC1(otsuImg,pictureBox);
						 MessageBox::Show("otsu0");
						 
					 }



					 cv::Mat forheadImg;

					 cv::Mat element0(3,3,CV_8UC1,cv::Scalar(0));
					 circle(element0,cv::Point(1,1),1,CV_RGB(255,255,255));
					 for(int j=1;j<=1;j++)
					 {
						 cv::erode(otsuImg,forheadImg,element0,cv::Point(-1,-1),j);

						 int sz_forhead = 0;
						 for(int i=0;i<forheadImg.cols*forheadImg.rows;i++)
						 {
							 if(forheadImg.data[i] > 0) sz_forhead++;
						 }
						 if(sz_forhead < cvRound(1.5*size_fish))
							 //if(sz_forhead < cvRound(0.3*size_fish))
						 {
							 forheadImg = otsuImg.clone();
							 break;
						 }
					 }

					 //cv::morphologyEx(otsuImg,forheadImg,cv::MORPH_OPEN,element0,cv::Point(-1,-1),3);

					 if(debuging)
					 {
						 DrawMatResizedC1(subImg,pictureBox);
						 MessageBox::Show("sub");
					 }
					 if(debuging)
					 {
						 DrawMatResizedC1(forheadImg,pictureBox);
						 MessageBox::Show("forhead");
					 }



					 //ゴミ取りのためのラベリング処理と２値化処理のために，データ形式を変更
					 unsigned char *uchar_img = new unsigned char[roi_act.width*roi_act.height];
					 short *labeling_first = new short[roi_act.width*roi_act.height];
					 cvtMat2uchar(forheadImg,uchar_img);


					 
					 LabelingBS label_first;
					 label_first.Exec(uchar_img, labeling_first, roi_act.width, roi_act.height, true, 20/*cvRound(0.1*size_fish)*/);//固定値２０が入る




					 ///////////////////////
					 //鏡像が存在する場合を考え，サイズがある程度大きいものが２つある場合，中心に近いものをとる
					 // Deleting of Mirror Fish

					 //トップ2のサイズ取得
					 double rate_to_assume_same = 1.5;
					 int numcc = label_first.GetNumOfResultRegions();
					 int max_brtnss= INT_MIN;
					 std::vector<int> candidate_cc;
					 if(debuging) MessageBox::Show("numcc:"+numcc);
					 if(numcc >= 2)
					 {
						 std::vector<int> max_brt;
						 for(int i=0;i<numcc;i++)
						 {
							 max_brt.push_back(0);		
						 }
						  //最大輝度が最大のもの2つを見つける
						 for(int i=0; i< roi_act.width*roi_act.height;i++)
						 {
							 int ccno = labeling_first[i];
							 if(ccno!=0)
							 {
								 max_brt[ccno-1] = std::max(max_brt[ccno-1],(int)subImg.data[i]);
							 }
						 }
						 int maxcc, secondcc;
						 int max=INT_MIN, second=INT_MIN;
						 for(int i=0;i<numcc;i++)
						 {
							 if(debuging)
							 {
								 MessageBox::Show(""+max_brt[i]+"("+i+")");
							 }

							 //サイズでフィルタリングもおこなう
							 RegionInfoBS *ri;
							 ri = label_first.GetResultRegionInfo(0);
							 int sz = ri->GetNumOfPixels();
							 //if(sz < 1.5*size_fish) max_brt[i] = 0;
							 if(sz < 0.3*size_fish) max_brt[i] = 0;
							 if(max< max_brt[i])
							 {
								 second = max;
								 secondcc = maxcc;
								 max = max_brt[i];
								 maxcc = i;
							 }
							 else if(secondcc < max_brt[i])
							 {
								 secondcc = i;
								 second = max_brt[i];
							 }
						 }
						 candidate_cc.push_back(maxcc);
						 if(debuging)
						 {
							 MessageBox::Show("max:"+max+"("+maxcc+") , second:"+second+"("+secondcc+")");
						 }
						 if(second > (int)((double)max*0.8))
						 {
						     candidate_cc.push_back(secondcc);
						 }
					 }

					 int selected_cc = 1;//取り出すCCの番号（1～)
					 if((int)candidate_cc.size()>0) selected_cc = candidate_cc[0]+1;
					 
					 if((int)candidate_cc.size() >= 2)
					 {
						 int hsize1, hsize2;
						 RegionInfoBS *hri1, *hri2;
						 hri1 = label_first.GetResultRegionInfo(candidate_cc[0]);
						 hri2 = label_first.GetResultRegionInfo(candidate_cc[1]);
						 hsize1 = hri1->GetNumOfPixels();
						 hsize2 = hri2->GetNumOfPixels();
						 


						 if(fabs((double)hsize1/(double)hsize2) < rate_to_assume_same && fabs((double)hsize2/(double)hsize1)<rate_to_assume_same)
						 {
							 //トップ2の位置取得
							 cv::Point hpos1, hpos2;
							 float tempx, tempy;
							 hri1->GetCenter(tempx,tempy);
							 hpos1 = cv::Point((int)tempx,(int)tempy);
							 hri2->GetCenter(tempx,tempy);
							 hpos2 = cv::Point((int)tempx,(int)tempy);

							 //cv::Point centBox(boxarea.x+boxarea.width/2-roi_act.x, boxarea.y+boxarea.height/2-roi_act.y);
							 cv::Point centBox(aquabox.x + aquabox.width / 2 - roi_act.x, aquabox.y + aquabox.height / 2 - roi_act.y);//eijwat ver3.2
							 //水槽の中心から近い座標のオブジェクトを選択

							 //距離
							 double hdist1, hdist2;
							 hdist1 = pow((centBox.x-hpos1.x),2)+pow((centBox.y-hpos1.y),2);
							 hdist2 = pow((centBox.x-hpos2.x),2)+pow((centBox.y-hpos2.y),2);


							 if(hdist1 < hdist2)
							 {
								 selected_cc = candidate_cc[0]+1;
							 }
							 else
							 {
								 selected_cc = candidate_cc[1]+1;
							 }
						 }
						 else
						 {
							 if(hsize1>hsize2)
							 {
								 selected_cc = candidate_cc[0]+1;
							 }
							 else
							 {
								 selected_cc = candidate_cc[1]+1;
							 }
						 }
					 }


					 /////////////////////////////////////////
					 //マスクベクトル生成＋２値化の入力画像代入
					 //Generating Mask Vectors & Binary Images

					 std::vector<cv::Point> masq;
					  int *in_img = new int[roi_act.width*roi_act.height];
					 for(int y=0; y<roi_act.height;y++)
					 {
						 for(int x=0;x<roi_act.width;x++)
						 {
							 in_img[y*roi_act.width+x] = 255-(int)grayRoi.data[y*roi_act.width+x];
							 
							 if((int)labeling_first[y*roi_act.width+x] == selected_cc)
							 {
								 masq.push_back(cv::Point(x,y));
								 forheadImg.data[y*roi_act.width+x] = 255;
							 }else{
								 forheadImg.data[y*roi_act.width+x] = 0;
							 }
						 }
					 }
					 delete [] labeling_first;
					 delete [] uchar_img;

					 if(debuging)
					 {
						 DrawMatResizedC1(forheadImg,pictureBox);
						 MessageBox::Show("after labeling");
						DrawMatResizedC1(otsuImg,pictureBox);
						 MessageBox::Show("otsuImg");
					 }

					 //brightRegionBlock(in_img,masq,processedImg,roi_act.width,roi_act.height,cvRound(size_fish*1.5));//最後の引数:230 = だいたいメダカの面積？
					 //
					 //頭部検出用の小さい領域
					 cv::Mat headImg(forheadImg.size(),CV_8UC1);
					 //brightRegionBlock(in_img,masq,headImg,roi_act.width,roi_act.height,cvRound(size_fish*2.0));
					 brightRegionBlock(in_img, masq, headImg, roi_act.width, roi_act.height, cvRound(size_fish*0.4));//size_fish*0.4!!
					 
					 delete [] in_img;

					 //Generating Fish Figure
					 //きれいなメダカ形状の取得
					 cv::Mat morphImg;
					 morphImg = forheadImg.clone();

					 cv::Mat morphHeadImg;

					 cv::morphologyEx(headImg,morphHeadImg,cv::MORPH_CLOSE,element0,cv::Point(-1,-1),3);


					 //morphological opening (removes small objects from the foreground)
					 //cv::erode(headImg, morphHeadImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
					 //cv::dilate(morphHeadImg, morphHeadImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));

					 //morphological closing (removes small holes from the foreground)
					// cv::dilate(morphHeadImg, morphHeadImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));
					 //cv::erode(morphHeadImg, morphHeadImg, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)));




					  if(debuging)
					 {
						 DrawMatResizedC1(morphHeadImg,pictureBox);
						 MessageBox::Show("atama?");
					 }

					 //頭の取得
					 //Detecting Fish Head
					 cv::Point head;
					 head.x = 0; head.y = 0;

					 if(findHead(morphHeadImg,head)<0)
					 {
						 //エラー発生
						 need_initial_process = true;
						 suspecious_frame.push_back(ith);
						 heads[ith] = heads[ith-1];
						 tails[ith] = tails[ith-1];
						 //joints[ith] = joints[ith-1];//joints廃止に伴う変更eijwat
						 calc_pts[ith] = calc_pts[ith-1];
						 ith++;
						 continue;

					 }


				 
					 
					 //eijwat ver 3.2 この補正がないほうがよりメダカの先頭に座標が近づく
					 //ver 3.3 オリジナルコードとして復活
					 //ver 3.7 バグがあるようなので再び封印
					 //いずれにしても問題のあるコードであることは間違いない
					 
					 /*
					 //Correcting Head Position
					 //ガウス分布との相互相関による頭位置の補正
					 cv::Point gaus_mtc_pt;
					 gaus_mtc_pt.x = 0; gaus_mtc_pt.y = 0;
					 cv::Mat match_map(cv::Size(roi_act.width,roi_act.height),CV_8UC1,cv::Scalar(0));
					 gaussianMatching(subImg,match_map,morphHeadImg,7.0f,25,head,15,gaus_mtc_pt);	//各値はメダカの頭の大きさを加味して指定 //暫定 sigma=4.0f, patch_size = 25, search_area = 19
					 head = gaus_mtc_pt;
					 */

	


					 
					 heads[ith] = cv::Point(head.x+roi_act.x,head.y+roi_act.y);
					
					  if(debuging)
					 {
						 cv::Mat showMorph = morphHeadImg.clone();
						 cv::circle(showMorph,head,3,cv::Scalar(150),1,CV_AA);
						 DrawMatResizedC1(showMorph,pictureBox);
						 MessageBox::Show("headpos");
					 }


					 //しっぽの取得
					 //Detecting of Fish Tail
					 //ゴミ取りのためのラベリング処理と２値化処理のために，データ形式を変更
					 unsigned char *uchar_img_tail = new unsigned char[roi_act.width*roi_act.height];
					 short *labeling_tail = new short[roi_act.width*roi_act.height];
					 cvtMat2uchar(morphImg,uchar_img_tail);



					 LabelingBS label_tail;
					 //label_first.Exec(uchar_img_tail, labeling_tail, roi_act.width, roi_act.height, true, cvRound(0.5*size_fish));
					 label_first.Exec(uchar_img_tail, labeling_tail, roi_act.width, roi_act.height, true, cvRound(0.1*size_fish));
					 //Generating Mask Vectors & Binary Images
					 //マスクベクトル生成＋２値化の入力画像代入
					 for(int y=0; y<roi_act.height;y++)
					 {
						 for(int x=0;x<roi_act.width;x++)
						 {
							 
							 if((int)labeling_tail[y*roi_act.width+x] == 1)
							 {
								 morphImg.data[y*roi_act.width+x] = 255;
							 }else{
								 morphImg.data[y*roi_act.width+x] = 0;
							 }
						 }
					 }


					 /*
					 					 if (morphImg.data == NULL)//エラー発生eijwat 3.2
					 {
						 
						 need_initial_process = true;
						 suspecious_frame.push_back(ith);

						 if (ith>0)
						 {
							 tails[ith] = tails[ith - 1];
							 calc_pts.insert(std::map<int, cv::Point>::value_type(ith, calc_pts[ith - 1]));
							 ith++;
							 continue;
						 }
						 else
						 {
							 tails[ith] = cv::Point(boxarea.x + boxarea.width / 2, boxarea.y + boxarea.height / 2);
							 calc_pts[ith] = cv::Point(boxarea.x + boxarea.width / 2, boxarea.y + boxarea.height / 2);
							 ith++;
							 continue;
						 }

					 }
					 
					 */



					 delete [] labeling_tail;
					 delete [] uchar_img_tail;

					 cv::Mat tailPosMat;	//Point2fが入っている

					 cv::goodFeaturesToTrack(morphImg,tailPosMat,10,0.02,5,cv::noArray(),2);

					 int max_dist_to_head=0;
					 cv::Point tail;
					 tail.x = 0; tail.y = 0;


					 for(int i=0;i<tailPosMat.rows;i++)
					 {
						 int tx = (int)tailPosMat.at<cv::Point2f>(i,0).x;
						 int ty = (int)tailPosMat.at<cv::Point2f>(i,0).y;
						 int dist = (head.x - tx)*(head.x - tx)+(head.y - ty)*(head.y - ty);
						 if(max_dist_to_head<dist)
						 {
							 tail.x = (int)tailPosMat.at<cv::Point2f>(i,0).x;
							 tail.y = (int)tailPosMat.at<cv::Point2f>(i,0).y;
							 max_dist_to_head = dist;
						 }

					 }

					 tails[ith] = cv::Point(tail.x+roi_act.x,tail.y+roi_act.y);



					//切り取り枠の決定

					cv::Point temp;

					temp.x = (int)((head.x + tail.x) / 2);//ver3.1 eijwat//もともとはheadではなくjoint[n]//joints廃止に伴う変更eijwat
					temp.y = (int)((head.y + tail.y) / 2);//ver3.1 eijwat

					int iCoo = temp.x + roi_act.x;//roi_act上の座標をもとのピクチャー座標へ変換

					if (iCoo - roi_default.width / 2<0)
					{
						roi_act.x = 0;
						roi_act.width = roi_default.width;
					}
					else if (iCoo + roi_default.width / 2>width){
						//roi_act.x = iCoo - roi_default.width / 2;
						//roi_act.width = width - iCoo + roi_default.width / 2;
						roi_act.x = width - roi_default.width-1;//ver3.1 eijwat
						roi_act.width = roi_default.width;//ver3.1 eijwat
					}
					else{
						roi_act.x = iCoo - roi_default.width / 2;
						roi_act.width = roi_default.width;
					}

					iCoo = temp.y + roi_act.y;

					if (iCoo - roi_default.height / 2<0)
					{
						roi_act.y = 0;
						roi_act.height = roi_default.height;
					}
					else if (iCoo + roi_default.height / 2>height){
						//roi_act.y = iCoo - roi_default.height / 2;
						//roi_act.height = height - iCoo + roi_default.height / 2;
						roi_act.y = height - roi_default.height-1;//ver3.1 eijwat
						roi_act.height = roi_default.height;//ver3.1 eijwat
					}
					else{
						roi_act.y = iCoo - roi_default.height / 2;
						roi_act.height = roi_default.height;
					}


					



					 //正常に終了したのでsuspecioius_frameからithを削除
					 std::vector<int>::iterator it_sus_del = find(suspecious_frame.begin(),suspecious_frame.end(),ith);
					 if(it_sus_del !=suspecious_frame.end())
					 {
						 suspecious_frame.erase(it_sus_del);
					 }


					 ith++;


				 }//--if(need_initial_process) else--//

			 }//---while(repeat)--//

			 return 0;
		 }//--tracking()--//




private: int normDistSub(cv::Mat foreground, cv::Mat background, cv::Mat output, int vsize, double threshSimple, double thresh, int need_npixels)
		 {
			 int width=foreground.cols;
			 int height = foreground.rows;
			 cv::Mat smplSubImg(foreground.size(),CV_8UC1,cv::Scalar(255));
			 absdiff(background,foreground,smplSubImg);
			 const int vhalf = vsize/2;
			 double *forevector = new double[vsize*vsize];
			 double *backvector = new double[vsize*vsize];
			 int num_white_pixel = 0;
			 //int *result = new int[width*height];
			// for(int i=0;i<width*height;i++)
			// {
				 //result[i] = 0;
			// }
			 for(int y=vhalf;y<height-vhalf;y++)
			 {
				 for(int x=vhalf;x<width-vhalf;x++)
				 {
					 for(int dy=-vhalf;dy<=vhalf;dy++)
					 {
						 for(int dx=-vhalf;dx<=vhalf;dx++)
						 {
							 int idx_vct=(dy+vhalf)*vsize+dx+vhalf;
							 int idx_img=(y+dy)*width+x+dx;
							 forevector[idx_vct] = (double)foreground.data[idx_img];
							 backvector[idx_vct]= (double)background.data[idx_img];
						 }	
					 }
					 double foresum=0;
					 double backsum=0;
					 for(int yy=0;yy<vsize;yy++)
					 {
						 for(int xx=0;xx<vsize;xx++)
						 {
							 foresum += forevector[yy*vsize+xx]*forevector[yy*vsize+xx];
							 backsum += backvector[yy*vsize+xx]*backvector[yy*vsize+xx];
						 }
					 }
					 foresum = sqrt(foresum);
					 backsum = sqrt(backsum);


					 for(int i=0;i<vsize*vsize;i++)
					 {
						 forevector[i] = forevector[i]/foresum - backvector[i]/backsum;
					 }
					 double dist=0;
					 for(int i=0;i<vsize*vsize;i++)
					 {
						 dist += forevector[i]*forevector[i];
					 }
					 dist = sqrt(dist);
					 if(dist >= thresh && smplSubImg.data[y*width+x]>threshSimple)
					 {
						// result[y*width+x] = 255;
						 output.data[y*width+x] = 255;
						 num_white_pixel++;
					 }else{
						 //result[y*width+x] = 0;
						 output.data[y*width+x] = 0;
					 }
				 }//-- for x --/
			 }//--for y--//



			 delete [] forevector;
			 delete [] backvector;
			// delete [] result;

			 if(num_white_pixel < need_npixels)
			 {
				 //必要なサイズが検出されない場合にはエラーを返す
				return -1;
			 }

			 return 0;
		 }






private: void brightRegionBlock(int *img, std::vector<cv::Point> masq, cv::Mat& dst, int width, int height, int num_pix)
		 {
			 int blocksize = 5; // 3 x 3
			 std::vector<cv::Point>masq_temp;
			 int *dst_temp;
			 dst_temp = new int[width*height];

			 cv::Mat dst0(cv::Size(width,height),CV_8UC1,cv::Scalar(-1));

			 //初期化
			 int max_brightness_block = -1;
			 int max_brightness = -1;
			 int max_x = -1;
			 int max_y = -1;

			 for(int i=0;i<(int)masq.size();i++)
			 {
				 dst0.data[masq[i].y*width+masq[i].x] = 0;

				 int sum_b=0;
				 int halfbs = (int)(blocksize*0.5);
				 for(int m=-halfbs;m<halfbs;m++)	//x方向
				 {
					 for(int n=-halfbs;n<halfbs;n++)	//y方向
					 {
						 int bx = masq[i].x+m;
						 int by = masq[i].y+n;
						 if(bx>=0 && bx<width && by>=0 && by<height)
						 {
							 sum_b += img[by*width+bx];
						 }
					 }
				 }

				 masq_temp.push_back(masq[i]);
				 if(max_brightness_block < sum_b)
				 {
					 max_brightness_block = sum_b;
					 max_brightness = img[masq[i].y*width+masq[i].x];
					 max_x = masq[i].x;
					 max_y = masq[i].y;
				 }
			 }

			 dst0.data[max_y*width+max_x] = 1;
			 //初期化終了



			 int now_th = max_brightness;	//これを小さくしていく
			 int now_num = 1;
			// int strikesforout = 0;

			 while(num_pix - now_num >= 0)	//num_pix個pixelが選ばれるまで繰り返す
			 {
				 for(int i=0;i<width*height;i++)
				 {
					 dst_temp[i] = dst0.data[i];
				 }


				 for(int i=0;i<(int)masq_temp.size();i++)
				 {
					 int x = masq_temp[i].x;
					 int y = masq_temp[i].y; 
					 if(dst0.data[y*width+x] == 0)
					 {
						 if(img[y*width+x]>=now_th)
						 {
							 bool adj = false;
							 for(int m = -3; m<=3;m++)
							 {
								 for(int n=-3;n<=3;n++)
								 {
									 if(y+m<0 || x+n<0 || y+m >=height || x+n>=width) continue;	//画像外

									 if(dst0.data[(y+m)*width+(x+n)] == 1)
									 {
										 adj = true;
										 dst_temp[y*width+x] = 1;
										 now_num++;

										 //この点をvector<Point>masq_tempから除く
										 masq_temp.erase(masq_temp.begin() + i);
										 break;
									 }
								 }
								 if(adj) break;
							 }
							 if(!adj){
								 dst_temp[y*width+x] = -1;
								 //この点をvector<Point> masq_tempから除く
								 masq_temp.erase(masq_temp.begin() + i);
							 }
						 }//--if img[y*width+x] >= now_th--//
					 }//-- if(dst.data[y*width+x]) == 0) --//
				 }//-- for maskの要素 --/


				 for(int i=0;i<(int)masq.size();i++)
				 {
					 int x=masq[i].x, y=masq[i].y;	
					 dst0.data[y*width+x] = dst_temp[y*width+x];
				 }

				 now_th--;
				 if(now_th<0) break;
			 }

			 for(int i=0;i<width*height;i++)
			 {
				 if(dst0.data[i] == 1)
				 {
					 dst.data[i] = 255;
				 }else
				 {
					 dst.data[i] = 0;
				 }
			 }

			 // finishing
			 delete [] dst_temp;
		 }



private: int findHead(cv::Mat img, cv::Point& head)
		 {
			 cv::Mat kernel(3,3,CV_8UC1,cv::Scalar(0));
			 cv::circle(kernel,cv::Point(1,1),1,CV_RGB(255,255,255),-1);

			 cv::Mat input = img.clone();

			 int img_area = 1000;
			 while(img_area > 10)
			 {
				 cv::Mat temp = input.clone();
				 cv::erode(input,input,kernel);
				 if((img_area = getBinAreaMat(input)) == 0)
				 {
					 temp.copyTo(input);
					 break;

				 }
			 }
			 int x, y;
			 if(findCoG(input,x,y,input.cols,input.rows)<0)
				{
					 return -1;
			 };

			 head.x = x;
			 head.y = y;

			 return 0;
		 }





private: int findCoG(cv::Mat img, int& x, int& y, int width, int height)
		 {
			 int CoGx =0;
			 int CoGy =0;
			 int total =0;
			 for(int yl=0;yl<height;yl++)
			 {
				 for(int x=0;x<width;x++)
				 {
					 int p = img.data[yl*width+x];
					 CoGx+=p*x;
					 CoGy+=p*yl;
					 total += p;
				 }
			 }

			 if(total <= 0)
			 {
				 return -1;
			 }


			 x = CoGx/total;
			 y = CoGy/total;
			 return 0;
		 }




private: int getBinAreaMat(cv::Mat img)
		 {
			 int width = img.cols;
			 int height = img.rows;
			 int area = 0;
			 for(int y=0;y<height;y++)
			 {
				 for(int x=0;x<width;x++)
				 {
					 if((int)img.data[y*width+x]>0)
					 {
						 area++;
					 }
				 }
			 }

			 return area;
		 }



private: void gaussianMatching(cv::Mat input_img,cv::Mat match_map, cv::Mat mask_img, double gauss_sigma, int patch_size/*odd number*/,//cv::Mat&の&をとった=eijwat ver3.3
					  cv::Point around_this_pt, int search_area_size /*odd number*/, cv::Point& match_pt)
{
	//gaussian
	cv::Mat gauss_val_container = cv::getGaussianKernel(patch_size, gauss_sigma, CV_32F);
	double gauss_val_max;
	cv::Point gval_max_loc;
	cv::minMaxLoc(gauss_val_container,NULL,&gauss_val_max,NULL,&gval_max_loc);
	double gauss_val_max_squared = gauss_val_max*gauss_val_max;

	cv::Mat gauss_img(patch_size,patch_size,CV_32F);
	
	for(int y = 0; y < patch_size; y++)
	{
		for(int x = 0; x< patch_size; x++)
		{
			gauss_img.at<float>(x,y) = gauss_val_container.at<float>(x , 0) * gauss_val_container.at<float>(y, 0)/(float)gauss_val_max_squared*255.0;
		}
	}



	//よくわからんけどエラーの原因のようなのでとりあえずスキップ＝ver3.2
	//ver3.2ではそもそもgaussianMatchingを未使用＝ver3.2
	//=かとうかがやき様のご助言によりgaussianMatchingのバグがとれたようなので復活＝eijwat ver3.3
		//試しに（ここから)
	
	
	double gval_max, gval_min;
	cv::minMaxIdx(gauss_img, &gval_min, &gval_max);

	double middle = (gval_min + gval_max)*0.5;
	for (int y = 0; y<gauss_img.rows; y++)
	{
		for (int x = 0; x<gauss_img.cols; x++)
		{
			gauss_img.at<float>(y, x) -= middle;
		}
	}

	
	//試しに（ここまで）
		

	//matching
	int half_patch_size = (int)((patch_size-1) * 0.5);
	int half_search_area_size = (int)((search_area_size-1)*0.5);
	int width = input_img.cols;
	int height = input_img.rows;
	double sum_max = 0;
	double sum_min = 9.9e10;
	cv::Mat f_match_map(cv::Size(width,height),CV_32FC1,cv::Scalar(0));
	cv::Point max_loc, min_loc;
	for(int y =around_this_pt.y-half_search_area_size/*half_patch_size*/; y<around_this_pt.y+half_search_area_size/*height-half_patch_size*/;y++)
	{
		for(int x=around_this_pt.x-half_search_area_size/*half_patch_size*/;x<around_this_pt.x+half_search_area_size/*width-half_patch_size*/;x++)
		{
			double sum_diff;
			//以下，使用する相関の取り方にあわせて true/falseを入れ替える
			if(false)
			{
				//matching by sum of squared difference
				double sum_sq_diff = 0;
				for(int gy =0; gy<patch_size;gy++)
				{
					for(int gx = 0; gx<patch_size;gx++)
					{
						int ix = x - half_patch_size + gx;
						int iy = y - half_patch_size + gy;
						if(ix>=0 && ix < width && iy >=0 && iy <height)
						{
							sum_sq_diff += ((float)input_img.data[iy*width+ix]-gauss_img.at<float>(gx,gy))*
								((float)input_img.data[iy*width+ix]-gauss_img.at<float>(gx,gy));
							//cout <<(float)input_img.data[iy*width+ix]<<"-"<<gauss_img.at<float>(gx,gy)<<endl;
							//cout << sum_sq_diff <<endl;
							//cout <<"--------------------------"<<endl;
						}
					}
				}
			}
			if(false)
			{
				//matching by sum of absolute difference
				double sum_abs_diff = 0;
				for(int gy =0; gy<patch_size;gy++)
				{
					for(int gx = 0; gx<patch_size;gx++)
					{
						int ix = x - half_patch_size + gx;
						int iy = y - half_patch_size + gy;
						if(ix>=0 && ix < width && iy >=0 && iy <height)
						{
							sum_abs_diff += fabs(((float)input_img.data[iy*width+ix]-gauss_img.at<float>(gx,gy)));
						}
					}
				}
				sum_diff = sum_abs_diff;
			}
			if(true)
			{
				//matching by normalized cross correlation
				double product_sum = 0;
				double sqrd_sum_input = 0;
				double sqrd_sum_patch = 0;
				for(int gy =0; gy<patch_size;gy++)
				{
					for(int gx = 0; gx<patch_size;gx++)
					{
						int ix = x - half_patch_size + gx;
						int iy = y - half_patch_size + gy;
						if(ix>=0 && ix < width && iy >=0 && iy <height)
						{
							product_sum += input_img.data[iy*width+ix]*gauss_img.at<float>(gx,gy);
							sqrd_sum_input += input_img.data[iy*width+ix]*input_img.data[iy*width+ix];
							sqrd_sum_patch += gauss_img.at<float>(gx,gy)*gauss_img.at<float>(gx,gy);
						}
					}
				}
				//差ではないが，上記他の手法と変数を共有しているため
				sum_diff = 1-product_sum/(sqrt(sqrd_sum_input*sqrd_sum_patch));
			}
			f_match_map.at<float>(y,x) = (float)sum_diff;
			if(sum_max < sum_diff && mask_img.data[y*width+x]>0)
			{
				sum_max = sum_diff;
				max_loc.x = x;
				max_loc.y = y;
			}
			if(sum_min > sum_diff && mask_img.data[y*width+x]>0)
			{
				sum_min = sum_diff;
				min_loc.x = x;
				min_loc.y = y;
			}
		}
	}
	double f_map_val_max, f_map_val_min;
	cv::minMaxIdx(f_match_map,&f_map_val_min,&f_map_val_max);
	for(int y=0;y<height;y++)
	{
		for(int x=0;x<width;x++)
		{
			match_map.data[y*width+x] = 255.0/(f_map_val_max-f_map_val_min)*(f_match_map.at<float>(y,x)-f_map_val_min);
		}
	}


	match_pt = min_loc;

}





private: System::Void bgworker_tracking_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
			 tracking(false);
		 }

private: System::Void bgworker_tracking_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {
			progressBar->Value = e->ProgressPercentage;
		 }

private: System::Void bgworker_tracking_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
			 
			 if (tracking_cancelled)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("    キャンセルされました");
				 }
				 else
				 {
					 textToLog("	Tracking has been canceled.");
				 }
				 //textToLog("    ※途中までの結果について解析が可能です．もう一度トラッキングを行うと結果が上書きされます");
				 tracking_cancelled = false;
			 } else {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("    トラッキングが完了しました");
				 }
				 else
				 {
					 textToLog("	Tracking completed");
				 }
			 }

			 showTrackInfo();
			 gb_boxarea->Enabled = true;
			 gb_ROI->Enabled = true;
			 //gb_smoothing->Enabled = true;//joints廃止に伴う変更eijwat
			 //gb_bonecalc->Enabled = true;
			 gb_determinesize->Enabled =true;
			 gb_detecterror->Enabled= true;
			 panel_playercontrol->Enabled = true;
			 trackBar->Enabled = true;
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 b_track_exec->Text = "トラッキング実行";
			 }
			 else
			 {
				 b_track_exec->Text = "Execute tracking";
			 }

			 tracking_done = true;
			 checkBox_showmarkers->Enabled = true;
			 checkBox_showmarkers->Checked = true;
			 cb_forclick->Enabled = true;//eijwat
			 gb_writingvideo->Enabled = true;
			 gb_saveresult->Enabled = true;
			 gb_saveparam->Enabled = true;
			 gb_ROI->Enabled = true;
			 //groupBox3->Enabled = true;


			 if(target_frame_set)
			 {
				 drawMarked(true,sttime,lsttime,CV_RGB(0,30,255));
			 }
			 else
			 {
				 drawMarked(false,0,0,CV_RGB(0,0,0));
			 }

		 }



private: System::Void b_track_exec_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(video_set)
			 {
				 if(!tracking_now)
				 {
					 progressBar->Maximum = 100;
					 progressBar->Minimum = 0;
					 trackBar->Enabled = false;
					 if(englishToolStripMenuItem->Checked==false)
					 {
						 textToLog("・トラッキングを実行しています．．．");
						 //textToLog("・ボックスさいず" + boxarea.width + "）");
						 //textToLog("・ボックスさいず" + boxarea.height + "）");
					 }
					 else
					 {
						 textToLog("・Now tracking");
					 }
					 bgworker_tracking->RunWorkerAsync();

					 tracking_now = true;
					 if(englishToolStripMenuItem->Checked==false)
					 {
						 b_track_exec->Text = "キャンセル";
					 }
					 else
					 {
						 b_track_exec->Text = "Cancel";
					 }

					 gb_boxarea->Enabled = false;
					 gb_ROI->Enabled = false;
					 //gb_smoothing->Enabled = false;//joints廃止に伴う変更eijwat
					 //gb_bonecalc->Enabled = false;
					 gb_determinesize->Enabled =false;
					 panel_playercontrol->Enabled = false;
				 }
				 else
				 {
					 showTrackInfo();
					 bgworker_tracking->CancelAsync();
					 if(englishToolStripMenuItem->Checked==false)
					 {
						 b_track_exec->Text = "トラッキング実行";
					 }
					 else
					 {
						 b_track_exec->Text = "Execute tracking";
					 }
					 tracking_now = false;
					 tracking_done = true;
					 trackBar->Enabled = true;
					 gb_boxarea->Enabled = true;
					 gb_ROI->Enabled = true;
					 //gb_smoothing->Enabled = true;//joints廃止に伴う変更eijwat
					 //gb_bonecalc->Enabled = true;
					 gb_determinesize->Enabled =true;
					 gb_writingvideo->Enabled = true;
					 gb_saveresult->Enabled = true;
					 gb_saveparam->Enabled = true;
					 gb_ROI->Enabled = true;
					 //groupBox3->Enabled = true;
					 panel_playercontrol->Enabled = true;
					 checkBox_showmarkers->Enabled = true;
					 checkBox_showmarkers->Checked = true;
					 cb_forclick->Enabled = true;//eijwat

				 }
			 }else
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("-> \"動画を読込んで下さい\"");
				 }
				 else
				 {
					 MessageBox::Show("-> \"A video file must be loaded first");
				 }
			 }

		 }




private: System::Void b_debug_Click(System::Object^  sender, System::EventArgs^  e) {
			 					 progressBar->Maximum = 100;
					 progressBar->Minimum = 0;
					 if(englishToolStripMenuItem->Checked==false)
					 {
						 textToLog("・トラッキングを実行しています．．．");
					 }
					 else
					 {
						 textToLog("・Now tracking");
					 }
					

					 tracking_now = true;
					 if(englishToolStripMenuItem->Checked==false)
					 {
						 b_track_exec->Text = "キャンセル";
					 }
					 else
					 {
						 b_track_exec->Text = "Cancel";
					 }

					 gb_boxarea->Enabled = false;
					 gb_ROI->Enabled = false;
					 //gb_smoothing->Enabled = false;//joints廃止に伴う変更eijwat
					 //gb_bonecalc->Enabled = false;
					 gb_determinesize->Enabled =false;
					 panel_playercontrol->Enabled = false;
					 tracking(true);
		 }



private: System::Void checkBox_showmarkers_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			showDisp();
		 }




/*****************前処理（魚のおおよそのサイズを決定する)********************************/
/*****************Setting of Fish Size///////////////////********************************/
private: System::Void b_startsize_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(englishToolStripMenuItem->Checked==false)
				 {
				 textToLog("・バーを左右に動かして魚の大まかなサイズを決定して下さい \n    →[確認]により比較\n    →[完了]にて決定");
			 }
			 else
			 {
				 textToLog("・Slide the bar below to set an approximate fish size\n		[checking] for checking\n	→[confirm] for finish setting");
			 }
			 setting_size = true;
			 trackBar_sizebinary->Enabled = true;
			 b_check->Enabled = true;
			 b_setsize->Enabled = true;
			 b_startsize->Enabled = false;
			 gb_boxarea->Enabled = false;
			 gb_ROI->Enabled = false;
			 gb_tracking->Enabled = false;
			 //gb_smoothing->Enabled = false;//joints廃止に伴う変更eijwat
			 //gb_bonecalc->Enabled = false;
			 cv::Mat subImg0;
			 cv::Mat mimg;
			 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
			 cap >> mimg;
			 cv::cvtColor(mimg,subImg0,CV_RGB2GRAY);
			 cv::absdiff(subImg0,bcgdImg,subImg0);


			 /*マスクと背景*/
			 cv::Mat mask(cv::Size(width0,height0),CV_8UC1,cv::Scalar(0));
			 cv::rectangle(mask,boxarea,cv::Scalar(1),-1,CV_AA);
			 cv::Mat subImg;
			 subImg0.copyTo(subImg,mask);
			 cv::threshold(subImg,subImg,bin_threshold,255,CV_THRESH_BINARY);
			 cv::Mat kernel(cv::Size(5,5),CV_8UC1,cv::Scalar(0));
			 cv::circle(kernel,cv::Point(2,2),2,cv::Scalar(255),-1,CV_AA);
			 cv::threshold(subImg,subImg,5,255,CV_THRESH_BINARY);
			 if(cb_zoomin->Checked)
			 {
				 cv::Mat mimg_roi = subImg(boxarea);
				 if((double)boxarea.width/(double)boxarea.height < (double)pictureBox->Width/(double)pictureBox->Height)
				 {
					 cv::Mat mimgshow(cv::Size(boxarea.height*pictureBox->Width/pictureBox->Height,boxarea.height),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(mimgshow.cols*0.5-boxarea.width*0.5,0,boxarea.width,boxarea.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }
				 else
				 {
					 cv::Mat mimgshow(cv::Size(boxarea.width,boxarea.width*pictureBox->Height/pictureBox->Width),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(0,mimgshow.rows*0.5-boxarea.height*0.5,boxarea.width,boxarea.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }
				 
			 }
			 else
			 {
				 DrawMatResizedC1(subImg, pictureBox);
			 }

		 }



private: System::Void trackBar_sizebinary_Scroll(System::Object^  sender, System::EventArgs^  e) {
			 bin_threshold = trackBar_sizebinary->Value;
			 
			 cv::Mat subImg0;
			 cv::Mat mimg;
			 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
			 cap >> mimg;
			 cv::cvtColor(mimg,subImg0,CV_RGB2GRAY);
			 cv::absdiff(subImg0,bcgdImg,subImg0);
			 /*マスクと背景*/
			 cv::Mat mask(cv::Size(width0,height0),CV_8UC1,cv::Scalar(0));
			 cv::rectangle(mask, boxarea, cv::Scalar(1), -1, CV_AA);//aquabox->boxarea
			 cv::Mat subImg;
			 subImg0.copyTo(subImg,mask);
			 cv::threshold(subImg,subImg,bin_threshold,255,CV_THRESH_BINARY);
			 cv::Mat kernel(cv::Size(5,5),CV_8UC1,cv::Scalar(0));
			 cv::circle(kernel,cv::Point(2,2),2,cv::Scalar(255),-1,CV_AA);
			 cv::threshold(subImg,subImg,5,255,CV_THRESH_BINARY);
			  if(cb_zoomin->Checked)
			 {
				 cv::Mat mimg_roi = subImg(aquabox);
				 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.height*pictureBox->Width/pictureBox->Height,aquabox.height),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(mimgshow.cols*0.5-aquabox.width*0.5,0,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }
				 else
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.width,aquabox.width*pictureBox->Height/pictureBox->Width),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(0,mimgshow.rows*0.5-aquabox.height*0.5,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }

				 
				 
			 }
			 else
			 {
				 DrawMatResizedC1(subImg, pictureBox);
			 }
		 }





private: System::Void b_check_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(setting_size)
			 {
				 showDisp();
				 setting_size = false;
			 }
			 else
			 {
				 cv::Mat subImg0;
				 cv::Mat mimg;
				 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
				 cap >> mimg;
				 cv::cvtColor(mimg,subImg0,CV_RGB2GRAY);
				 cv::absdiff(subImg0,bcgdImg,subImg0);
				 /*マスクと背景*/
				 cv::Mat mask(cv::Size(width0,height0),CV_8UC1,cv::Scalar(0));
				 cv::rectangle(mask,aquabox,cv::Scalar(1),-1,CV_AA);//aquabox
				 cv::Mat subImg;
				 subImg0.copyTo(subImg,mask);
				 cv::threshold(subImg,subImg,bin_threshold,255,CV_THRESH_BINARY);
				 cv::Mat kernel(cv::Size(5,5),CV_8UC1,cv::Scalar(0));
				 cv::circle(kernel,cv::Point(2,2),2,cv::Scalar(255),-1,CV_AA);
				 cv::threshold(subImg,subImg,5,255,CV_THRESH_BINARY);
				  if(cb_zoomin->Checked)
			 {
				 cv::Mat mimg_roi = subImg(aquabox);
				 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.height*pictureBox->Width/pictureBox->Height,aquabox.height),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(mimgshow.cols*0.5-aquabox.width*0.5,0,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }
				 else
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.width,aquabox.width*pictureBox->Height/pictureBox->Width),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(0,mimgshow.rows*0.5-aquabox.height*0.5,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }

				 
				 
			 }
			 else
			 {
				 DrawMatResizedC1(subImg, pictureBox);
			 }
				 setting_size = true;
			 }
		 }




private: System::Void b_setsize_Click(System::Object^  sender, System::EventArgs^  e) {
			 cv::Mat subImg0;
			 cv::Mat mimg;
			 cap.set(CV_CAP_PROP_POS_FRAMES,iframe_now);
			 cap >> mimg;
			  cv::cvtColor(mimg,subImg0,CV_RGB2GRAY);
			 cv::absdiff(subImg0,bcgdImg,subImg0);
			 /*マスクと背景*/
			 cv::Mat mask(cv::Size(width0,height0),CV_8UC1,cv::Scalar(0));
			 cv::rectangle(mask,aquabox,cv::Scalar(1),-1,CV_AA);
			 cv::Mat subImg;
			 subImg0.copyTo(subImg,mask);
			 cv::threshold(subImg,subImg,bin_threshold,255,CV_THRESH_BINARY);
			 cv::Mat kernel(cv::Size(5,5),CV_8UC1,cv::Scalar(0));
			 cv::circle(kernel,cv::Point(2,2),2,cv::Scalar(255),-1,CV_AA);
			 cv::threshold(subImg,subImg,5,255,CV_THRESH_BINARY);
			  if(cb_zoomin->Checked)
			 {
				 cv::Mat mimg_roi = subImg(aquabox);
				 if((double)aquabox.width/(double)aquabox.height < (double)pictureBox->Width/(double)pictureBox->Height)
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.height*pictureBox->Width/pictureBox->Height,aquabox.height),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(mimgshow.cols*0.5-aquabox.width*0.5,0,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }
				 else
				 {
					 cv::Mat mimgshow(cv::Size(aquabox.width,aquabox.width*pictureBox->Height/pictureBox->Width),CV_8UC1,CV_RGB(0,0,0));
					 cv::Mat mimgshow_roi = mimgshow(cv::Rect(0,mimgshow.rows*0.5-aquabox.height*0.5,aquabox.width,aquabox.height));
					 mimg_roi.copyTo(mimgshow_roi);
					 DrawMatResizedC1(mimgshow,pictureBox);
				 }

				 
				 
			 }
			 else
			 {
				 DrawMatResizedC1(subImg, pictureBox);
			 }
			 
			 //魚の特徴ベクトルをとる
			 // 大きさ・平均輝度・最大輝度・最小輝度
			 int num = 0;
			 int max = INT_MIN,min = INT_MAX;
			 double average=0;
			 for(int i=0;i<subImg.cols*subImg.rows;i++)
			 {
				 if(subImg.data[i] > 128)
				 {
					 num++;
					 int val = (int)subImg0.data[i];
					 average+=(double)val;
					 if(max < val) max = val;
					 if(min > val) min = val;
				 }
			 }
			 size_fish = num;
			 //size_fish = 200;これくらいのサイズだとエラーしないな
			 average/=(double)num;
			 max_fish = max;
			 min_fish = min;
			 ave_fish = average;
			 //textToLog("max_fish:"+max_fish);
			 //textToLog("min_fish:"+min_fish);
			 //textToLog("ave_fish:"+ave_fish);



			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・サイズ決定（サイズはおおよそ"+size_fish+"）");
				 //textToLog("    →骨格を表現する点数を指定後，[トラッキング実行]クリック");//joints廃止に伴う変更eijwat
			 }
			 else
			 {
				 textToLog("・The size has been set (Approximately "+size_fish+"）");
				 //textToLog("    →Change the number of joints if necessary, and click on [Execute tracking]");//joints廃止に伴う変更eijwat
			 }
			 setting_size = false;
			 trackBar_sizebinary->Enabled = false;
			 b_check->Enabled = false;
			 b_setsize->Enabled = false;
			 b_startsize->Enabled = true;
			 gb_boxarea->Enabled = true;
			 gb_ROI->Enabled = true;
			 gb_tracking->Enabled = true;
			 //gb_smoothing->Enabled = true;//joints廃止に伴う変更eijwat
			 //gb_bonecalc->Enabled = true;
			 showDisp();
			 size_set = true;
		 }




/////////////////////////////////////////////////////////////////////
/*******************保存********************************************/
/*******************save********************************************/
/////////////////////////////////////////////////////////////////////

//_____背景画像_____
//BackGround Image
private: System::Void b_savebcgdimage_Click(System::Object^  sender, System::EventArgs^  e) {
			 SaveFileDialog^ bcgd_save_diag = gcnew SaveFileDialog;
			 //ファイルフィルタ 
			 bcgd_save_diag->Filter = "背景画像ファイル(*.png)|*.png"; 
			 //ダイアログの表示 
			 if (bcgd_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return; 
			 //System::String^型のファイル名
			 textToLog(bcgd_save_diag->FileName);
			 cv::imwrite(cvtStrStr(bcgd_save_diag->FileName),bcgdImg);
		 }




//____トラッキング結果_____
//Results of Tracking
private: System::Void b_saveresultdata_Click(System::Object^  sender, System::EventArgs^  e) {
			 SaveFileDialog^ txt_save_diag = gcnew SaveFileDialog;

			 bool proceed = false;
			 if((int)head_marked.size() != num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("トラッキング未完了のため，途中経過を保存");
				 }
				 else
				 {
					 MessageBox::Show("Tracking is incomplete. The partial result is to be used");
				 }
				 if(target_frame_set) proceed = true;
			 }
			 else
			 {
				 proceed = true;
			 }

			 if(!proceed)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("対象フレームを指定して下さい");
				 }
				 else
				 {
					 MessageBox::Show("Select target frames");
				 }
			 }
			 else
			 {
				 //ファイルフィルタ
				 if(radioButton_txt->Checked)
				 {
					 String^ strvideoname = gcnew String( filename_nopath.c_str() );
					 txt_save_diag->FileName = strvideoname+"_tracking.txt";
					 txt_save_diag->Filter = "タブ区切りテキストファイル(*.txt)|*.txt";
					 if (txt_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return;
					 std::ofstream fout(cvtStrStr(txt_save_diag->FileName));

					 fout << "Aquarium(xywh):"<<"\t"

					 <<aquabox.x << "\t" <<aquabox.y << "\t"
					 << aquabox.width << "\t" << aquabox.height << "\n";



					 int t_start, t_end;
					 if(target_frame_set)
					 {
						 t_start = sttime;
						 t_end = lsttime+1;
					 }
					 else
					 {
						 t_start = 0;
						 t_end = (int)heads.size();
					 }

					 

					 for(int i=t_start;i<t_end;i++)
					 {
						 fout << i <<"\t"
							 <<heads[i].x <<"\t"<<heads[i].y <<"\t"
							 <<tails[i].x << "\t"<< tails[i].y ;
						 //joints廃止に伴う変更eijwat

						 /*						 for(int j=0;j<(int)joints[i].size();j++)
						 {
							 fout <<"\t"<<joints[i][j].x<<"\t"<<joints[i][j].y;
						 }*/

						 fout <<std::endl;
					 }
				 }
				 else if(radioButton_csv->Checked)
				 {
					 String^ strvideoname = gcnew String( filename_nopath.c_str() );
					 txt_save_diag->FileName = strvideoname+"_tracking.csv";
					 txt_save_diag->Filter = "コンマ区切りテキストファイル(*.csv)|*.csv";
					 if (txt_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return;
					 std::ofstream fout(cvtStrStr(txt_save_diag->FileName));

					 fout << "Aquarium(xywh):" << ","

						 << aquabox.x << "," << aquabox.y << "," 
						 << aquabox.width << "," << aquabox.height << "\n";


					 int t_start, t_end;
					 if(target_frame_set)
					 {
						 t_start = sttime;
						 t_end = lsttime+1;
					 }
					 else
					 {
						 t_start = 0;
						 t_end = (int)heads.size();
					 }
					 for(int i=t_start;i<t_end;i++)
					 {
						 fout << i <<","
							 <<heads[i].x <<","<<heads[i].y <<","
							 <<tails[i].x << ","<< tails[i].y;
						 //joints廃止に伴う変更eijwat
						 /*						 for(int j=0;j<(int)joints[i].size();j++)
						 {
							 fout <<","<<joints[i][j].x<<","<<joints[i][j].y;
						 }*/

						 fout <<std::endl;
					 }
				 }
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・トラッキング結果を保存しました");
				 }
				 else
				 {
					 textToLog("・Tracking result has been saved.");
				 }
			 }
		 }



private: System::Void b_savemarksonoriginal_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 SaveFileDialog^ video_save_diag = gcnew SaveFileDialog;
			 //ファイルフィルタ 
			 video_save_diag->Filter = "動画ファイル(*.avi)|*.avi"; 
			 //ダイアログの表示 
			 if (video_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return;
			

			 
			 progressBar->Maximum = 100;
			 progressBar->Minimum = 0;
			 bool proceed = false;
			 if((int)head_marked.size() != num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("    トラッキングが完了していないので，途中までを保存");
				 }
				 else
				 {
					 textToLog("	Tracking is incomplete. The partial result is to be used");
				 }
				 if(target_frame_set) proceed = true;
			 }
			  else
			 {
				 proceed = true;
			 }

			 if(!proceed)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("対象フレームを指定して下さい");
				 }
				 else
				 {
					 MessageBox::Show("Select target frames");
				 }
			 }
			 else
			 {

				 gb_writingvideo->Enabled = false;
				 gb_saveresult->Enabled = false;
				 gb_saveparam->Enabled = false;

				 if(englishToolStripMenuItem->Checked==false)
				 {

					 textToLog("・結果動画を保存しています");
				 }
				 else
				 {
					 textToLog("・The result video file is being saved.");
				 }
				 bgworker_writevideo->RunWorkerAsync(video_save_diag->FileName);	
			 }
		 }



private: System::Void bgworker_writevideo_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
			 System::String^ strfilename = (System::String^)e->Argument;
			 saving_video(strfilename);
		 }


private: System::Void bgworker_writevideo_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {
			 progressBar->Value = e->ProgressPercentage;
		 }


private: System::Void bgworker_writevideo_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("    保存しました");
			 }
			 else
			 {
				 textToLog("	The file has been saved");
			 }
			 gb_writingvideo->Enabled = true;
			 gb_saveresult->Enabled = true;
			 gb_saveparam->Enabled = true;
		 }


private: void saving_video(System::String^ strfilename)
		 {
			 std::string filename = cvtStrStr(strfilename);
			 double fps = cap.get(CV_CAP_PROP_FPS);
			 cv::VideoWriter vwriter(filename,-1, fps, cv::Size(Form1::width0,Form1::height0),1);

			 int t_start,t_end;
			 if(target_frame_set)
			 {
				 t_start = sttime;
				 t_end = lsttime+1;
			 }
			 else
			 {
				 t_start = 0;
				 t_end = (int)heads.size();
			 }



			 for(int t=t_start;t<t_end;t++)
			 {
				 bgworker_writevideo->ReportProgress(cvRound(100.0*(double)(t-t_start+1)/(double)(t_end-t_start)));

				 cv::Mat mimg(cv::Size(width0,height0),CV_8UC3,CV_RGB(0,0,0));

				 if(cb_writeoriginal->Checked)
				 {
					 cap.set(CV_CAP_PROP_POS_FRAMES,t);
					 cap>>mimg;
				 }

				 if (cb_writebinary->Checked)
				 {
					 cap.set(CV_CAP_PROP_POS_FRAMES, t);
					 cap >> mimg;
					 cv::Mat subImg0;
					 cv::cvtColor(mimg, subImg0, CV_RGB2GRAY);
					 cv::absdiff(subImg0, bcgdImg, subImg0);
					 /*マスクと背景*/
					 cv::Mat mask(cv::Size(width0, height0), CV_8UC1, cv::Scalar(0));
					 cv::rectangle(mask, boxarea, cv::Scalar(1), -1, CV_AA);//aquabox->boxarea
					 cv::Mat subImg;
					 subImg0.copyTo(subImg, mask);
					 cv::threshold(subImg, subImg, bin_threshold, 255, CV_THRESH_BINARY);
					 cv::Mat kernel(cv::Size(5, 5), CV_8UC1, cv::Scalar(0));
					 cv::circle(kernel, cv::Point(2, 2), 2, cv::Scalar(255), -1, CV_AA);
					 cv::threshold(subImg, subImg, 5, 255, CV_THRESH_BINARY);

					 subImg.copyTo(mimg);

				 }


				 if(cb_writehead->Checked) cv::circle(mimg,heads[t],3,CV_RGB(255,0,0),1,CV_AA);
				 if(cb_writetail->Checked) cv::circle(mimg,tails[t],3,CV_RGB(0,0,255),1,CV_AA);



				 if(cb_writebox->Checked && box_area_set)
				 {
					 cv::rectangle(mimg,aquabox,CV_RGB(0,0,255),1);//eijwat ver3.2
				 }

				 if(cb_writeroi->Checked && roi_set)
				 {
					 for(int i=0;i<(int)ROIs.size();i++)
					 {
						 cv::rectangle(mimg,ROIs[i],ROI_color[i],1);

					 } 
				 }
				
				 vwriter << mimg;
			 }
		 }




private: System::Void rb_roitop_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 label_bartop->ForeColor = System::Drawing::Color::Blue;
			 label_barbottom->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barright->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barleft->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 ROI_targetline[roi_index] = 1;
			 
		 }


private: System::Void rb_roibottom_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 label_bartop->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barbottom->ForeColor = System::Drawing::Color::Blue;
			 label_barright->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barleft->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 ROI_targetline[roi_index] = 2;
		 }


private: System::Void rb_roiright_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 label_bartop->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barbottom->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barright->ForeColor = System::Drawing::Color::Blue;
			 label_barleft->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 ROI_targetline[roi_index] = 3;
		 }


private: System::Void rb_roileft_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 label_bartop->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barbottom->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barright->ForeColor = System::Drawing::SystemColors::ButtonShadow;
			 label_barleft->ForeColor = System::Drawing::Color::Blue;
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 ROI_targetline[roi_index] = 4;
		 }


private: System::Void comboBox_roianal_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 int targetline = ROI_targetline[roi_index];
			 double targetangle = ROI_targetangle[roi_index];
			 int totalhot = ROI_totalhot[roi_index];

			 if(targetline==1)
			 {
				 rb_roitop->Checked = true;
			 }
			 else if(targetline==2)
			 {
				 rb_roibottom->Checked = true;
			 }
			 else if(targetline==3)
			 {
				 rb_roiright->Checked = true;
			 }
			 else if(targetline==4)
			 {
				 rb_roileft->Checked = true;
			 }

			 tb_roiangle->Text = ""+targetangle;
		 }


private: System::Void tb_roiangle_TextChanged(System::Object^  sender, System::EventArgs^  e) {
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 double angle = atof(cvtStrStr(tb_roiangle->Text).c_str());
			 ROI_targetangle[roi_index] = angle;

		 }


private: System::Void b_execanal_Click(System::Object^  sender, System::EventArgs^  e) {
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 int targetline = ROI_targetline[roi_index];
			 double targetangle = ROI_targetangle[roi_index];
			 std::map<int,int> whenhot;

			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("解析を開始しました");
			 }
			 else
			 {
				 textToLog("Analysing data");
			 }
			 if(heads.size()!=num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・トラッキングが完了していないので，途中までの結果を解析します");
				 }
				 else
				 {
					 textToLog("・Tracking is incomplete. The partial result is to be used.");
				 }
			 }

			 int num_head_only = 0;
			 int num_head_angle = 0;

			 int t_start, t_end;
			 if(target_frame_set)
			 {
				 t_start = sttime;
				 t_end = lsttime+1;
			 }
			 else
			 {
				 t_start = 0;
				 t_end = (int)heads.size();
			 }

			 for(int t=t_start;t<t_end;t++)
			 {
				 bool head_inside = false;
				 cv::Point head = heads[t];
				 cv::Rect roi = ROIs[roi_index];

				 //ROI内にいるかどうかの判定
				 if(head.x >= roi.x && head.x <= roi.x+roi.width
					 && head.y>=roi.y && head.y <= roi.y+roi.height)
				 {
					 head_inside = true;//ROI内にいるというboolをオンにする

					 cv::Point2f middle;
					 middle = tails[t];//joints廃止に伴う変更＝角度は頭と尻尾で計算するeijwat


					 /*
					 int j_size = joints[t].size();
					 if(j_size%2 != 0)
					 {
						 middle = joints[t][j_size/2];
					 }
					 else
					 {
						 middle.x = (float)(joints[t][j_size/2 -1].x + joints[t][j_size/2].x)*0.5;
						 middle.y = (float)(joints[t][j_size/2 -1].y + joints[t][j_size/2].y)*0.5;
					 }
					 */


					 cv::Point2f wall;
					 if(targetline == 1)
					 {
						 if(head.y < middle.y)
						 {
							 double ang = 90 - 180.0/CV_PI * std::atan2(fabs(head.y-middle.y),fabs(head.x-middle.x));
							 if(ang <= targetangle)
							 {
								 whenhot[t] = 2;
								 num_head_angle++;
							 }
							 else
							 {
								 whenhot[t] = 1;
								 num_head_only++;
							 }
						 }
						 else
						 {
							 whenhot[t] = 1;
							 num_head_only++;//eijwat
						 }
					 }
					 else if(targetline == 2)
					 {
						 if(head.y > middle.y)
						 {
							 double ang = 90 - 180.0/CV_PI * std::atan2(fabs(head.y-middle.y),fabs(head.x-middle.x));
							 if(ang<= targetangle)
							 {
								 whenhot[t] = 2;
								 num_head_angle++;
							 }
							 else
							 {
								 whenhot[t] = 1;
								 num_head_only++;
							 }
						 }
						 else
						 {
							 whenhot[t] = 1;
							 num_head_only++;//eijwat
						 }
					 }
					 else if(targetline == 3)
					 {
						 if(head.x > middle.x)
						 {
							 double ang = 180.0/CV_PI * std::atan2(fabs(head.y-middle.y),fabs(head.x-middle.x));
							  if(ang<= targetangle)
							 {
								 whenhot[t] = 2;
								 num_head_angle++;
							 }
							 else
							 {
								 whenhot[t] = 1;
								 num_head_only++;
							 }
						 }
						 else
						 {
							 whenhot[t] = 1;
							 num_head_only++;//eijwat
						 }
					 }
					 else if(targetline == 4)
					 {
						 if(head.x < middle.x)
						 {
							 double ang = 180.0/CV_PI * std::atan2(fabs(head.y-middle.y),fabs(head.x-middle.x));
							  if(ang<= targetangle)
							 {
								 whenhot[t] = 2;
								 num_head_angle++;
							 }
							 else
							 {
								 whenhot[t] = 1;
								 num_head_only++;
							 }
						 }
						 else
						 {
							 whenhot[t] = 1;
							 num_head_only++;//eijwat
						 }
					 }

				 }
				 else
				 {
					 whenhot[t] = 0;
				 }
			 } // for t

			 //結果をコピー
			 ROI_whenhot[roi_index]=whenhot;


			 cv::rectangle(trackbarImg,cv::Rect(0,0,trackbarImg.cols,trackbarImg.rows),CV_RGB(0,0,0),-1);
			 for(int t=0;t<(int)whenhot.size();t++)
			 {
				 if(whenhot[t]==1)
				 {
					 drawTrackbarLine(trackbarImg,pictureBox_trackbar,t,CV_RGB(255,0,0));
				 }
				 else if(whenhot[t] == 2)
				 {
					 drawTrackbarLine(trackbarImg,pictureBox_trackbar,t,CV_RGB(255,255,0));
				 }
				 else
				 {
					 drawTrackbarLine(trackbarImg,pictureBox_trackbar,t,CV_RGB(0,0,0));
				 }
			 }

			 tb_anal_numframes->Text = ""+heads.size();
			 tb_anal_head_only->Text = ""+(num_head_only+num_head_angle);
			 tb_head_angle->Text = ""+num_head_angle;
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("解析を終了しました");
			 }
			 else
			 {
				 textToLog("Analysis has been completed");
			 }

		 }




private: System::Void b_save_roianal_Click(System::Object^  sender, System::EventArgs^  e) {
			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 cv::Rect roi = ROI_realsize[roi_index];
			 std::vector<std::string> fnames0;
			 fnames0 = split(cvtStrStr(strfilename),"\\");
			 std::vector<std::string> fname;
			 fname = split((*(fnames0.end()-1)),".");

			 bool proceed = false;
			 if((int)head_marked.size() != num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・トラッキングが完了していないので，途中までの結果を保存します");
				 }
				 else
				 {
					 textToLog("・Tracking is incomplete. The partial result is to be saved.");
				 }
				 if(target_frame_set) proceed = true;
			 }
			 else
			 {
				 proceed = true;
			 }

			 if(!proceed)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("対象フレームを指定して下さい");
				 }
				 else
				 {
					 MessageBox::Show("Select target frames");
				 }
			 }
			 else
			 {
				 SaveFileDialog^ text_save_diag = gcnew SaveFileDialog;
				 //ファイルフィルタ 
				 text_save_diag->Filter = "テキストファイル(*.txt)|*.txt"; 
				 String^ strfname = gcnew String( fname[0].c_str() );
				 text_save_diag->FileName = strfname + "_ROI_"+roi.x+"_"+roi.y+"_"+roi.width+"_"+roi.height+".txt";
				 //ダイアログの表示 
				 if (text_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return;
				 tab->Enabled = false;
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・ROI: "+roi_index+"の解析結果を保存");
				 }
				 else
				 {
					 textToLog("・Svaing the analysis result of ROI: "+roi_index);
				 }
				 std::ofstream fout(cvtStrStr(text_save_diag->FileName));

				 int t_start, t_end;
				 if(target_frame_set)
				 {
					 t_start = sttime;
					 t_end = lsttime+1;
				 }
				 else
				 {
					 t_start = 0;
					 t_end = (int)heads.size();
				 }
				 for(int t=t_start;t<t_end;t++)
				 {
					 fout <<t <<"	"<< ROI_whenhot[roi_index][t] << std::endl;
				 }
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("　保存しました");
				 }
				 else
				 {
					 textToLog("  The file has been saved");
				 }
				 tab->Enabled=true;
			 }

		 }


//////////////////////////ここにデバッグ関係のコードがあったが全部削除ver3.5


/////////////////////////設定の保存
private: System::Void b_saveparamfile_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 bool b_videofile_name = cb_videofile_name->Checked;			//動画ファイル名
			 bool b_date_exp = cb_date_exp->Checked;						//実験日
			 bool b_box_area = cb_box_area->Checked;						//対象領域の座標
			 bool b_box_area_real = cb_box_area->Checked;					//対象領域の実寸
			 bool b_fish_size = cb_fish_size->Checked;						//魚領域サイズ
			 //bool b_numjoints = cb_numjoints->Checked;						//骨格点数//joints廃止に伴う変更
			 bool b_roinum_area = cb_roinum_area->Checked;					//ROIの数・座標

			 SaveFileDialog^ setting_save_diag = gcnew SaveFileDialog;

			 //ファイルフィルタ infからtxtに変更eijwat

			 //setting_save_diag->Filter = "設定ファイル(*.inf)|*.inf"; 
			 //String^ strvideoname = gcnew String( filename_nopath.c_str() );
			 //setting_save_diag->FileName = strvideoname+"_setting.inf";
			 setting_save_diag->Filter = "Setting_Information(*.txt)|*.txt";
			 String^ strvideoname = gcnew String(filename_nopath.c_str());
			 setting_save_diag->FileName = strvideoname + "_setting.txt";


			 //ダイアログの表示 
			 if (setting_save_diag->ShowDialog() == System::Windows::Forms::DialogResult::Cancel) return; 
			 //System::String^型のファイル名 
			 System::String^ settingfname = setting_save_diag->FileName;
			 std::string fname = cvtStrStr(settingfname);
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("・設定ファイルを保存");
			 }
			 else
			 {
				 textToLog("・Saving a setting file");
			 }

			 std::ofstream fout(fname);

			 fout << "VideoFileName:";
			 if(b_videofile_name)
			 {
				 fout << filename_nopath;
			 }
			 else
			 {
				 fout << "None";
			 }

			 fout << "\nCoord&SizeOfMovie:";
			 fout << boxarea.x << "," << boxarea.y << "," << boxarea.width << "," << boxarea.height;



			 fout << "\nData:";
			 if(b_date_exp)
			 {
				 fout << cvtStrStr(tb_exp_date->Text);
			 }
			 else
			 {
				 fout << "None";
			 }



			 fout << "\nCoord&SizeOfAquarium:";
			 if(b_box_area)
			 {
				 fout << aquabox.x << "," << aquabox.y <<","<<aquabox.width<<","<<aquabox.height;
			 }
			 else
			 {
				 fout << "None";
			 }

			 fout << "\nPlainScaleOfAquarium:";
			 if(b_box_area_real)
			 {
				 fout << cvtStrStr(textBox_boxarea_width->Text) <<","<<cvtStrStr(textBox_boxarea_height->Text);
					 
			 }
			 else
			 {
				 fout <<"None";
			 }


			 fout << "\nSize&BrightnessOfFish:";
			 if(b_fish_size)
			 {
				 fout << size_fish <<"," << max_fish<<","<<min_fish<<","<<ave_fish<<","<<bin_threshold;
			 }
			 else
			 {
				 fout << "None";
			 }

			 /*			 fout << "\n骨格点数:";
			 if(b_numjoints)
			 {
				 fout << (int)track_num_joint_points->Value;
			 }
			 else
			 {
				 fout << "None";
			 }*/


			 fout << "\nNumberOfROI:";
			 if(b_roinum_area)
			 {
				 if((int)ROIs.size()!=0)
				 {
					 fout << (int)ROIs.size();
				 }
				 else
				 {
					 fout << "None";
				 }
			 }
			 else
			 {
				 fout << "None";
			 }

			 fout << "\nCoord&SizeOfROI TagetLine&Angle:";
			 if(b_roinum_area)
			 {
				 if((int)ROI_realsize.size()!=0)
				 {
					 for(int i=0;i<(int)ROI_realsize.size();i++)
					 {
						 fout <<std::endl;
						 fout << ROI_realsize[i].x << "," << ROI_realsize[i].y <<","<<ROI_realsize[i].width<<","<<ROI_realsize[i].height<<","<<ROI_targetline[i]<<","<<ROI_targetangle[i];
					 }
				 }
				 else
				 {
					 fout << "None";
				 }
			 }
			 else
			 {
				 fout << "None";
			 }
			 if(englishToolStripMenuItem->Checked==false)
			 {
				 textToLog("    保存しました");
			 }
			 else
			 {
				 textToLog("	Saved.");
			 }


		 }


private: System::Void tb_exp_date_Enter(System::Object^  sender, System::EventArgs^  e) {
			 tb_exp_date->ForeColor = System::Drawing::SystemColors::ControlText;
			 tb_exp_date->Text = "";
		 }



private: System::Void tb_exp_date_Leave(System::Object^  sender, System::EventArgs^  e) {
			 if(tb_exp_date->Text == "")
			 {
				 tb_exp_date->Text == "yyyy/mm/dd";
				 tb_exp_date->ForeColor = System::Drawing::SystemColors::GrayText;
			 }
		 }


private: System::Void cb_date_exp_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(cb_date_exp->Checked)
			 {
				 tb_exp_date->Enabled = true;
				 DateTime d1 = DateTime::Now;
				 tb_exp_date->Text = d1.ToString("yyyy/MM/dd");

			 }
			 else
			 {
				 tb_exp_date->Enabled = false;
			 }
		 }


private: System::Void cb_box_area_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(cb_box_area->Checked)
			 {
				 //なにもしない
			 }
			 else
			 {
				 cb_roinum_area->Checked = false;
			 }
		 }


private: System::Void cb_roinum_area_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 	if(!cb_box_area->Checked && cb_roinum_area->Checked)
			 {
				 MessageBox::Show("対象領域座標出力選択時のみ選択可能です");
				 cb_roinum_area->Checked = false;
			 }
		 }



//画像を拡大
//Enlargement of Images
private: System::Void cb_zoomin_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 showDisp();
		 }



//JAPANESE & ENGLISH
private: void setLanguage(std::string lang)
		 {
			 if(lang=="English")
			 {
				 LangToolStripMenuItem->Text = "言語設定";
				 textToLog("・Language has been switched to English");
				 englishToolStripMenuItem->Checked = true;
				 JapaneseToolStripMenuItem->Checked =false;
				 tab_load->Text="Load";
				 groupBox1->Text="Load video (MP4)";
				 b_loadvideofile->Text="Load";
				 label_videofilename->Text="Filename:";
				 gb_setbackground->Text="Make/load background";
				 gb_createbackground->Text="Make background";
				 b_createbackground->Text="Go!";
				 b_showbackground->Text="Display";
				 b_savebcgdimage->Text="Save";
				 b_loadbackground->Text="Load";
				 label_bcgdimagename->Text="Filename:";
				 gb_setparam->Text="Load settings";
				 b_loadparameter->Text="Load";
				 checkBox_showmarkers->Text="Show markers";
				 checkBox_showoriginal->Text="Show movie";
				 cb_showboxarea->Text="Show aquarium";
				 cb_showroi->Text ="Show ROIs";
				 gb_speedcontrol->Text="Speed";
				 tab_tracking->Text="Tracking";
				 tabPage1->Text="Save results";
				 tabPage2->Text="ROI analysis";
				 gb_boxarea->Text="Box area";
				 label1->Text="Measure:";
				 b_set_boxarea->Text="Set box";
				 gb_determinesize->Text="Set fish size";
				 b_startsize->Text="Start setting";
				 b_check->Text="Check";
				 b_setsize->Text="Confirm";
				 gb_tracking->Text="Tracking";
				 label8->Text="Number of joints";
				 b_track_exec->Text="Execute tracking";
				 gb_detecterror->Text="Finding suspecious values";
				 label36->Text="Find errors";
				 b_detecterror->Text="Execute";
				 gb_smoothing->Text="Tail position smoothing";
				 gb_bonecalc->Text="Recalculating joints";
				 label5->Text="All ";
				 b_getbone_all->Text="Execute";
				 b_smooth_exec->Text="Execute";
				 gb_writingvideo->Text="Saving Movie";
				 gb_writeoption->Text="Select elements";
				 cb_writeoriginal->Text="Original";
				 cb_writehead->Text="Head";
				 cb_writetail->Text="Tail";
				 cb_writejoint->Text="Joints";
				 cb_writebox->Text="Box area";
				 cb_writeroi->Text="ROI";
				 b_savemarksonoriginal->Text="Save";
				 gb_saveresult->Text="Save settings";
				 gb_saving_as->Text="Savefile Format";
				 b_saveresultdata->Text="Save results";
				 gb_saveparam->Text="Save settings";
				 cb_videofile_name->Text="Filename";
				 cb_date_exp->Text="Experiment date";
				 cb_box_area->Text="Box (Coordinates)";
				 cb_boxarea_real->Text="Box (Measures)";
				 cb_fish_size->Text="Fish size";
				 cb_numjoints->Text="Number of joints";
				 cb_roinum_area->Text="ROIs";
				 b_saveparamfile->Text="Save";
				 label38->Text="Measure";
				 gb_ROI->Text="Region of Interest";
				 b_addROI->Text="Add ROI";
				 b_clearroi->Text="Clear All";
				 groupBox3->Text="ROI analysis";
				 label23->Text="ROI No.";
				 groupBox2->Text="Target wall";
				 rb_roitop->Text="Top";
				 rb_roileft->Text="Left";
				 rb_roibottom->Text="Right";
				 label24->Text="Bottom";
				 label24->Text="Angle:   ±";
				 b_execanal->Text="Analyze";
				 b_save_roianal->Text="Save analysis";
				 label32->Text="Analysis:";
				 label27->Text="Outside";
				 label29->Text="Head-inside";
				 label31->Text="Head-inside, Angle range-inside";
				 label33->Text="　　　　　            frames in total：";
				 label34->Text="Head-insdie：　　　　 　frames";
				 label35->Text="Head, angle inside：　　　  　　frames";
				 label41->Text = L"Settings shown below has been loaded from the file (Data can be modified）：\r\n";
				 label_readfromsettingfile->Text = L"None";
				 cb_usebinval->Text = "use the specified value for binarization";
				 b_result_to_clip->Text = "To clipboard";
				 b_anal_result_to_clip->Text = "To clipboard";



			 }
			 else if(lang=="Japanese")
			 {
				 LangToolStripMenuItem->Text = "Language";
				 textToLog("・言語を日本語に変更しました．");
				 JapaneseToolStripMenuItem->Checked = true;
				 englishToolStripMenuItem->Checked = false;
				 tab_load->Text="読込";
				 groupBox1->Text="ビデオ読込(MP4)";
				 b_loadvideofile->Text="読込";
				 label_videofilename->Text="ファイル名:";
				 gb_setbackground->Text="背景画像の作成/読込";
				 gb_createbackground->Text="背景画像作成";
				 b_createbackground->Text="作成！";
				 b_showbackground->Text="表示";
				 b_savebcgdimage->Text="保存";
				 b_loadbackground->Text="読込";
				 label_bcgdimagename->Text="ファイル名：";
				 gb_setparam->Text="設定ファイルの読込";
				 b_loadparameter->Text="読込";
				 checkBox_showmarkers->Text="マーカー表示";
				 checkBox_showoriginal->Text="動画表示";
				 cb_showboxarea->Text="水槽領域表示";
				 cb_showroi->Text ="ROI表示";
				 gb_speedcontrol->Text="再生速度";
				 tab_tracking->Text="トラッキング";
				 tabPage1->Text="結果保存";
				 tabPage2->Text="ROI解析";
				 gb_boxarea->Text="対象領域の設定";
				 label1->Text="実寸：";
				 b_set_boxarea->Text="対象領域の選択";
				 gb_determinesize->Text="魚領域のサイズ設定";
				 b_startsize->Text="設定開始";
				 b_check->Text="確認";
				 b_setsize->Text="完了";
				 gb_tracking->Text="トラッキング";
				 label8->Text="骨格点の数";
				 b_track_exec->Text="トラッキング実行";
				 gb_detecterror->Text="誤検出修正用";
				 label36->Text="異常値検出:";
				 b_detecterror->Text="実行";
				 gb_smoothing->Text="尾部のスムージング";
				 gb_bonecalc->Text="骨格点の再計算";
				 label5->Text="全フレームについて再計算";
				 b_getbone_all->Text="実行";
				 b_smooth_exec->Text="スムージング実行";gb_writingvideo	->Text="	動画保存	";		gb_writingvideo->Text="動画保存";
				 gb_writeoption	->Text="	書出し対象をチェック	";		gb_writeoption->Text="書出し対象をチェック";
				 cb_writeoriginal	->Text="	撮影動画（オリジナル）	";		cb_writeoriginal->Text="撮影動画（オリジナル）";
				 cb_writehead	->Text="	頭部	";		cb_writehead->Text="頭部";
				 cb_writetail	->Text="	尾部	";		cb_writetail->Text="尾部";
				 cb_writejoint	->Text="	骨格	";		cb_writejoint->Text="骨格";
				 cb_writebox	->Text="	対象領域矩形	";		cb_writebox->Text="対象領域矩形";
				 cb_writeroi	->Text="	ROI	";		cb_writeroi->Text="ROI";
				 b_savemarksonoriginal	->Text="	動画の書出し	";
				 gb_saveresult	->Text="	結果ファイル保存	";
				 gb_saving_as	->Text="	ファイル保存形式	";
				 b_saveresultdata	->Text="	保存	";
				 gb_saveparam	->Text="	設定の保存	";
				 cb_videofile_name	->Text="	動画ファイル名	";
				 cb_date_exp	->Text="	実験日	";		cb_date_exp->Text="実験日";
				 cb_box_area	->Text="	対象領域 (座標）	";
				 cb_boxarea_real	->Text="	対象領域 (実寸）	";
				 cb_fish_size	->Text="	魚領域サイズ	";
				 cb_numjoints	->Text="	骨格点数	";
				 cb_roinum_area	->Text="	ROIの数・実寸	";
				 b_saveparamfile	->Text="	保存	";
				 label38->Text="対象領域実寸";
				 gb_ROI->Text="Region of Interestの設定";
				 b_addROI->Text="ROI追加";
				 b_clearroi->Text="全消去";
				 groupBox3->Text="ROIの解析";
				 label23->Text="対象ROI:";
				 groupBox2->Text="対象辺の指定";
				 rb_roitop->Text="上";
				 rb_roileft->Text="左";
				 rb_roibottom->Text="右";
				 label24->Text="下";
				 label24->Text="角度範囲: ±";
				 b_execanal->Text="解析実行";
				 b_save_roianal->Text="解析結果保存";
				 label32->Text="解析結果：";
				 label27->Text="ROI外";
				 label29->Text="頭部ROI内";
				 label31->Text="頭部ROI内・角度範囲内";
				 label33->Text="解析対象　　　　　フレーム中：";
				 label34->Text="頭部がROI内：　　　　　フレーム";
				 label35->Text="頭部・角度が範囲内：　　　　　フレーム";
				 label41->Text = L"ファイルより以下の設定項目の読込完了（トラッキングタブにて変更可能）：\r\n";
				 cb_usebinval->Text = "指定した閾値で2値化";
				 label_readfromsettingfile->Text = L"なし";
				 b_result_to_clip->Text = "クリップボードへ";
				 b_anal_result_to_clip->Text = "クリップボードへ";

			 }
		 }

private: System::Void englishToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 setLanguage("English");
		 }



private: System::Void JapaneseToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 setLanguage("Japanese");
		 }


private: System::Void pictureBoxDone_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

			 int t = cvRound((trackBar->Maximum+1)*(double)e->X/pictureBoxDone->Width);

			 if(sttime_mdown)
			 {
				 drawMarked(true,sttime,t,CV_RGB(50,170,255));
			 }
			 else
			 {
				 int tf = t;
				 std::set<int>::iterator ithead;
				 std::set<int>::iterator ittail;
				 ithead = head_marked.find(tf);
				 ittail = tail_marked.find(tf);
				 pictureBoxDone->Cursor = System::Windows::Forms::Cursors::Arrow;
				 if(ithead!=head_marked.end() && ittail!=tail_marked.end())
				 {
					 pictureBoxDone->Cursor = System::Windows::Forms::Cursors::Hand;
					 on_done_frames = true;
				 }
				 else
				 {
					 on_done_frames = false;
				 }

				 if(on_done_frames)
				 {
					 while(true)
					 {
						 ithead++;
						 ittail++;
						 if(ithead == head_marked.end() || ittail == tail_marked.end())
						 {
							 lsttime_temp = tf;
							 break;
						 }
						 else if((*ithead) - tf > 1 || (*ittail)-tf>1 )
						 {
							 lsttime_temp = tf;
							 break;
						 }
						 tf = (*ithead);
					 }

					 if(lsttime>=num_frames) lsttime = num_frames-1; 

					 while(true)
					 {
						 ithead--;
						 ittail--;
						 if(ithead == head_marked.begin()|| ittail == tail_marked.begin())
						 {
							 tf = (*ithead);
							 sttime_temp = tf;
							 break;
						 }
						 else if(tf-(*ithead)> 1  || tf-(*ittail)>1 )
						 {
							 sttime_temp = tf;
							 break;
						 }
						 tf = (*ithead);
					 }

					 drawMarked(true,sttime_temp,lsttime_temp,CV_RGB(50,170,255));
				 }
				 else
				 {
					 drawMarked(false,0,0,CV_RGB(0,0,0));
				 }
			 }
		 }


private: System::Void pictureBoxDone_MouseLeave(System::Object^  sender, System::EventArgs^  e) {
			 on_done_frames = false;
			 if(target_frame_set)
			 {
				 drawMarked(true,sttime,lsttime,CV_RGB(0,30,255));
				 sttime_temp = 0;
				 lsttime_temp = 0;
			 }
			 else
			 {
				 drawMarked(false,0,0,CV_RGB(0,0,0));
			 }
		 }


private: System::Void trackBar_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		 label_time->Text = ""+iframe_now;
		 }


private: System::Void pictureBoxDone_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 if(e->Button == System::Windows::Forms::MouseButtons::Left)
			 {
				 if(on_done_frames)
				 {
					 sttime = sttime_temp;
					 lsttime = lsttime_temp;
					 target_frame_set = true;
					 if(englishToolStripMenuItem->Checked==false)
					 {

						 textToLog("・解析の対象領域: "+sttime+"～"+lsttime);
					 }
					 else
					 {
						 textToLog("・Target frames are: "+sttime+"～"+lsttime);
					 }

					 drawMarked(true,sttime,lsttime,CV_RGB(0,30,255));
				 }
			 }
		 }
		


private: System::Void pictureBoxDone_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			 if(e->Button == System::Windows::Forms::MouseButtons::Right)
			 {
				 sttime = cvRound((trackBar->Maximum+1)*(double)e->X/pictureBoxDone->Width);
				 pictureBoxDone->Cursor = System::Windows::Forms::Cursors::IBeam;
				 sttime_mdown = true;
			 }
		 }



private: System::Void pictureBoxDone_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
			if(sttime_mdown)
			{
				lsttime = cvRound((trackBar->Maximum+1)*(double)e->X/pictureBoxDone->Width);
				pictureBoxDone->Cursor = System::Windows::Forms::Cursors::Arrow;
				sttime_mdown = false;
				target_frame_set = true;
			}
		 }


		 //結果をクリップボードへ追加
private: System::Void b_result_to_clip_Click(System::Object^  sender, System::EventArgs^  e) {
			 bool proceed = false;
			 if((int)head_marked.size() != num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("トラッキング未完了のため，途中経過をコピー");
				 }
				 else
				 {
					 MessageBox::Show("Tracking is incomplete. The partial result is to be copied to clipboard");
				 }
				 if(target_frame_set) proceed = true;
			 }
			 else
			 {
				 proceed = true;
			 }

			 if(!proceed)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("対象フレームを指定して下さい");
				 }
				 else
				 {
					 MessageBox::Show("Select target frames");
				 }
			 }
			 else
			 {

				 int t_start, t_end;
				 if(target_frame_set)
				 {
					 t_start = sttime;
					 t_end = lsttime+1;
				 }
				 else
				 {
					 t_start = 0;
					 t_end = (int)heads.size();
				 }
				 String^ strdata = gcnew String("");
				 for(int i=t_start;i<t_end;i++)
				 {
					 strdata += i;
					 strdata += "\t";
					 strdata += heads[i].x;
					 strdata += "\t";
					 strdata +=heads[i].y;
					 strdata += "\t";
					 strdata +=tails[i].x;
					 strdata +="\t";
					 strdata +=tails[i].y;

					 //joints廃止に伴う変更eijwat
					 /*					 for(int j=0;j<(int)joints[i].size();j++)
					 {
						 strdata+="\t";
						 strdata+=joints[i][j].x;
						 strdata+="\t";
						 strdata+=joints[i][j].y;
					 }*/



					 strdata+="\n";
				 }
				 Clipboard::SetText(strdata);
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・トラッキング結果をクリップボードへコピーしました");
				 }
				 else
				 {
					 textToLog("・Tracking result has been copied to clipboard.");
				 }
			 }
		 }



private: System::Void b_anal_result_to_clip_Click(System::Object^  sender, System::EventArgs^  e) {

			 int roi_index = atoi(cvtStrStr(comboBox_roianal->Text).c_str())-1;
			 cv::Rect roi = ROI_realsize[roi_index];

			 bool proceed = false;
			 if((int)head_marked.size() != num_frames)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・トラッキングが完了していないので，途中までの結果をコピーします");
				 }
				 else
				 {
					 textToLog("・Tracking is incomplete. The partial result is to be copied to clipboard.");
				 }
				 if(target_frame_set) proceed = true;
			 }
			 else
			 {
				 proceed = true;
			 }

			 if(!proceed)
			 {
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 MessageBox::Show("対象フレームを指定して下さい");
				 }
				 else
				 {
					 MessageBox::Show("Select target frames");
				 }
			 }
			 else
			 {

				 tab->Enabled = false;
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("・ROI: "+roi_index+"の解析結果を保存");
				 }
				 else
				 {
					 textToLog("・Svaing the analysis result of ROI: "+roi_index);
				 }


				 int t_start, t_end;
				 if(target_frame_set)
				 {
					 t_start = sttime;
					 t_end = lsttime+1;
				 }
				 else
				 {
					 t_start = 0;
					 t_end = (int)heads.size();
				 }
				 String^ strdata = gcnew String("");

				 for(int t=t_start;t<t_end;t++)
				 {
					  strdata += t;
					  strdata += "\t";
					  strdata += ROI_whenhot[roi_index][t];
					  strdata += "\n";
				 }

				 Clipboard::SetText(strdata);
				 if(englishToolStripMenuItem->Checked==false)
				 {
					 textToLog("　クリップボードへコピーしました");
				 }
				 else
				 {
					 textToLog("  Copied to clipboard");
				 }
				 tab->Enabled=true;
			 }
 }



private: System::Void cb_usebinval_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		 }


//Form1がロードされたときの初期イベント
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {


	if (englishToolStripMenuItem->Checked == false)
	{
		textToLog("・動画ファイルを読み込んでください.\n");
	}
	else
	{
		textToLog("・Load a video file\n");
	}

	tb_exp_date->Enabled = true;
	DateTime d1 = DateTime::Now;
	tb_exp_date->Text = d1.ToString("yyyy/MM/dd");


}



		 //基準点の選択ボタン
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

	if (englishToolStripMenuItem->Checked == false)
	{
		textToLog("・画面上で基準点を選択して下さい");
	}
	else
	{
		textToLog("・Select the reference point by clicking on the screen");
	}
	setting_reference_point = true;
	tab->Enabled = false;
	trackBar->Enabled = false;
	panel_playercontrol->Enabled = false;
	gb_speedcontrol->Enabled = false;
	checkBox_showoriginal->Enabled = false;
	showDisp();
}

};
}